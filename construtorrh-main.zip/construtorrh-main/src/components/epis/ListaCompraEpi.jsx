import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { ShoppingCart, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

export default function ListaCompraEpi({ filtroObra, filtroColaborador }) {
  const { data: epis = [] } = useQuery({ queryKey: ['epis'], queryFn: () => base44.entities.EpiRegistro.list() });

  const pendentes = useMemo(() => {
    return epis.filter(e => 
      e.pendente_compra && 
      (filtroObra === 'todas' || e.obra_id === filtroObra) &&
      (filtroColaborador === 'todos' || e.colaborador_id === filtroColaborador)
    );
  }, [epis, filtroObra, filtroColaborador]);

  // Agrupa por EPI para mostrar quantidades e tamanhos
  const porEpi = useMemo(() => {
    const map = {};
    pendentes.forEach(e => {
      const key = e.equipamento;
      if (!map[key]) map[key] = { equipamento: e.equipamento, ca: e.ca, itens: [] };
      map[key].itens.push({
        colaborador_nome: e.colaborador_nome,
        obra_nome: e.obra_nome,
        tamanho: e.tamanho,
      });
    });
    return Object.values(map);
  }, [pendentes]);

  const porColaborador = useMemo(() => {
    const map = {};
    pendentes.forEach(e => {
      if (!map[e.colaborador_id]) {
        map[e.colaborador_id] = {
          colaborador_nome: e.colaborador_nome,
          obra_nome: e.obra_nome,
          itens: []
        };
      }
      map[e.colaborador_id].itens.push({ equipamento: e.equipamento, tamanho: e.tamanho, ca: e.ca });
    });
    return Object.values(map);
  }, [pendentes]);

  if (pendentes.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <ShoppingCart className="w-10 h-10 mx-auto mb-2 opacity-30" />
        <p>Nenhum EPI pendente de compra</p>
        {filtroObra !== 'todas' && <p className="text-xs mt-1">Tente selecionar outra obra</p>}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Por EPI (consolidado para compra) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="font-semibold text-sm">Lista consolidada para compra</p>
          <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded-full font-medium">{pendentes.length} item(s)</span>
        </div>
        <div className="border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left px-3 py-2 font-medium">EPI</th>
                <th className="text-left px-3 py-2 font-medium">CA</th>
                <th className="text-left px-3 py-2 font-medium">Qtd</th>
                <th className="text-left px-3 py-2 font-medium">Tamanhos</th>
              </tr>
            </thead>
            <tbody>
              {porEpi.map((item, i) => {
                const tamanhos = item.itens.filter(it => it.tamanho).map(it => it.tamanho);
                const semTamanho = item.itens.filter(it => !it.tamanho).length;
                return (
                  <tr key={i} className="border-t">
                    <td className="px-3 py-2 font-medium">{item.equipamento}</td>
                    <td className="px-3 py-2 text-muted-foreground">{item.ca || '-'}</td>
                    <td className="px-3 py-2">{item.itens.length}</td>
                    <td className="px-3 py-2">
                      {tamanhos.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {/* Agrupa por tamanho */}
                          {Object.entries(tamanhos.reduce((acc, t) => { acc[t] = (acc[t] || 0) + 1; return acc; }, {})).map(([t, q]) => (
                            <span key={t} className="bg-blue-100 text-blue-700 text-xs px-1.5 py-0.5 rounded">{t}{q > 1 ? ` (x${q})` : ''}</span>
                          ))}
                          {semTamanho > 0 && <span className="bg-muted text-muted-foreground text-xs px-1.5 py-0.5 rounded">s/tam ({semTamanho})</span>}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">Não aplica</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Por Colaborador */}
      <div>
        <p className="font-semibold text-sm mb-3">Lista por colaborador</p>
        <div className="space-y-2">
          {porColaborador.map((col, i) => (
            <div key={i} className="border rounded-xl overflow-hidden">
              <div className="bg-sidebar text-sidebar-foreground px-4 py-2.5 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{col.colaborador_nome}</p>
                  {col.obra_nome && <p className="text-xs opacity-70">{col.obra_nome}</p>}
                </div>
                <span className="bg-sidebar-accent text-sidebar-accent-foreground text-xs px-2 py-1 rounded">{col.itens.length} item(s)</span>
              </div>
              <div className="p-3">
                <table className="w-full text-xs">
                  <tbody>
                    {col.itens.map((item, j) => (
                      <tr key={j} className={j > 0 ? 'border-t' : ''}>
                        <td className="py-1.5 font-medium">{item.equipamento}</td>
                        <td className="py-1.5 text-muted-foreground">{item.ca ? `CA ${item.ca}` : ''}</td>
                        <td className="py-1.5">
                          {item.tamanho && <span className="bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">{item.tamanho}</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}