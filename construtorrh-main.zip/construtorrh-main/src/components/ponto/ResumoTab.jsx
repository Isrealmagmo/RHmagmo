import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Search, Download } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import StatusBadge from '@/components/ui/StatusBadge';
import { calcTotaisColaborador, formatHoras } from '@/lib/pontoCalc';

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

export default function ResumoTab() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [quinzena, setQuinzena] = useState('1');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list(),
  });

  const { data: registros = [] } = useQuery({
    queryKey: ['pontos-resumo', month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: month, ano: year }),
  });

  const { data: obras = [] } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list(),
  });

  const resumo = useMemo(() => {
    const ativos = colaboradores.filter(c => c.status === 'ativo');
    return ativos.map(col => {
      const colRegs = registros.filter(r => r.colaborador_id === col.id && (quinzena === 'todas' || r.quinzena === Number(quinzena)));
      const aprovado = colRegs.every(r => r.aprovado) && colRegs.length > 0;
      const status_ponto = aprovado ? 'aprovado' : colRegs.filter(r => r.presente).length > 0 ? 'pendente' : 'sem_ponto';

      // Valor hora a partir da função ou salário do colaborador
      const funcao = funcoes.find(f => f.id === col.funcao_id);
      const valorHora = col.tipo_contrato === 'clt'
        ? (funcao?.piso_clt || col.salario || 0)
        : (funcao?.piso_autonomo || col.salario || 0);

      // Busca a primeira obra do colaborador (já que ResumoTab agrupa por colaborador)
      const colObra = obras.find(o => o.id === col.obra_id);
      const totais = calcTotaisColaborador(colRegs, valorHora, col.tipo_contrato, colObra);

      return { ...col, ...totais, status_ponto };
    }).filter(c => {
      if (search && !c.nome?.toLowerCase().includes(search.toLowerCase())) return false;
      if (statusFilter !== 'todos' && c.status_ponto !== statusFilter) return false;
      return true;
    });
  }, [colaboradores, funcoes, registros, search, statusFilter, quinzena]);

  const totalGeral = useMemo(() => resumo.reduce((s, c) => s + c.totalBruto, 0), [resumo]);

  const gerarRelatorioPDF = (tipo) => {
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    let yPos = 15;

    const addHeader = () => {
      pdf.setFontSize(16);
      pdf.text(`Relatório de Ponto - ${tipo === 'colaborador' ? 'Por Colaborador' : 'Por Obra'}`, pageWidth / 2, yPos, { align: 'center' });
      yPos += 8;
      pdf.setFontSize(10);
      pdf.text(`${MONTHS[month - 1]} de ${year} - ${quinzena === '1' ? '1ª Quinzena' : quinzena === '2' ? '2ª Quinzena' : 'Ambas'}`, pageWidth / 2, yPos, { align: 'center' });
      yPos += 12;
    };

    const addFooter = () => {
      if (yPos > pageHeight - 15) {
        pdf.addPage();
        yPos = 15;
      }
    };

    addHeader();

    if (tipo === 'colaborador') {
      pdf.setFontSize(11);
      pdf.setTextColor(40);
      const colWidths = [40, 20, 20, 25, 25];
      const headers = ['Colaborador', 'Tipo', 'Dias', 'Horas', 'Total'];
      let tableYPos = yPos;

      pdf.setFillColor(230, 230, 230);
      let xPos = 10;
      headers.forEach((h, i) => {
        pdf.text(h, xPos, tableYPos);
        xPos += colWidths[i];
      });
      tableYPos += 7;

      resumo.forEach((col) => {
        addFooter();
        xPos = 10;
        pdf.setFontSize(9);
        pdf.text(col.nome.substring(0, 20), xPos, tableYPos);
        xPos += colWidths[0];
        pdf.text(col.tipo_contrato === 'clt' ? 'CLT' : 'Aut', xPos, tableYPos);
        xPos += colWidths[1];
        pdf.text(String(col.dias), xPos, tableYPos, { align: 'right' });
        xPos += colWidths[2];
        pdf.text(formatHoras(col.totalHorasNormais), xPos, tableYPos, { align: 'right' });
        xPos += colWidths[3];
        pdf.text(`R$ ${col.totalBruto.toFixed(2)}`, xPos, tableYPos, { align: 'right' });
        tableYPos += 6;
        yPos = tableYPos;
      });

      addFooter();
      pdf.setFontSize(11);
      pdf.setTextColor(0, 128, 0);
      pdf.text(`Total Geral: R$ ${totalGeral.toFixed(2)}`, pageWidth - 20, yPos, { align: 'right' });
    } else {
      // Agrupar por obra
      const porObra = {};
      registros.forEach((reg) => {
        if (quinzena !== 'todas' && reg.quinzena !== Number(quinzena)) return;
        if (reg.mes !== month || reg.ano !== year) return;
        const chaveObra = reg.obra_id || 'Sem Obra';
        if (!porObra[chaveObra]) porObra[chaveObra] = [];
        porObra[chaveObra].push(reg);
      });

      pdf.setFontSize(11);
      Object.keys(porObra).forEach((obraId) => {
        addFooter();
        const obra = obras.find(o => o.id === obraId);
        pdf.setTextColor(0, 91, 187);
        pdf.setFontSize(11);
        pdf.text(`${obra?.nome || 'Sem Obra'} (${obra?.codigo || ''})`, 10, yPos);
        yPos += 8;

        const regs = porObra[obraId];
        let totalObra = 0;
        pdf.setFontSize(9);
        pdf.setTextColor(40);

        regs.forEach((reg) => {
          addFooter();
          const col = colaboradores.find(c => c.id === reg.colaborador_id);
          const horas = reg.horas_normais || 0;
          const valor = horas * (reg.valor_hora_snapshot || 0);
          totalObra += valor;
          pdf.text(`${col?.nome || 'N/A'}: ${horas}h - R$ ${valor.toFixed(2)}`, 15, yPos);
          yPos += 6;
        });

        pdf.setTextColor(0, 128, 0);
        pdf.setFontSize(10);
        pdf.text(`Subtotal: R$ ${totalObra.toFixed(2)}`, 15, yPos);
        yPos += 10;
      });
    }

    pdf.save(`relatorio-ponto-${tipo}-${month}-${year}.pdf`);
  };

  return (
    <div className="mt-4 space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <Select value={String(month)} onValueChange={v => setMonth(Number(v))}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m.slice(0, 3)}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(year)} onValueChange={v => setYear(Number(v))}>
          <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
          <SelectContent>{[2024,2025,2026,2027].map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={quinzena} onValueChange={setQuinzena}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todas">Todas quinzenas</SelectItem>
            <SelectItem value="1">1ª Quinzena (1–15)</SelectItem>
            <SelectItem value="2">2ª Quinzena (16–fim)</SelectItem>
          </SelectContent>
        </Select>

        {/* Badge mostrando a quinzena selecionada */}
        <div className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-primary/10 text-primary border border-primary/30">
          {quinzena === 'todas' ? 'Mês Completo' : quinzena === '1' ? '1ª Quinzena' : '2ª Quinzena'}
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="aprovado">Aprovado</SelectItem>
            <SelectItem value="pendente">Pendente</SelectItem>
            <SelectItem value="sem_ponto">Sem ponto</SelectItem>
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        {/* Botões de relatório */}
        <Button variant="outline" size="sm" onClick={() => gerarRelatorioPDF('colaborador')} className="gap-1">
          <Download className="w-3.5 h-3.5" /> Relatório
        </Button>
        <Button variant="outline" size="sm" onClick={() => gerarRelatorioPDF('obra')} className="gap-1">
          <Download className="w-3.5 h-3.5" /> Por Obra
        </Button>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted">
              <th className="text-left px-4 py-3 font-medium">Colaborador</th>
              <th className="text-left px-4 py-3 font-medium">Tipo</th>
              <th className="text-right px-4 py-3 font-medium">Dias</th>
              <th className="text-right px-4 py-3 font-medium">Horas</th>
              <th className="text-right px-4 py-3 font-medium">Produção</th>
              <th className="text-right px-4 py-3 font-medium">Total Quinzena</th>
              <th className="text-left px-4 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {resumo.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Nenhum registro encontrado</td></tr>
            ) : (
              resumo.map(col => (
                <tr key={col.id} className="border-t hover:bg-muted/30">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{col.nome}</span>
                      {quinzena !== 'todas' && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full border bg-muted text-muted-foreground">
                          {quinzena === '1' ? '1ª Q' : '2ª Q'}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${col.tipo_contrato === 'clt' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>
                      {col.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">{col.dias}</td>
                  <td className="px-4 py-3 text-right">
                    <span className="text-primary font-medium">{formatHoras(col.totalHorasNormais)}</span>
                    {col.totalHorasExtra > 0 && (
                      <span className="text-orange-500 text-xs ml-1">+{formatHoras(col.totalHorasExtra)}</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {col.totalProducao > 0 ? (
                      <span className="text-green-700 font-medium">R$ {col.totalProducao.toFixed(2)}</span>
                    ) : <span className="text-muted-foreground">—</span>}
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-green-700">
                    R$ {col.totalBruto.toFixed(2)}
                  </td>
                  <td className="px-4 py-3"><StatusBadge status={col.status_ponto} /></td>
                </tr>
              ))
            )}
          </tbody>
          {resumo.length > 0 && (
            <tfoot>
              <tr className="border-t bg-muted/60">
                <td colSpan={5} className="px-4 py-2 text-right font-semibold text-sm">Total Geral:</td>
                <td className="px-4 py-2 text-right font-bold text-green-700">R$ {totalGeral.toFixed(2)}</td>
                <td />
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}