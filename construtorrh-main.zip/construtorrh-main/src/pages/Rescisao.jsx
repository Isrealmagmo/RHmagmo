import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Download, Search, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import jsPDF from 'jspdf';

const MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

export default function Rescisao() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [search, setSearch] = useState('');
  const [reportType, setReportType] = useState('individual'); // individual, obra, resumo
  const [selectedColab, setSelectedColab] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-rescisao', month, year],
    queryFn: () => base44.entities.Pagamento.filter({ mes: month, ano: year, tipo: 'rescisao' }),
  });

  const { data: provisoes = [] } = useQuery({
    queryKey: ['provisoes-rescisao', month, year],
    queryFn: () => base44.entities.ProvFGTS.filter({ mes: month, ano: year }),
  });

  const { data: registros = [] } = useQuery({
    queryKey: ['registros-ponto-rescisao', month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: month, ano: year }),
  });

  const cltColabs = useMemo(() => colaboradores.filter(c => c.tipo_contrato === 'clt'), [colaboradores]);

  const calcularRescisao = (colabId) => {
    const prov = provisoes.find(p => p.colaborador_id === colabId);
    const pagtoRescisao = pagamentos.find(p => p.colaborador_id === colabId);
    
    if (!prov && !pagtoRescisao) return null;

    return {
      colaborador_id: colabId,
      colaborador_nome: prov?.colaborador_nome || pagtoRescisao?.colaborador_nome || '',
      prov13Sal: prov?.prov_13_salario || 0,
      fgtsRecisorio: prov?.fgts_recolhido || 0,
      multaFgts40: prov?.multa_fgts_40 || 0,
      provFerias: prov?.prov_ferias || 0,
      prov1_3Ferias: prov?.prov_1_3_ferias || 0,
      saldoSalario: pagtoRescisao?.valor || 0,
      total: (prov?.prov_13_salario || 0) + (prov?.fgts_recolhido || 0) + (prov?.multa_fgts_40 || 0) + (prov?.prov_ferias || 0) + (prov?.prov_1_3_ferias || 0) + (pagtoRescisao?.valor || 0),
    };
  };

  const rescisoes = useMemo(() => {
    const result = [];
    cltColabs.forEach(c => {
      const data = calcularRescisao(c.id);
      if (data) result.push(data);
    });
    return result;
  }, [cltColabs, provisoes, pagamentos]);

  const filtered = useMemo(() => {
    if (!search.trim()) return rescisoes;
    const s = search.toLowerCase();
    return rescisoes.filter(r => r.colaborador_nome?.toLowerCase().includes(s) || cltColabs.find(c => c.id === r.colaborador_id)?.chapa?.toLowerCase().includes(s));
  }, [rescisoes, search, cltColabs]);

  const totais = useMemo(() => {
    const t = filtered.reduce((acc, r) => ({
      prov13Sal: acc.prov13Sal + (r.prov13Sal || 0),
      fgtsRecisorio: acc.fgtsRecisorio + (r.fgtsRecisorio || 0),
      multaFgts40: acc.multaFgts40 + (r.multaFgts40 || 0),
      provFerias: acc.provFerias + (r.provFerias || 0),
      prov1_3Ferias: acc.prov1_3Ferias + (r.prov1_3Ferias || 0),
      saldoSalario: acc.saldoSalario + (r.saldoSalario || 0),
      total: acc.total + (r.total || 0),
    }), { prov13Sal: 0, fgtsRecisorio: 0, multaFgts40: 0, provFerias: 0, prov1_3Ferias: 0, saldoSalario: 0, total: 0 });
    return t;
  }, [filtered]);

  const gerarPDFIndividual = (rescisao) => {
    const doc = new jsPDF();
    const col = cltColabs.find(c => c.id === rescisao.colaborador_id);
    
    doc.setFontSize(16);
    doc.text('RESUMO DE RESCISÃO', 20, 20);
    
    doc.setFontSize(10);
    doc.text(`Colaborador: ${rescisao.colaborador_nome}`, 20, 35);
    doc.text(`Chapa: ${col?.chapa || '—'}`, 20, 42);
    doc.text(`Função: ${col?.funcao_nome || '—'}`, 20, 49);
    doc.text(`Período: ${MONTHS[month - 1]}/${year}`, 20, 56);

    let y = 70;
    const dados = [
      ['Prov. 13º Salário', `R$ ${rescisao.prov13Sal.toFixed(2)}`],
      ['FGTS Rescisório', `R$ ${rescisao.fgtsRecisorio.toFixed(2)}`],
      ['Multa FGTS 40%', `R$ ${rescisao.multaFgts40.toFixed(2)}`],
      ['Provisão Férias', `R$ ${rescisao.provFerias.toFixed(2)}`],
      ['Prov. 1/3 Férias', `R$ ${rescisao.prov1_3Ferias.toFixed(2)}`],
      ['Saldo Salário', `R$ ${rescisao.saldoSalario.toFixed(2)}`],
    ];

    doc.setFontSize(11);
    doc.setFont(undefined, 'bold');
    dados.forEach((linha, i) => {
      doc.text(linha[0], 20, y);
      doc.text(linha[1], 150, y, { align: 'right' });
      y += 8;
    });

    y += 5;
    doc.setFillColor(240, 240, 240);
    doc.rect(20, y - 2, 170, 10, 'F');
    doc.setFontSize(12);
    doc.setFont(undefined, 'bold');
    doc.text('TOTAL', 20, y + 5);
    doc.text(`R$ ${rescisao.total.toFixed(2)}`, 150, y + 5, { align: 'right' });

    doc.save(`rescisao_${rescisao.colaborador_nome.replace(/\s+/g, '_')}_${month}_${year}.pdf`);
  };

  const gerarPDFResumo = () => {
    const doc = new jsPDF('l'); // landscape
    doc.setFontSize(16);
    doc.text('RESUMO GERAL DE RESCISÕES', 20, 20);
    doc.setFontSize(10);
    doc.text(`Período: ${MONTHS[month - 1]}/${year} | Total: ${filtered.length} colaboradores`, 20, 30);

    const colunas = ['Colaborador', 'Chapa', 'Prov. 13º', 'FGTS', 'Multa 40%', 'Férias', '1/3 Férias', 'Saldo', 'Total'];
    const dados = filtered.map(r => {
      const col = cltColabs.find(c => c.id === r.colaborador_id);
      return [
        r.colaborador_nome,
        col?.chapa || '—',
        `R$ ${r.prov13Sal.toFixed(2)}`,
        `R$ ${r.fgtsRecisorio.toFixed(2)}`,
        `R$ ${r.multaFgts40.toFixed(2)}`,
        `R$ ${r.provFerias.toFixed(2)}`,
        `R$ ${r.prov1_3Ferias.toFixed(2)}`,
        `R$ ${r.saldoSalario.toFixed(2)}`,
        `R$ ${r.total.toFixed(2)}`,
      ];
    });

    let y = 40;
    doc.setFontSize(9);
    doc.setFont(undefined, 'bold');
    const colWidths = [25, 12, 18, 16, 18, 16, 16, 16, 20];
    let x = 15;
    colunas.forEach((col, i) => {
      doc.text(col, x, y);
      x += colWidths[i];
    });

    y += 5;
    doc.setDrawColor(200);
    doc.line(15, y, 280, y);
    y += 3;

    doc.setFont(undefined, 'normal');
    dados.forEach(linha => {
      if (y > 180) {
        doc.addPage();
        y = 15;
      }
      x = 15;
      linha.forEach((val, i) => {
        doc.text(val, x, y, { maxWidth: colWidths[i] - 1 });
        x += colWidths[i];
      });
      y += 5;
    });

    y += 3;
    doc.line(15, y, 280, y);
    y += 5;
    doc.setFont(undefined, 'bold');
    const totaisLinha = [
      'TOTAL',
      '',
      `R$ ${totais.prov13Sal.toFixed(2)}`,
      `R$ ${totais.fgtsRecisorio.toFixed(2)}`,
      `R$ ${totais.multaFgts40.toFixed(2)}`,
      `R$ ${totais.provFerias.toFixed(2)}`,
      `R$ ${totais.prov1_3Ferias.toFixed(2)}`,
      `R$ ${totais.saldoSalario.toFixed(2)}`,
      `R$ ${totais.total.toFixed(2)}`,
    ];
    x = 15;
    totaisLinha.forEach((val, i) => {
      doc.text(val, x, y, { maxWidth: colWidths[i] - 1 });
      x += colWidths[i];
    });

    doc.save(`rescisoes_${month}_${year}.pdf`);
  };

  return (
    <div>
      <PageHeader title="Rescisão" subtitle={`Total a pagar: R$ ${totais.total.toFixed(2)}`} icon="FileText">
        <Button onClick={() => gerarPDFResumo()} className="gap-1.5"><Download className="w-4 h-4" /> Exportar PDF</Button>
      </PageHeader>

      <div className="flex gap-2 mb-4 flex-wrap">
        <Select value={String(month)} onValueChange={v => setMonth(Number(v))}>
          <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
          <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(year)} onValueChange={v => setYear(Number(v))}>
          <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
          <SelectContent>{[2024,2025,2026,2027].map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted">
              <th className="text-left px-3 py-3 font-medium">Colaborador</th>
              <th className="text-right px-3 py-3 font-medium">Prov 13º Sal</th>
              <th className="text-right px-3 py-3 font-medium">FGTS Recisório (R$)</th>
              <th className="text-right px-3 py-3 font-medium">Multa FGTS 40% (R$)</th>
              <th className="text-right px-3 py-3 font-medium">Provisão férias</th>
              <th className="text-right px-3 py-3 font-medium">Prov 1/3 férias</th>
              <th className="text-right px-3 py-3 font-medium">Saldo Salário</th>
              <th className="text-right px-3 py-3 font-medium">Total</th>
              <th className="px-3 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={9} className="text-center py-8 text-muted-foreground">Nenhum registro de rescisão</td></tr>
            ) : (
              <>
                {filtered.map(r => (
                  <tr key={r.colaborador_id} className="border-t hover:bg-muted/30">
                    <td className="px-3 py-3 font-medium">{r.colaborador_nome}</td>
                    <td className="px-3 py-3 text-right">R$ {r.prov13Sal.toFixed(2)}</td>
                    <td className="px-3 py-3 text-right">R$ {r.fgtsRecisorio.toFixed(2)}</td>
                    <td className="px-3 py-3 text-right">R$ {r.multaFgts40.toFixed(2)}</td>
                    <td className="px-3 py-3 text-right">R$ {r.provFerias.toFixed(2)}</td>
                    <td className="px-3 py-3 text-right">R$ {r.prov1_3Ferias.toFixed(2)}</td>
                    <td className="px-3 py-3 text-right">R$ {r.saldoSalario.toFixed(2)}</td>
                    <td className="px-3 py-3 text-right font-semibold">R$ {r.total.toFixed(2)}</td>
                    <td className="px-3 py-3">
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setSelectedColab(r); setDetailOpen(true); }}>
                        <Eye className="w-3.5 h-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))}
                <tr className="border-t bg-muted/50 font-semibold">
                  <td className="px-3 py-3">TOTAL</td>
                  <td className="px-3 py-3 text-right">R$ {totais.prov13Sal.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">R$ {totais.fgtsRecisorio.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">R$ {totais.multaFgts40.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">R$ {totais.provFerias.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">R$ {totais.prov1_3Ferias.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">R$ {totais.saldoSalario.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">R$ {totais.total.toFixed(2)}</td>
                  <td></td>
                </tr>
              </>
            )}
          </tbody>
        </table>
      </div>

      {/* Detail Modal */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Detalhes da Rescisão</DialogTitle></DialogHeader>
          {selectedColab && (
            <div className="space-y-3">
              <div className="flex justify-between"><span>Prov. 13º Salário:</span><span className="font-semibold">R$ {selectedColab.prov13Sal.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>FGTS Rescisório:</span><span className="font-semibold">R$ {selectedColab.fgtsRecisorio.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Multa FGTS 40%:</span><span className="font-semibold">R$ {selectedColab.multaFgts40.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Provisão Férias:</span><span className="font-semibold">R$ {selectedColab.provFerias.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Prov. 1/3 Férias:</span><span className="font-semibold">R$ {selectedColab.prov1_3Ferias.toFixed(2)}</span></div>
              <div className="flex justify-between"><span>Saldo Salário:</span><span className="font-semibold">R$ {selectedColab.saldoSalario.toFixed(2)}</span></div>
              <div className="border-t pt-3 flex justify-between text-lg"><span className="font-bold">TOTAL:</span><span className="font-bold text-green-700">R$ {selectedColab.total.toFixed(2)}</span></div>
              <Button className="w-full" onClick={() => gerarPDFIndividual(selectedColab)}><Download className="w-4 h-4 mr-2" /> Gerar PDF Individual</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}