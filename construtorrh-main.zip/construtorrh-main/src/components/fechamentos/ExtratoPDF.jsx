import jsPDF from 'jspdf';
import { calcHorasNormais, calcHorasExtra, getAdicionalFator, formatHoras } from '@/lib/pontoCalc';

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const DIAS_SEMANA = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const ADICIONAL_LABEL = { normal: '', '50_sab': 'Sáb +50%', '100_dom': 'Dom +100%', '100_fer': 'Fer +100%' };
const TIPO_LABELS = { normal: 'Normal', falta: 'Falta', atestado: 'Atestado', feriado: 'Feriado', folga: 'Folga' };

function fmt(v) { return `R$ ${Number(v || 0).toFixed(2)}`; }
function fmtDate(str) {
  if (!str) return '';
  const d = new Date(str + 'T00:00:00');
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;
}

// ─── Helpers de layout ────────────────────────────────────────────────────────
function newPage(doc, y, minSpace) {
  if (y + minSpace > 272) { doc.addPage(); return 14; }
  return y;
}

function sectionTitle(doc, label, y, W, margin) {
  doc.setFillColor(30, 58, 138);
  doc.rect(margin, y, W - margin * 2, 6.5, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text(label, margin + 2, y + 4.5);
  return y + 7;
}

function hrLine(doc, y, W, margin, color = [220, 220, 220]) {
  doc.setDrawColor(...color);
  doc.line(margin, y, W - margin, y);
  return y + 3;
}

function row2col(doc, label, value, y, margin, W, boldValue = false, valueColor = null) {
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(80, 90, 110);
  doc.text(label, margin + 2, y);
  doc.setFont('helvetica', boldValue ? 'bold' : 'normal');
  doc.setTextColor(...(valueColor || [30, 41, 59]));
  doc.text(String(value), W - margin - 2, y, { align: 'right' });
  return y + 5.5;
}

// ─── Função principal ─────────────────────────────────────────────────────────
export function gerarExtratoPDF({
  colaborador, registros, adiantamentos,
  descontoINSS, descontoVT, descontoIR, liquido,
  totalBruto, totalHorasNormais, totalHorasExtra, totalProducao,
  mes, ano, quinzena,
  premios = [],
  vtLancamento = null,
}) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = 210;
  const margin = 12;
  let y = 0;

  // ══════════════════════════════════════════════════════
  // CABEÇALHO
  // ══════════════════════════════════════════════════════
  doc.setFillColor(15, 40, 100);
  doc.rect(0, 0, W, 32, 'F');

  // faixa decorativa lateral
  doc.setFillColor(59, 130, 246);
  doc.rect(0, 0, 4, 32, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(17);
  doc.setFont('helvetica', 'bold');
  doc.text('EXTRATO DE PAGAMENTO', margin + 4, 12);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(180, 200, 240);
  const periodo = `${MONTHS[mes - 1]}/${ano}  —  ${quinzena === 1 ? '1ª Quinzena' : '2ª Quinzena'}`;
  doc.text(periodo, margin + 4, 19);
  doc.text(`Emitido em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`, W - margin, 19, { align: 'right' });

  y = 36;

  // ══════════════════════════════════════════════════════
  // DADOS DO COLABORADOR
  // ══════════════════════════════════════════════════════
  doc.setFillColor(241, 245, 253);
  doc.roundedRect(margin, y, W - margin * 2, 26, 2, 2, 'F');
  doc.setDrawColor(200, 215, 240);
  doc.roundedRect(margin, y, W - margin * 2, 26, 2, 2, 'S');

  doc.setTextColor(15, 40, 100);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text((colaborador.nome || '').toUpperCase(), margin + 4, y + 8);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 100, 140);

  const colLabels = [
    colaborador.chapa ? `Chapa: ${colaborador.chapa}` : null,
    colaborador.funcao_nome ? `Função: ${colaborador.funcao_nome}` : null,
    colaborador.tipo_contrato ? `Contrato: ${colaborador.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo'}` : null,
    colaborador.obra_nome ? `Obra: ${colaborador.obra_nome}` : null,
  ].filter(Boolean);
  doc.text(colLabels.join('   |   '), margin + 4, y + 15);

  const cpfAdm = [
    colaborador.cpf ? `CPF: ${colaborador.cpf}` : null,
    colaborador.data_admissao ? `Admissão: ${fmtDate(colaborador.data_admissao)}` : null,
    colaborador.pis_nit ? `PIS/NIT: ${colaborador.pis_nit}` : null,
  ].filter(Boolean);
  if (cpfAdm.length) doc.text(cpfAdm.join('   |   '), margin + 4, y + 21);

  y += 30;

  // ══════════════════════════════════════════════════════
  // RESUMO FINANCEIRO (3 colunas)
  // ══════════════════════════════════════════════════════
  y = newPage(doc, y, 40);
  y = sectionTitle(doc, 'RESUMO FINANCEIRO', y, W, margin);
  y += 3;

  const colW = (W - margin * 2) / 3;
  const resumoBlocks = [
    { label: 'Horas Normais', value: formatHoras(totalHorasNormais), color: [30, 64, 175] },
    { label: 'Horas Extras', value: formatHoras(totalHorasExtra), color: totalHorasExtra > 0 ? [217, 119, 6] : [160, 170, 190] },
    { label: 'Produção Total', value: fmt(totalProducao), color: totalProducao > 0 ? [5, 150, 105] : [160, 170, 190] },
    { label: 'Prêmios / Bônus', value: fmt(premios.reduce((s, p) => s + (p.valor || 0), 0)), color: premios.length > 0 ? [124, 58, 237] : [160, 170, 190] },
    { label: 'VT Recebido', value: vtLancamento ? fmt(vtLancamento.valor_total) : '—', color: [14, 116, 144] },
    { label: 'TOTAL BRUTO', value: fmt(totalBruto), color: [15, 40, 100], bold: true },
  ];
  resumoBlocks.forEach((b, i) => {
    const cx = margin + (i % 3) * colW + colW / 2;
    const cy = y + Math.floor(i / 3) * 17;
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(120, 130, 150);
    doc.text(b.label, cx, cy, { align: 'center', maxWidth: colW - 4 });
    doc.setFontSize(b.bold ? 9.5 : 8.5);
    doc.setFont('helvetica', b.bold ? 'bold' : 'normal');
    doc.setTextColor(...b.color);
    doc.text(b.value, cx, cy + 6.5, { align: 'center', maxWidth: colW - 4 });
  });
  y += 36;

  // ══════════════════════════════════════════════════════
  // DESCONTOS
  // ══════════════════════════════════════════════════════
  const descontos = [
    descontoINSS > 0 ? { label: 'INSS (Previdência Social)', value: descontoINSS } : null,
    descontoVT > 0 ? { label: 'Vale Transporte (desconto 6%)', value: descontoVT } : null,
    descontoIR > 0 ? { label: 'Imposto de Renda Retido (IR)', value: descontoIR } : null,
    ...(adiantamentos || []).map(a => ({ label: a.descricao || 'Adiantamento', value: a.valor })),
  ].filter(Boolean);

  if (descontos.length > 0) {
    y = newPage(doc, y, descontos.length * 6 + 20);
    y = sectionTitle(doc, 'DESCONTOS', y, W, margin);
    y += 3;

    descontos.forEach((d, i) => {
      if (i % 2 === 0) {
        doc.setFillColor(248, 250, 255);
        doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F');
      }
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(60, 70, 100);
      doc.text(d.label, margin + 3, y + 2);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(185, 28, 28);
      doc.text(`- ${fmt(d.value)}`, W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });

    // subtotal descontos
    const totalDesc = descontos.reduce((s, d) => s + d.value, 0);
    doc.setFillColor(254, 242, 242);
    doc.rect(margin, y, W - margin * 2, 6, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(185, 28, 28);
    doc.text('Total de Descontos', margin + 3, y + 4);
    doc.text(`- ${fmt(totalDesc)}`, W - margin - 3, y + 4, { align: 'right' });
    y += 9;
  }

  // ══════════════════════════════════════════════════════
  // LÍQUIDO A RECEBER
  // ══════════════════════════════════════════════════════
  y = newPage(doc, y, 18);
  doc.setFillColor(5, 150, 105);
  doc.roundedRect(margin, y, W - margin * 2, 15, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('LÍQUIDO A RECEBER', margin + 5, y + 9.5);
  doc.setFontSize(13);
  doc.text(fmt(liquido), W - margin - 5, y + 9.5, { align: 'right' });
  y += 20;

  // ══════════════════════════════════════════════════════
  // VALE TRANSPORTE — detalhes
  // ══════════════════════════════════════════════════════
  if (vtLancamento) {
    y = newPage(doc, y, 40);
    y = sectionTitle(doc, 'VALE TRANSPORTE — DETALHAMENTO', y, W, margin);
    y += 3;

    const vtRows = [
      ['Tipo de VT', (colaborador.vt_tipo || '').replace(/_/g, ' ')],
      ['Valor por Dia', fmt(vtLancamento.valor_dia)],
      ['Dias Esperados (quinzena)', String(vtLancamento.dias_esperados || '—')],
      ['Dias Trabalhados', String(vtLancamento.dias_trabalhados || '—')],
      ['Valor Total VT (pago)', fmt(vtLancamento.valor_total)],
    ];
    if (vtLancamento.observacoes) vtRows.push(['Observação (descontos)', vtLancamento.observacoes]);

    // trechos
    const trechosIda = colaborador.vt_trechos_ida || [];
    const trechosVolta = colaborador.vt_trechos_volta || [];
    if (trechosIda.length > 0) {
      vtRows.push(['Trechos de Ida', trechosIda.map(t => `${t.nome_linha || t.linha || t.tipo}: ${fmt(t.valor)}`).join(' + ')]);
    }
    if (trechosVolta.length > 0) {
      vtRows.push(['Trechos de Volta', trechosVolta.map(t => `${t.nome_linha || t.linha || t.tipo}: ${fmt(t.valor)}`).join(' + ')]);
    }

    vtRows.forEach((r, i) => {
      if (i % 2 === 0) { doc.setFillColor(248, 252, 255); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(60, 80, 120);
      doc.text(r[0], margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(14, 116, 144);
      doc.text(String(r[1]), W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });
    y += 3;
  }

  // ══════════════════════════════════════════════════════
  // PRÊMIOS E BÔNUS
  // ══════════════════════════════════════════════════════
  if (premios.length > 0) {
    y = newPage(doc, y, premios.length * 6 + 20);
    y = sectionTitle(doc, 'PRÊMIOS E BÔNUS', y, W, margin);
    y += 3;

    premios.forEach((p, i) => {
      if (i % 2 === 0) { doc.setFillColor(250, 247, 255); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(80, 60, 130);
      const label = [p.descricao || 'Prêmio', p.motivo ? `(${p.motivo})` : '', p.data ? fmtDate(p.data) : ''].filter(Boolean).join(' ');
      doc.text(label, margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(124, 58, 237);
      doc.text(fmt(p.valor), W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });

    const totalPremios = premios.reduce((s, p) => s + (p.valor || 0), 0);
    doc.setFillColor(245, 240, 255);
    doc.rect(margin, y, W - margin * 2, 6, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8);
    doc.setTextColor(109, 40, 217);
    doc.text('Total Prêmios / Bônus', margin + 3, y + 4);
    doc.text(fmt(totalPremios), W - margin - 3, y + 4, { align: 'right' });
    y += 10;
  }

  // ══════════════════════════════════════════════════════
  // DADOS BANCÁRIOS
  // ══════════════════════════════════════════════════════
  if (colaborador.pix_chave || colaborador.banco) {
    y = newPage(doc, y, 22);
    y = sectionTitle(doc, 'DADOS PARA PAGAMENTO', y, W, margin);
    y += 3;

    const dadosBancarios = [
      colaborador.pix_chave ? [`PIX — ${(colaborador.pix_tipo || 'chave').replace(/_/g, ' ')}`, colaborador.pix_chave] : null,
      colaborador.banco ? ['Banco', colaborador.banco] : null,
      colaborador.agencia ? ['Agência / Conta', `${colaborador.agencia} / ${colaborador.conta || '—'} (${colaborador.tipo_conta || 'corrente'})`] : null,
    ].filter(Boolean);

    dadosBancarios.forEach((r, i) => {
      if (i % 2 === 0) { doc.setFillColor(248, 250, 252); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(60, 80, 100);
      doc.text(r[0], margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(15, 40, 100);
      doc.text(r[1], W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });
    y += 3;
  }

  // ══════════════════════════════════════════════════════
  // REGISTROS DE PONTO — TABELA DETALHADA
  // ══════════════════════════════════════════════════════
  const regOrdenados = [...registros].sort((a, b) => a.data < b.data ? -1 : 1);

  if (regOrdenados.length > 0) {
    y = newPage(doc, y, 30);
    y = sectionTitle(doc, 'REGISTROS DE PONTO', y, W, margin);
    y += 1;

    // cabeçalho da tabela
    const TH = [
      { l: 'Data', x: margin + 1, w: 14 },
      { l: 'Dia', x: margin + 15, w: 9 },
      { l: 'Entrada', x: margin + 25, w: 13 },
      { l: 'Alm.Saída', x: margin + 38, w: 14 },
      { l: 'Alm.Ret.', x: margin + 53, w: 14 },
      { l: 'Saída', x: margin + 67, w: 12 },
      { l: 'H.Norm.', x: margin + 80, w: 13 },
      { l: 'H.Extra', x: margin + 94, w: 12 },
      { l: 'Adicional', x: margin + 107, w: 18 },
      { l: 'Produção', x: margin + 126, w: 20 },
      { l: 'Vlr.Dia', x: margin + 147, w: 18 },
      { l: 'Tipo', x: margin + 166, w: 18 },
    ];

    doc.setFillColor(44, 82, 180);
    doc.rect(margin, y, W - margin * 2, 6.5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'bold');
    TH.forEach(h => doc.text(h.l, h.x, y + 4.5));
    y += 7;

    let totalH = 0, totalHE = 0, totalP = 0, totalVD = 0;

    regOrdenados.forEach((reg, idx) => {
      if (y > 270) { doc.addPage(); y = 14; }

      const isEven = idx % 2 === 0;
      doc.setFillColor(isEven ? 248 : 255, isEven ? 250 : 255, isEven ? 255 : 255);
      doc.rect(margin, y - 1, W - margin * 2, 6.5, 'F');

      const d = new Date(reg.data + 'T00:00:00');
      const dow = d.getDay();
      const diaSemana = DIAS_SEMANA[dow];
      const isWeekend = dow === 0 || dow === 6;

      const hNorm = reg.tipo === 'atestado' ? 0 : calcHorasNormais(reg.entrada, reg.saida, reg.saida_almoco, reg.retorno_almoco);
      const hExtra = calcHorasExtra(reg.entrada_extra, reg.saida_extra);
      const fator = getAdicionalFator(reg.adicional);
      const vh = reg.valor_hora_snapshot || 0;
      const valorDia = reg.valor_producao > 0
        ? reg.valor_producao
        : (hNorm + hExtra) * fator * vh;

      totalH += hNorm; totalHE += hExtra; totalP += reg.valor_producao || 0; totalVD += valorDia;

      const isAusente = !reg.presente && reg.tipo !== 'atestado';
      const baseColor = isAusente ? [170, 100, 100] : isWeekend ? [80, 80, 180] : [40, 50, 70];

      doc.setTextColor(...baseColor);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);

      const rv = y + 4;
      doc.text(fmtDate(reg.data), TH[0].x, rv);
      doc.text(diaSemana, TH[1].x, rv);
      doc.text(reg.entrada || '—', TH[2].x, rv);
      doc.text(reg.saida_almoco || '—', TH[3].x, rv);
      doc.text(reg.retorno_almoco || '—', TH[4].x, rv);
      doc.text(reg.saida || '—', TH[5].x, rv);
      doc.text(hNorm > 0 ? formatHoras(hNorm) : '—', TH[6].x, rv);
      doc.text(hExtra > 0 ? formatHoras(hExtra) : '—', TH[7].x, rv);

      // Adicional com cor
      const adicLabel = ADICIONAL_LABEL[reg.adicional];
      if (adicLabel) {
        doc.setTextColor(217, 119, 6);
        doc.setFont('helvetica', 'bold');
        doc.text(adicLabel, TH[8].x, rv);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...baseColor);
      } else {
        doc.text('—', TH[8].x, rv);
      }

      // Produção com cor verde
      if (reg.valor_producao > 0) {
        doc.setTextColor(5, 120, 80);
        doc.setFont('helvetica', 'bold');
        doc.text(fmt(reg.valor_producao), TH[9].x, rv);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...baseColor);
      } else {
        doc.text('—', TH[9].x, rv);
      }

      doc.text(valorDia > 0 ? fmt(valorDia) : '—', TH[10].x, rv);

      // Tipo com cor
      const tipo = reg.tipo || 'normal';
      const tipoColorMap = { normal: [22, 130, 70], falta: [200, 30, 30], atestado: [217, 119, 6], feriado: [30, 64, 175], folga: [100, 110, 130] };
      doc.setTextColor(...(tipoColorMap[tipo] || [80, 80, 80]));
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.text(TIPO_LABELS[tipo] || tipo, TH[11].x, rv);

      y += 6.5;
    });

    // Linha de rodapé da tabela (totais)
    if (y > 265) { doc.addPage(); y = 14; }
    doc.setFillColor(30, 50, 120);
    doc.rect(margin, y, W - margin * 2, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.text('TOTAL', TH[0].x, y + 5);
    doc.text(formatHoras(totalH), TH[6].x, y + 5);
    doc.text(totalHE > 0 ? formatHoras(totalHE) : '—', TH[7].x, y + 5);
    doc.setTextColor(100, 220, 160);
    doc.text(totalP > 0 ? fmt(totalP) : '—', TH[9].x, y + 5);
    doc.setTextColor(255, 230, 100);
    doc.text(fmt(totalVD), TH[10].x, y + 5);
    y += 10;
  }

  // ══════════════════════════════════════════════════════
  // LINHA DE ASSINATURA
  // ══════════════════════════════════════════════════════
  y = newPage(doc, y, 35);
  y += 8;
  doc.setDrawColor(150, 160, 180);
  const midX = W / 2;
  doc.line(margin + 10, y, midX - 8, y);
  doc.line(midX + 8, y, W - margin - 10, y);
  doc.setFontSize(7);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(120, 130, 150);
  doc.text('Assinatura do Colaborador', margin + 10, y + 4);
  doc.text('Responsável pelo Pagamento', midX + 8, y + 4);
  y += 12;

  doc.setFontSize(7);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(170, 180, 200);
  doc.text(`Recebi a importância de ${fmt(liquido)} referente ao período ${MONTHS[mes - 1]}/${ano} — ${quinzena === 1 ? '1ª' : '2ª'} Quinzena.`, W / 2, y, { align: 'center' });

  // ══════════════════════════════════════════════════════
  // RODAPÉ EM TODAS AS PÁGINAS
  // ══════════════════════════════════════════════════════
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFillColor(15, 40, 100);
    doc.rect(0, 285, W, 12, 'F');
    doc.setFillColor(59, 130, 246);
    doc.rect(0, 285, 4, 12, 'F');
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(180, 200, 240);
    doc.text(`Página ${i} de ${pageCount}`, W / 2, 291, { align: 'center' });
    doc.text('Gerado pelo sistema ConstrutorRH — Documento sem valor fiscal', W / 2, 295, { align: 'center' });
  }

  const nomeArquivo = `extrato_${(colaborador.nome || 'colaborador').replace(/\s+/g, '_').toLowerCase()}_${MONTHS[mes - 1].toLowerCase()}_${ano}_${quinzena}q.pdf`;
  doc.save(nomeArquivo);
}