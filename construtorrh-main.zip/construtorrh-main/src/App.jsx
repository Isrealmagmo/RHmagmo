import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import AppLayout from '@/components/layout/AppLayout';
import Dashboard from '@/pages/Dashboard';
import Obras from '@/pages/Obras';
import Colaboradores from '@/pages/Colaboradores';
import ControlePonto from '@/pages/ControlePonto';
import Fechamentos from '@/pages/Fechamentos.jsx';
import Provisoes from '@/pages/Provisoes';
import Premios from '@/pages/Premios.jsx';
import ValeTransporte from '@/pages/ValeTransporte';
import Pagamentos from '@/pages/Pagamentos.jsx';
import EPIs from '@/pages/EPIs';
import Atestados from '@/pages/Atestados';
import Acidentes from '@/pages/Acidentes';
import Documentos from '@/pages/Documentos';
import Solicitacoes from '@/pages/Solicitacoes';
import Relatorios from '@/pages/Relatorios.jsx';
import Configuracoes from '@/pages/Configuracoes.jsx';
import Rescisao from '@/pages/Rescisao';
import Usuarios from '@/pages/Usuarios';
import MeuPerfil from '@/pages/MeuPerfil';
import PlaybookObra from '@/pages/PlaybookObra';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-10 h-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-sm text-muted-foreground">Carregando ConstrutorRH...</p>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/obras" element={<Obras />} />
        <Route path="/playbook-obras" element={<PlaybookObra />} />
        <Route path="/colaboradores" element={<Colaboradores />} />
        <Route path="/controle-ponto" element={<ControlePonto />} />
        <Route path="/fechamentos" element={<Fechamentos />} />
        <Route path="/provisoes" element={<Provisoes />} />
        <Route path="/premios" element={<Premios />} />
        <Route path="/vale-transporte" element={<ValeTransporte />} />
        <Route path="/pagamentos" element={<Pagamentos />} />
        <Route path="/epis" element={<EPIs />} />
        <Route path="/atestados" element={<Atestados />} />
        <Route path="/acidentes" element={<Acidentes />} />
        <Route path="/documentos" element={<Documentos />} />
        <Route path="/solicitacoes" element={<Solicitacoes />} />
        <Route path="/relatorios" element={<Relatorios />} />
        <Route path="/configuracoes" element={<Configuracoes />} />
        <Route path="/rescisao" element={<Rescisao />} />
        <Route path="/usuarios" element={<Usuarios />} />
        <Route path="/meu-perfil" element={<MeuPerfil />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App