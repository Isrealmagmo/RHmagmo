import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageHeader from '@/components/ui/PageHeader';

export default function MeuPerfil() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      const me = await base44.auth.me();
      setUser(me);
      setLoading(false);
    };
    loadUser();
  }, []);

  if (loading) return <div className="text-center py-12 text-muted-foreground">Carregando...</div>;

  return (
    <div>
      <PageHeader title="Meu Perfil" icon={User} />
      <Card className="max-w-lg">
        <CardHeader><CardTitle>Informações do Usuário</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Nome</Label>
            <Input value={user?.full_name || ''} disabled className="bg-muted" />
          </div>
          <div>
            <Label>E-mail</Label>
            <Input value={user?.email || ''} disabled className="bg-muted" />
          </div>
          <div>
            <Label>Função</Label>
            <Input value={user?.role || 'user'} disabled className="bg-muted capitalize" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}