import React, { useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Building2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PontoSheetResumo({
  colaborador,
  obraIds,
  obras,
  quinzena,
  month,
  year,
  onApprove,
}) {
  const queryClient = useQueryClient();

  // Fetch registros para TODAS as obras da quinzena
   const { data: registros = [] } = useQuery({
     queryKey: ['pontos-resumo', colaborador.id, month, year, quinzena],
     queryFn: async () => {
       const allRegs = await base44.entities.RegistroPonto.filter({
         colaborador_id: colaborador.id,
         mes: month,
         ano: year,
         quinzena,
       });
       return allRegs;
     },
   });

  // Agrupar por obra
  const obrasComLancamentos = useMemo(() => {
    const grouped = {};
    registros.forEach(r => {
      if (!grouped[r.obra_id]) {
        grouped[r.obra_id] = [];
      }
      grouped[r.obra_id].push(r);
    });
    return Object.keys(grouped).map(obraId => ({
      obraId,
      registros: grouped[obraId],
      obra: obras.find(o => o.id === obraId),
    }));
  }, [registros, obras]);

  // Verificar se tudo está aprovado
  const todasAprovadas = useMemo(
    () => obrasComLancamentos.length > 0 && obrasComLancamentos.every(item =>
      item.registros.every(r => r.aprovado)
    ),
    [obrasComLancamentos]
  );

  const aprovarMutation = useMutation({
    mutationFn: async () => {
      for (const r of registros) {
        await base44.entities.RegistroPonto.update(r.id, { ...r, aprovado: true });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pontos'] });
      queryClient.invalidateQueries({ queryKey: ['pontos-aprovacao'] });
      queryClient.invalidateQueries({ queryKey: ['pontos-resumo'] });
      setTimeout(() => onApprove?.(), 500);
    },
  });

  return (
    <div className="space-y-4">
      <div className="text-sm text-muted-foreground bg-muted/50 px-3 py-2 rounded-lg">
        Resumo de lançamentos nas obras selecionadas
      </div>

      {obrasComLancamentos.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          Nenhum lançamento encontrado nesta quinzena.
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {obrasComLancamentos.map(item => (
              <div key={item.obraId} className="border rounded-lg p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-primary" />
                  <span className="font-medium">{item.obra?.nome || 'Sem obra'}</span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {item.registros.filter(r => r.presente).length} dias com presença
                  </span>
                </div>
                <div className="text-xs space-y-1 text-muted-foreground">
                  {item.registros
                    .filter(r => r.presente)
                    .map(r => (
                      <div key={r.id} className="flex justify-between">
                        <span>{new Date(r.data).toLocaleDateString('pt-BR')}</span>
                        <span className={r.aprovado ? 'text-green-600 font-medium' : ''}>
                          {r.aprovado ? '✓ Aprovado' : 'Pendente'}
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            ))}
          </div>

          {!todasAprovadas && (
            <div className="flex justify-end pt-2 border-t">
              <Button
                className="bg-green-600 hover:bg-green-700 gap-1.5"
                onClick={() => aprovarMutation.mutate()}
                disabled={aprovarMutation.isPending}
              >
                <Check className="w-4 h-4" /> Aprovar Quinzena {quinzena === 1 ? '(1ª)' : '(2ª)'}
              </Button>
            </div>
          )}

          {todasAprovadas && (
            <div className="text-xs text-green-700 bg-green-50 border border-green-200 px-3 py-2 rounded-lg text-center font-medium">
              ✓ Quinzena aprovada em todas as obras
            </div>
          )}
        </>
      )}
    </div>
  );
}