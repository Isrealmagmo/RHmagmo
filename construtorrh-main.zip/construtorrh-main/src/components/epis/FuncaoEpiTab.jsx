import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Search, Eye, Pencil, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import FuncaoEpiDialog from './FuncaoEpiDialog';

export default function FuncaoEpiTab() {
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [selectedFuncao, setSelectedFuncao] = useState(null);
  const [editingFuncao, setEditingFuncao] = useState(null);
  const queryClient = useQueryClient();

  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list(),
  });

  const { data: funcaoEpis = [] } = useQuery({
    queryKey: ['funcao_epis'],
    queryFn: () => base44.entities.FuncaoEpi.list(),
  });

  const { data: funcaoEpisDetails = [] } = useQuery({
    queryKey: ['funcao_epis_details', selectedFuncao?.id],
    queryFn: () => base44.entities.FuncaoEpi.list(),
    enabled: !!selectedFuncao,
  });

  // Agrupa EPIs por função
  const grouped = useMemo(() => {
    return funcoes.map(func => {
      const epis = funcaoEpis.filter(fe => fe.funcao_id === func.id);
      return { funcao: func, epis };
    }).filter(group => {
      if (!search) return group.epis.length > 0;
      const s = search.toLowerCase();
      return group.funcao.nome?.toLowerCase().includes(s) || group.epis.some(e => e.epi_nome?.toLowerCase().includes(s));
    });
  }, [funcoes, funcaoEpis, search]);

  return (
    <div>
      <div className="flex gap-2 mb-4 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar função ou EPI..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5">
          <Plus className="w-4 h-4" /> Adicionar EPI à Função
        </Button>
      </div>

      <div className="space-y-3">
        {grouped.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">Nenhuma função com EPIs configurados</div>
        ) : (
          grouped.map(({ funcao, epis }) => (
            <div key={funcao.id} className="bg-card border rounded-xl overflow-hidden hover:border-primary/20 transition">
              <div className="bg-slate-100 text-slate-900 px-4 py-3 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{funcao.nome}</p>
                  {funcao.cbo && <p className="text-xs text-slate-600">CBO: {funcao.cbo}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="bg-slate-200 text-slate-700 text-xs px-2 py-1 rounded">{epis.length} EPI(s)</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 gap-1 text-slate-700 hover:bg-slate-200"
                    onClick={() => {
                      setSelectedFuncao(funcao);
                      setViewerOpen(true);
                    }}
                  >
                    <Eye className="w-4 h-4" /> Visualizar
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 gap-1 text-slate-700 hover:bg-slate-200"
                    onClick={() => {
                      setEditingFuncao(funcao);
                      setDialogOpen(true);
                    }}
                  >
                    <Pencil className="w-4 h-4" /> Editar
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Dialog Visualizar EPIs */}
      <Dialog open={viewerOpen} onOpenChange={setViewerOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>EPIs da função: {selectedFuncao?.nome}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {selectedFuncao && funcaoEpisDetails.filter(fe => fe.funcao_id === selectedFuncao.id).length > 0 ? (
              funcaoEpisDetails.filter(fe => fe.funcao_id === selectedFuncao.id).map(epi => (
                <div key={epi.id} className="border rounded-lg p-3 bg-slate-50 hover:bg-slate-100 transition">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-sm">{epi.epi_nome}</p>
                      {epi.ca && <p className="text-xs text-slate-600">CA: {epi.ca}</p>}
                      {epi.requer_tamanho && <p className="text-xs text-blue-600 mt-1">✓ Requer tamanho</p>}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-6">Nenhum EPI configurado para esta função</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <FuncaoEpiDialog 
        open={dialogOpen} 
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditingFuncao(null);
        }}
        selectedFuncaoIdProp={editingFuncao?.id}
      />
      </div>
      );
      }