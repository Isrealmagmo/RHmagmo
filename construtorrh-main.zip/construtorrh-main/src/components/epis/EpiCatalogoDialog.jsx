import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Plus, Pencil, Trash2, HardHat } from 'lucide-react';

const emptyForm = { nome: '', ca: '', descricao: '', requer_tamanho: false, validade_meses: '', categoria: 'outros' };

const categoriaLabels = {
  cabeca: '🪖 Cabeça', olhos_face: '🥽 Olhos/Face', audicao: '👂 Audição',
  respiratorio: '😷 Respiratório', tronco: '🦺 Tronco', maos_bracos: '🧤 Mãos/Braços',
  pes_pernas: '👢 Pés/Pernas', queda: '🪝 Queda', outros: '📦 Outros'
};

export default function EpiCatalogoDialog({ open, onOpenChange }) {
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const queryClient = useQueryClient();

  const { data: catalogo = [] } = useQuery({ queryKey: ['epi_catalogo'], queryFn: () => base44.entities.EpiCatalogo.list() });

  const saveMutation = useMutation({
    mutationFn: (data) => editing
      ? base44.entities.EpiCatalogo.update(editing, data)
      : base44.entities.EpiCatalogo.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['epi_catalogo'] }); resetForm(); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EpiCatalogo.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['epi_catalogo'] }),
  });

  const resetForm = () => { setForm(emptyForm); setEditing(null); };

  const startEdit = (epi) => { setForm({ ...emptyForm, ...epi }); setEditing(epi.id); };

  const set = (f, v) => setForm(p => ({ ...p, [f]: v }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><HardHat className="w-5 h-5" /> Catálogo de EPIs</DialogTitle></DialogHeader>

        <div className="border rounded-lg p-4 space-y-3 bg-muted/30">
          <p className="text-sm font-semibold">{editing ? 'Editando EPI' : 'Novo EPI'}</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label>Nome do EPI *</Label>
              <Input value={form.nome} onChange={e => set('nome', e.target.value)} placeholder="Ex: Capacete de Segurança" />
            </div>
            <div>
              <Label>CA (Certificado de Aprovação)</Label>
              <Input value={form.ca} onChange={e => set('ca', e.target.value)} placeholder="Ex: 12345" />
            </div>
            <div>
              <Label>Validade (meses)</Label>
              <Input type="number" value={form.validade_meses} onChange={e => set('validade_meses', Number(e.target.value))} placeholder="Ex: 12" />
            </div>
            <div>
              <Label>Categoria</Label>
              <Select value={form.categoria} onValueChange={v => set('categoria', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(categoriaLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3 pt-5">
              <Switch checked={form.requer_tamanho} onCheckedChange={v => set('requer_tamanho', v)} />
              <Label>Requer tamanho?</Label>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            {editing && <Button variant="outline" onClick={resetForm}>Cancelar</Button>}
            <Button onClick={() => saveMutation.mutate(form)} disabled={!form.nome}>
              {editing ? 'Atualizar' : 'Adicionar ao Catálogo'}
            </Button>
          </div>
        </div>

        <div className="space-y-2 mt-2">
          <p className="text-sm font-semibold text-muted-foreground">{catalogo.length} EPI(s) cadastrado(s)</p>
          {catalogo.map(epi => (
            <div key={epi.id} className="flex items-center justify-between border rounded-lg px-3 py-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{epi.nome}</span>
                  {epi.requer_tamanho && <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded">Tamanho</span>}
                </div>
                <p className="text-xs text-muted-foreground">
                  {categoriaLabels[epi.categoria] || epi.categoria}
                  {epi.ca && ` · CA ${epi.ca}`}
                  {epi.validade_meses && ` · ${epi.validade_meses} meses`}
                </p>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => startEdit(epi)}><Pencil className="w-3.5 h-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteMutation.mutate(epi.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          ))}
          {catalogo.length === 0 && <p className="text-center text-muted-foreground text-sm py-4">Nenhum EPI cadastrado ainda</p>}
        </div>
      </DialogContent>
    </Dialog>
  );
}