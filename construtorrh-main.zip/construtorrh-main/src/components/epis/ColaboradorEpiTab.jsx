import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Pencil, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function ColaboradorEpiTab({ colaboradorId, funcaoId }) {
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const queryClient = useQueryClient();

  const { data: funcaoEpis = [] } = useQuery({
    queryKey: ['funcao_epis', funcaoId],
    queryFn: async () => {
      if (!funcaoId) return [];
      return await base44.entities.FuncaoEpi.filter({ funcao_id: funcaoId });
    },
  });

  const { data: epiRegistros = [] } = useQuery({
    queryKey: ['epi_registros', colaboradorId],
    queryFn: () => base44.entities.EpiRegistro.filter({ colaborador_id: colaboradorId }),
  });

  // Auto-criar EPIs quando função muda
  useEffect(() => {
    const autoCreateEpis = async () => {
      if (!funcaoId || !colaboradorId || funcaoEpis.length === 0) return;

      const epiosParaCriar = funcaoEpis.filter(
        fe => !epiRegistros.some(er => er.epi_catalogo_id === fe.epi_id)
      );

      for (const fe of epiosParaCriar) {
        try {
          await base44.entities.EpiRegistro.create({
            colaborador_id: colaboradorId,
            epi_catalogo_id: fe.epi_id,
            equipamento: fe.epi_nome,
            ca: fe.ca || '',
            tamanho: '',
            cor: '',
            data_entrega: new Date().toISOString().split('T')[0],
            status: 'ativo',
            pendente_compra: false,
          });
        } catch (error) {
          console.error('Erro ao auto-criar EPI:', error);
        }
      }
      
      queryClient.invalidateQueries({ queryKey: ['epi_registros'] });
    };

    autoCreateEpis();
  }, [funcaoId, funcaoEpis, colaboradorId, epiRegistros.length, queryClient]);

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.EpiRegistro.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['epi_registros'] });
      setEditingId(null);
      toast.success('EPI atualizado com sucesso!');
    },
  });

  const handleEdit = (epi) => {
    setEditingId(epi.id);
    setEditForm(epi);
  };

  const handleSave = () => {
    updateMutation.mutate({ id: editingId, data: editForm });
  };

  const handleChange = (field, value) => {
    setEditForm({ ...editForm, [field]: value });
  };

  if (!funcaoId) {
    return (
      <div className="flex items-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <AlertCircle className="w-4 h-4 text-blue-600 flex-shrink-0" />
        <p className="text-sm text-blue-700">Selecione uma função para configurar EPIs</p>
      </div>
    );
  }

  if (epiRegistros.length === 0) {
    return (
      <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
        <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
        <p className="text-sm text-amber-700">Nenhum EPI configurado para esta função</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-xs font-semibold text-muted-foreground">
        {epiRegistros.length} EPI(s) configurado(s) para a função
      </p>

      <div className="space-y-2">
        {epiRegistros.map(epi => (
          <div key={epi.id}>
            {editingId === epi.id ? (
              <div className="border rounded-lg p-3 space-y-2 bg-blue-50">
                <p className="text-sm font-semibold mb-2">{epi.equipamento}</p>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <Label className="text-xs font-medium">Tamanho</Label>
                    <Input
                      value={editForm.tamanho || ''}
                      onChange={(e) => handleChange('tamanho', e.target.value)}
                      placeholder="PP, P, M..."
                      className="mt-1 h-7 text-xs"
                    />
                  </div>
                  <div>
                    <Label className="text-xs font-medium">Cor</Label>
                    <Input
                      value={editForm.cor || ''}
                      onChange={(e) => handleChange('cor', e.target.value)}
                      placeholder="Ex: Preto"
                      className="mt-1 h-7 text-xs"
                    />
                  </div>
                  <div>
                    <Label className="text-xs font-medium">Entrega</Label>
                    <Input
                      type="date"
                      value={editForm.data_entrega || ''}
                      onChange={(e) => handleChange('data_entrega', e.target.value)}
                      className="mt-1 h-7 text-xs"
                    />
                  </div>
                </div>
                <div className="flex gap-2 pt-1">
                  <Button size="sm" onClick={handleSave} className="flex-1 h-7 text-xs">
                    Salvar
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setEditingId(null)} className="flex-1 h-7 text-xs">
                    Cancelar
                  </Button>
                </div>
              </div>
            ) : (
              <div className="border rounded-lg p-3 flex items-center justify-between hover:bg-slate-50 transition">
                <div className="flex-1">
                  <p className="text-sm font-semibold">{epi.equipamento}</p>
                  {epi.ca && <p className="text-xs text-muted-foreground">CA: {epi.ca}</p>}
                </div>
                <div className="text-right space-y-0.5 mr-3">
                  {funcaoEpis.find(fe => fe.epi_id === epi.epi_catalogo_id)?.requer_tamanho && (
                    <>
                      <div className="text-xs">
                        <span className="text-muted-foreground">Tamanho:</span>
                        <span className="font-medium ml-1">{epi.tamanho || '—'}</span>
                      </div>
                      <div className="text-xs">
                        <span className="text-muted-foreground">Cor:</span>
                        <span className="font-medium ml-1">{epi.cor || '—'}</span>
                      </div>
                    </>
                  )}
                  <div className="text-xs">
                    <span className="text-muted-foreground">Entrega:</span>
                    <span className="font-medium ml-1">
                      {epi.data_entrega ? new Date(epi.data_entrega).toLocaleDateString('pt-BR') : '—'}
                    </span>
                  </div>
                </div>
                {funcaoEpis.find(fe => fe.epi_id === epi.epi_catalogo_id)?.requer_tamanho && (
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8"
                    onClick={() => handleEdit(epi)}
                  >
                    <Pencil className="w-4 h-4 text-blue-600" />
                  </Button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}