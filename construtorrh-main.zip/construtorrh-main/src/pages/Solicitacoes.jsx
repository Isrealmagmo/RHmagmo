import React from 'react';
import { MessageSquare } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';

export default function Solicitacoes() {
  return (
    <div>
      <PageHeader title="Solicitações" subtitle="Gestão de solicitações dos colaboradores" icon={MessageSquare} />
      <div className="text-center py-16">
        <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
        <p className="text-muted-foreground">Nenhuma solicitação registrada</p>
        <p className="text-xs text-muted-foreground mt-1">As solicitações dos colaboradores aparecerão aqui</p>
      </div>
    </div>
  );
}