import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { AlertTriangle, Plus, Search, Pencil, Trash2, FileHeart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';

const defaultForm = {
  colaborador_id: '', data: '', hora: '',
  tipo_acidente: 'acidente_tipico', gravidade: 'sem_afastamento',
  parte_corpo: '', descricao: '', causa: '', medidas: '',
  status: 'aberto', cat_emitida: false, testemunhas: ''
};

export default function Acidentes() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(defaultForm);
  const queryClient = useQueryClient();

  const { data: acidentes = [] } = useQuery({ queryKey: ['acidentes'], queryFn: () => base44.entities.Acidente.list() });
  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });
  const { data: atestados = [] } = useQuery({ queryKey: ['atestados'], queryFn: () => base44.entities.Atestado.list() });

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const col = colaboradores.find(c => c.id === data.colaborador_id);
      const payload = { ...data, colaborador_nome: col?.nome || '' };
      return editing
        ? base44.entities.Acidente.update(editing.id, payload)
        : base44.entities.Acidente.create(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['acidentes'] });
      setDialogOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Acidente.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['acidentes'] }),
  });

  const openNew = () => {
    setEditing(null);
    setForm(defaultForm);
    setDialogOpen(true);
  };

  const openEdit = (a) => {
    setEditing(a);
    setForm(a);
    setDialogOpen(true);
  };

  const abertos = acidentes.filter(a => a.status === 'aberto').length;
  const filtered = acidentes.filter(a =>
    !search || a.colaborador_nome?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        title="Acidentes de Trabalho"
        subtitle={`${abertos} em aberto · ${acidentes.length} total`}
        icon={AlertTriangle}
      >
        <Button onClick={openNew} className="gap-1.5">
          <Plus className="w-4 h-4" /> Registrar Acidente
        </Button>
      </PageHeader>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Buscar colaborador..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">Nenhum acidente registrado</div>
        )}
        {filtered.map(a => {
          const atestadoVinculado = atestados.find(at => at.id === a.atestado_id);
          return (
            <div key={a.id} className="bg-card border rounded-xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-red-50 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-sm">{a.colaborador_nome}</p>
                    {atestadoVinculado && (
                      <span className="flex items-center gap-1 text-xs text-blue-600 font-medium">
                        <FileHeart className="w-3 h-3" /> Atestado vinculado
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {a.tipo_acidente?.replace(/_/g, ' ')} · {a.data}
                    {a.hora && ` às ${a.hora}`}
                    {atestadoVinculado && ` · ${atestadoVinculado.dias || 0} dia(s) afastamento`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={a.gravidade} />
                <StatusBadge status={a.status} />
                <Button variant="ghost" size="icon" onClick={() => openEdit(a)}>
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive"
                  onClick={() => deleteMutation.mutate(a.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? 'Editar Acidente' : 'Registrar Acidente'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={form.colaborador_id} onValueChange={v => setForm({ ...form, colaborador_id: v })}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>
                  {colaboradores.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Data *</Label>
                <Input type="date" value={form.data} onChange={e => setForm({ ...form, data: e.target.value })} />
              </div>
              <div>
                <Label>Hora</Label>
                <Input type="time" value={form.hora} onChange={e => setForm({ ...form, hora: e.target.value })} />
              </div>
            </div>
            <Select value={form.tipo_acidente} onValueChange={v => setForm({ ...form, tipo_acidente: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="acidente_tipico">Acidente Típico</SelectItem>
                <SelectItem value="acidente_trajeto">Acidente de Trajeto</SelectItem>
                <SelectItem value="doenca_ocupacional">Doença Ocupacional</SelectItem>
              </SelectContent>
            </Select>
            <Select value={form.gravidade} onValueChange={v => setForm({ ...form, gravidade: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="sem_afastamento">Sem Afastamento</SelectItem>
                <SelectItem value="com_afastamento">Com Afastamento</SelectItem>
                <SelectItem value="obito">Óbito</SelectItem>
              </SelectContent>
            </Select>
            <div>
              <Label>Parte do corpo afetada</Label>
              <Input value={form.parte_corpo} onChange={e => setForm({ ...form, parte_corpo: e.target.value })} />
            </div>
            <div>
              <Label>Descrição do acidente</Label>
              <Textarea value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} />
            </div>
            <div>
              <Label>Causa provável</Label>
              <Input value={form.causa} onChange={e => setForm({ ...form, causa: e.target.value })} />
            </div>
            <div>
              <Label>Medidas tomadas</Label>
              <Input value={form.medidas} onChange={e => setForm({ ...form, medidas: e.target.value })} />
            </div>
            <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="aberto">Aberto</SelectItem>
                <SelectItem value="em_investigacao">Em Investigação</SelectItem>
                <SelectItem value="encerrado">Encerrado</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <Checkbox checked={form.cat_emitida} onCheckedChange={v => setForm({ ...form, cat_emitida: v })} />
              <Label>CAT Emitida</Label>
            </div>
            <div>
              <Label>Testemunhas</Label>
              <Input value={form.testemunhas} onChange={e => setForm({ ...form, testemunhas: e.target.value })} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button onClick={() => saveMutation.mutate(form)}>Salvar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}