import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { HardHat, Plus, Search, ShoppingCart, BookOpen, Link, Trash2, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';
import EpiCatalogoDialog from '@/components/epis/EpiCatalogoDialog';
import EpiCatalogoTab from '@/components/epis/EpiCatalogoTab';
import FuncaoEpiDialog from '@/components/epis/FuncaoEpiDialog';
import FuncaoEpiTab from '@/components/epis/FuncaoEpiTab';
import ListaCompraEpi from '@/components/epis/ListaCompraEpi';
import ListaPorTipoEpi from '@/components/epis/ListaPorTipoEpi';
import LoadDefaultEpiCatalogo from '@/components/epis/LoadDefaultEpiCatalogo';

const TAMANHOS = ['PP', 'P', 'M', 'G', 'GG', 'XG', 'XXG', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45'];

export default function EPIs() {
  const [mainTab, setMainTab] = useState('catalogo');
  const [colaboradorFilter, setColaboradorFilter] = useState('todos');
  const [catalogoOpen, setCatalogoOpen] = useState(false);
  const [funcaoEpiOpen, setFuncaoEpiOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [obraFilter, setObraFilter] = useState('todas');
  const [form, setForm] = useState({ colaborador_id: '', obra_id: '', epi_catalogo_id: '', equipamento: '', ca: '', tamanho: '', data_entrega: '', data_validade: '', status: 'ativo', pendente_compra: false });
  const queryClient = useQueryClient();

  const { data: epis = [] } = useQuery({ queryKey: ['epis'], queryFn: () => base44.entities.EpiRegistro.list() });
  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });
  const { data: obras = [] } = useQuery({ queryKey: ['obras'], queryFn: () => base44.entities.Obra.list() });
  const { data: catalogo = [] } = useQuery({ queryKey: ['epi_catalogo'], queryFn: () => base44.entities.EpiCatalogo.list() });

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const col = colaboradores.find(c => c.id === data.colaborador_id);
      const obra = obras.find(o => o.id === data.obra_id);
      const epiCat = catalogo.find(e => e.id === data.epi_catalogo_id);
      return base44.entities.EpiRegistro.create({
        ...data,
        colaborador_nome: col?.nome || '',
        obra_nome: obra?.nome || '',
        equipamento: epiCat?.nome || data.equipamento,
        ca: epiCat?.ca || data.ca,
      });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['epis'] }); setDialogOpen(false); resetForm(); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EpiRegistro.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['epis'] }),
  });

  const entregarMutation = useMutation({
    mutationFn: ({ id }) => base44.entities.EpiRegistro.update(id, { pendente_compra: false, data_entrega: new Date().toISOString().split('T')[0], status: 'ativo' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['epis'] }),
  });

  const resetForm = () => setForm({ colaborador_id: '', obra_id: '', epi_catalogo_id: '', equipamento: '', ca: '', tamanho: '', data_entrega: '', data_validade: '', status: 'ativo', pendente_compra: false });

  const selectedEpiCat = catalogo.find(e => e.id === form.epi_catalogo_id);

  const grouped = useMemo(() => {
    const map = {};
    const filtered = epis.filter(e => {
      if (search && !e.colaborador_nome?.toLowerCase().includes(search.toLowerCase()) && !e.equipamento?.toLowerCase().includes(search.toLowerCase())) return false;
      if (obraFilter !== 'todas' && e.obra_id !== obraFilter) return false;
      return true;
    });
    filtered.forEach(e => {
      if (!map[e.colaborador_id]) map[e.colaborador_id] = { nome: e.colaborador_nome, obra: e.obra_nome, epis: [] };
      map[e.colaborador_id].epis.push(e);
    });
    return Object.entries(map);
  }, [epis, search, obraFilter]);

  const pendentesCount = epis.filter(e => e.pendente_compra).length;

  return (
    <div>
      <PageHeader title="EPIs" subtitle={`${epis.filter(e => !e.pendente_compra).length} entrega(s) · ${pendentesCount} pendente(s) de compra`} icon={HardHat}>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5"><Plus className="w-4 h-4" /> Registrar EPI</Button>
      </PageHeader>

      <Tabs value={mainTab} onValueChange={setMainTab} className="mb-4">
         <TabsList>
           <TabsTrigger value="catalogo">Catálogo</TabsTrigger>
           <TabsTrigger value="funcoes" className="gap-1.5"><Link className="w-4 h-4" /> EPIs por Função</TabsTrigger>
           <TabsTrigger value="lista_compra" className="gap-1.5">
             <ShoppingCart className="w-4 h-4" /> Lista de Compra
             {pendentesCount > 0 && <span className="bg-yellow-500 text-white text-xs rounded-full px-1.5 py-0.5 ml-1">{pendentesCount}</span>}
           </TabsTrigger>
           <TabsTrigger value="por_tipo" className="gap-1.5">
             📋 Por Tipo
             {pendentesCount > 0 && <span className="bg-yellow-500 text-white text-xs rounded-full px-1.5 py-0.5 ml-1">{pendentesCount}</span>}
           </TabsTrigger>
         </TabsList>



        <TabsContent value="funcoes">
          <FuncaoEpiTab />
        </TabsContent>

        <TabsContent value="catalogo">
          {catalogo.length === 0 && <LoadDefaultEpiCatalogo />}
          <EpiCatalogoTab />
        </TabsContent>

        <TabsContent value="lista_compra">
           <div className="flex gap-2 mb-4 items-center flex-wrap">
             <Label className="text-sm text-muted-foreground">Obra:</Label>
             <Select value={obraFilter} onValueChange={setObraFilter}>
               <SelectTrigger className="w-48"><SelectValue placeholder="Todas as obras" /></SelectTrigger>
               <SelectContent>
                 <SelectItem value="todas">Todas as obras</SelectItem>
                 {obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}
               </SelectContent>
             </Select>
             <Label className="text-sm text-muted-foreground">Colaborador:</Label>
             <Select value={colaboradorFilter} onValueChange={setColaboradorFilter}>
               <SelectTrigger className="w-48"><SelectValue placeholder="Todos" /></SelectTrigger>
               <SelectContent>
                 <SelectItem value="todos">Todos</SelectItem>
                 {colaboradores.filter(c => c.status === 'ativo').map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}
               </SelectContent>
             </Select>
           </div>
           <ListaCompraEpi filtroObra={obraFilter} filtroColaborador={colaboradorFilter} />
         </TabsContent>

         <TabsContent value="por_tipo">
           <div className="flex gap-2 mb-4 items-center flex-wrap">
             <Label className="text-sm text-muted-foreground">Obra:</Label>
             <Select value={obraFilter} onValueChange={setObraFilter}>
               <SelectTrigger className="w-48"><SelectValue placeholder="Todas as obras" /></SelectTrigger>
               <SelectContent>
                 <SelectItem value="todas">Todas as obras</SelectItem>
                 {obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}
               </SelectContent>
             </Select>
             <Label className="text-sm text-muted-foreground">Colaborador:</Label>
             <Select value={colaboradorFilter} onValueChange={setColaboradorFilter}>
               <SelectTrigger className="w-48"><SelectValue placeholder="Todos" /></SelectTrigger>
               <SelectContent>
                 <SelectItem value="todos">Todos</SelectItem>
                 {colaboradores.filter(c => c.status === 'ativo').map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}
               </SelectContent>
             </Select>
           </div>
           <ListaPorTipoEpi filtroObra={obraFilter} filtroColaborador={colaboradorFilter} />
         </TabsContent>
      </Tabs>

      {/* Dialog Registrar EPI */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Registrar EPI</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={form.colaborador_id} onValueChange={v => setForm({...form, colaborador_id: v})}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{colaboradores.filter(c => c.status === 'ativo').map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Obra</Label>
              <Select value={form.obra_id} onValueChange={v => setForm({...form, obra_id: v})}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>EPI (do catálogo) *</Label>
              <Select value={form.epi_catalogo_id} onValueChange={v => setForm({...form, epi_catalogo_id: v, tamanho: ''})}>
                <SelectTrigger><SelectValue placeholder="Selecionar EPI..." /></SelectTrigger>
                <SelectContent>
                  {catalogo.map(e => <SelectItem key={e.id} value={e.id}>{e.nome}{e.requer_tamanho ? ' (tamanho)' : ''}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {selectedEpiCat?.requer_tamanho && (
              <div>
                <Label>Tamanho *</Label>
                <Select value={form.tamanho} onValueChange={v => setForm({...form, tamanho: v})}>
                  <SelectTrigger><SelectValue placeholder="Selecionar tamanho..." /></SelectTrigger>
                  <SelectContent>{TAMANHOS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Data Entrega</Label><Input type="date" value={form.data_entrega} onChange={e => setForm({...form, data_entrega: e.target.value})} /></div>
              <div><Label>Data Validade</Label><Input type="date" value={form.data_validade} onChange={e => setForm({...form, data_validade: e.target.value})} /></div>
            </div>
            <div className="flex items-center gap-3">
              <input type="checkbox" id="pendente" checked={form.pendente_compra} onChange={e => setForm({...form, pendente_compra: e.target.checked})} />
              <Label htmlFor="pendente" className="cursor-pointer">Pendente de compra (ainda não entregue)</Label>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button onClick={() => saveMutation.mutate(form)} disabled={!form.colaborador_id || !form.epi_catalogo_id}>Salvar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <EpiCatalogoDialog open={catalogoOpen} onOpenChange={setCatalogoOpen} />
      <FuncaoEpiDialog open={funcaoEpiOpen} onOpenChange={setFuncaoEpiOpen} />
    </div>
  );
}