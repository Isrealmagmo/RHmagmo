import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';
import { EPI_CATEGORIES } from 'https://esm.sh/v135/@base44/sdk@0.8.21/dist/index.js';

const EPI_DATA = [
  {
    category: '🥾 CALÇADOS',
    epis: [
      { nome: 'Botina PVC cano longo', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
      { nome: 'Botina bidensidade com bico de PVC', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
      { nome: 'Botina bidensidade com cadarço (nobuck)', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
      { nome: 'Botina com bico de aço', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
      { nome: 'Botina com bico composite (sem metal – eletricista)', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
      { nome: 'Bota de borracha/PVC impermeável', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
    ]
  },
  {
    category: '🧤 LUVAS',
    epis: [
      { nome: 'Luva de algodão tricotada', requer_tamanho: true, validade_meses: 6, categoria: 'maos_bracos' },
      { nome: 'Luva pigmentada (antiderrapante)', requer_tamanho: true, validade_meses: 6, categoria: 'maos_bracos' },
      { nome: 'Luva multiuso amarela', requer_tamanho: true, validade_meses: 6, categoria: 'maos_bracos' },
      { nome: 'Luva emborrachada', requer_tamanho: true, validade_meses: 6, categoria: 'maos_bracos' },
      { nome: 'Luva nitrílica com punho de malha', requer_tamanho: true, validade_meses: 6, categoria: 'maos_bracos' },
      { nome: 'Luva nitrílica total (químicos)', requer_tamanho: true, validade_meses: 6, categoria: 'maos_bracos' },
      { nome: 'Luva de raspa (couro)', requer_tamanho: true, validade_meses: 12, categoria: 'maos_bracos' },
      { nome: 'Luva de vaqueta', requer_tamanho: true, validade_meses: 12, categoria: 'maos_bracos' },
      { nome: 'Luva de raspa petroleira', requer_tamanho: true, validade_meses: 12, categoria: 'maos_bracos' },
      { nome: 'Luva térmica (para calor)', requer_tamanho: true, validade_meses: 12, categoria: 'maos_bracos' },
      { nome: 'Luva anticorte', requer_tamanho: true, validade_meses: 12, categoria: 'maos_bracos' },
    ]
  },
  {
    category: '👷 PROTEÇÃO DA CABEÇA',
    epis: [
      { nome: 'Capacete de segurança (branco)', requer_tamanho: false, validade_meses: 60, categoria: 'cabeca' },
      { nome: 'Capacete de segurança (azul)', requer_tamanho: false, validade_meses: 60, categoria: 'cabeca' },
      { nome: 'Capacete de segurança (amarelo)', requer_tamanho: false, validade_meses: 60, categoria: 'cabeca' },
      { nome: 'Capacete com jugular', requer_tamanho: false, validade_meses: 60, categoria: 'cabeca' },
      { nome: 'Capacete acoplado com abafador + viseira', requer_tamanho: false, validade_meses: 60, categoria: 'cabeca' },
    ]
  },
  {
    category: '👁️ PROTEÇÃO DOS OLHOS E FACE',
    epis: [
      { nome: 'Óculos de proteção incolor', requer_tamanho: false, validade_meses: 36, categoria: 'olhos_face' },
      { nome: 'Óculos de proteção escuro', requer_tamanho: false, validade_meses: 36, categoria: 'olhos_face' },
      { nome: 'Óculos ampla visão (tipo máscara)', requer_tamanho: false, validade_meses: 36, categoria: 'olhos_face' },
      { nome: 'Protetor facial (viseira)', requer_tamanho: false, validade_meses: 24, categoria: 'olhos_face' },
      { nome: 'Máscara de solda', requer_tamanho: false, validade_meses: 24, categoria: 'olhos_face' },
    ]
  },
  {
    category: '😷 PROTEÇÃO RESPIRATÓRIA',
    epis: [
      { nome: 'Máscara PFF1', requer_tamanho: true, validade_meses: 6, categoria: 'respiratorio' },
      { nome: 'Máscara PFF2 (com ou sem válvula)', requer_tamanho: true, validade_meses: 6, categoria: 'respiratorio' },
      { nome: 'Máscara PFF3', requer_tamanho: true, validade_meses: 6, categoria: 'respiratorio' },
      { nome: 'Respirador semifacial com filtro (poeira/químico)', requer_tamanho: true, validade_meses: 12, categoria: 'respiratorio' },
      { nome: 'Filtro químico (vapores – pintura)', requer_tamanho: false, validade_meses: 6, categoria: 'respiratorio' },
    ]
  },
  {
    category: '🔇 PROTEÇÃO AUDITIVA',
    epis: [
      { nome: 'Protetor auricular tipo plug', requer_tamanho: false, validade_meses: 12, categoria: 'audicao' },
      { nome: 'Abafador de ruído (concha)', requer_tamanho: false, validade_meses: 24, categoria: 'audicao' },
      { nome: 'Abafador acoplado ao capacete', requer_tamanho: false, validade_meses: 24, categoria: 'audicao' },
    ]
  },
  {
    category: '🦺 PROTEÇÃO DO CORPO',
    epis: [
      { nome: 'Avental de raspa', requer_tamanho: true, validade_meses: 24, categoria: 'tronco' },
      { nome: 'Avental impermeável (químico)', requer_tamanho: true, validade_meses: 24, categoria: 'tronco' },
      { nome: 'Mangote de raspa', requer_tamanho: false, validade_meses: 24, categoria: 'maos_bracos' },
      { nome: 'Mangote térmico', requer_tamanho: false, validade_meses: 24, categoria: 'maos_bracos' },
      { nome: 'Perneira de raspa', requer_tamanho: false, validade_meses: 24, categoria: 'pes_pernas' },
      { nome: 'Perneira contra animais peçonhentos', requer_tamanho: false, validade_meses: 24, categoria: 'pes_pernas' },
      { nome: 'Colete refletivo', requer_tamanho: true, validade_meses: 36, categoria: 'tronco' },
    ]
  },
  {
    category: '🧗 TRABALHO EM ALTURA',
    epis: [
      { nome: 'Cinto de segurança tipo paraquedista', requer_tamanho: true, validade_meses: 60, categoria: 'queda' },
      { nome: 'Talabarte simples', requer_tamanho: false, validade_meses: 60, categoria: 'queda' },
      { nome: 'Talabarte duplo (Y)', requer_tamanho: false, validade_meses: 60, categoria: 'queda' },
      { nome: 'Trava-quedas', requer_tamanho: false, validade_meses: 60, categoria: 'queda' },
      { nome: 'Linha de vida (horizontal/vertical)', requer_tamanho: false, validade_meses: 60, categoria: 'queda' },
      { nome: 'Conectores (mosquetão)', requer_tamanho: false, validade_meses: 60, categoria: 'queda' },
    ]
  },
  {
    category: '🧴 PROTEÇÃO COMPLEMENTAR',
    epis: [
      { nome: 'Protetor solar', requer_tamanho: false, validade_meses: 12, categoria: 'outros' },
      { nome: 'Creme protetor para mãos (graxa/óleo/químico)', requer_tamanho: false, validade_meses: 12, categoria: 'outros' },
      { nome: 'Hidratante de pele ocupacional', requer_tamanho: false, validade_meses: 12, categoria: 'outros' },
    ]
  },
  {
    category: '⚡ EPIs ESPECÍFICOS',
    epis: [
      { nome: 'Luva isolante elétrica', requer_tamanho: true, validade_meses: 12, categoria: 'maos_bracos' },
      { nome: 'Manga isolante', requer_tamanho: false, validade_meses: 12, categoria: 'maos_bracos' },
      { nome: 'Tapete isolante', requer_tamanho: false, validade_meses: 24, categoria: 'outros' },
      { nome: 'Botina sem componente metálico', requer_tamanho: true, validade_meses: 12, categoria: 'pes_pernas' },
    ]
  },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    let loaded = 0;
    let skipped = 0;

    for (const category of EPI_DATA) {
      for (const epi of category.epis) {
        const existing = await base44.entities.EpiCatalogo.filter({
          nome: epi.nome,
        });
        
        if (existing.length === 0) {
          await base44.entities.EpiCatalogo.create({
            nome: epi.nome,
            requer_tamanho: epi.requer_tamanho || false,
            validade_meses: epi.validade_meses || 12,
            categoria: epi.categoria || 'outros',
            descricao: `${category.category} - ${epi.nome}`,
          });
          loaded++;
        } else {
          skipped++;
        }
      }
    }

    return Response.json({ 
      success: true,
      loaded,
      skipped,
      message: `Catálogo carregado! ${loaded} EPIs adicionados, ${skipped} já existiam.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});