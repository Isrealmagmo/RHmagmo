import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { CreditCard, Plus, Search, Trash2, RotateCcw, Lock, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';

// Tipos gerados automaticamente por Fechamentos — não podem ser excluídos diretamente
const TIPOS_BLOQUEADOS = ['quinzena'];

const TIPO_LABEL = {
  quinzena: 'Quinzena',
  fechamento: 'Fechamento',
  vale_transporte: 'Vale Transporte',
  premio: 'Prêmio',
  adiantamento: 'Adiantamento',
  rescisao: 'Rescisão',
  outros: 'Outros',
};

export default function Pagamentos() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ativos'); // padrão: ocultar cancelados
  const [tipoFilter, setTipoFilter] = useState('todos');
  const [confirmEstorno, setConfirmEstorno] = useState(null); // pagamento a estornar
  const [confirmDelete, setConfirmDelete] = useState(null);   // pagamento a excluir (após estorno)
  const [form, setForm] = useState({
    colaborador_id: '', tipo: 'adiantamento', descricao: '', valor: 0, data_pagamento: '', forma_pagamento: 'pix',
    descontar: false, observacoes: '', status: 'pendente'
  });
  const queryClient = useQueryClient();

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos'],
    queryFn: () => base44.entities.Pagamento.list('-created_date', 200),
  });
  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const col = colaboradores.find(c => c.id === data.colaborador_id);
      const hoje = new Date();

      // Se descontar, salva a data de hoje como data_desconto
      const dataDesconto = data.descontar ? hoje.toISOString().split('T')[0] : null;

      return base44.entities.Pagamento.create({ 
        ...data, 
        data_desconto: dataDesconto,
        colaborador_nome: col?.nome || '' 
      });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['pagamentos'] }); queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] }); setDialogOpen(false); setForm({ colaborador_id: '', tipo: 'adiantamento', descricao: '', valor: 0, data_pagamento: '', forma_pagamento: 'pix', descontar: false, observacoes: '', status: 'pendente' }); },
  });

  const estornarMutation = useMutation({
    mutationFn: (pag) => base44.entities.Pagamento.update(pag.id, { status: 'cancelado' }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
      setConfirmEstorno(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (pag) => {
      // Se for prêmio, retornar a pendente ao invés de excluir
      if (pag.tipo === 'premio') {
        await base44.entities.Pagamento.update(pag.id, { status: 'pendente' });
      } else {
        await base44.entities.Pagamento.delete(pag.id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
      setConfirmDelete(null);
    },
  });

  const marcarPagoMutation = useMutation({
    mutationFn: (pag) => base44.entities.Pagamento.update(pag.id, { status: 'pago', data_pagamento: pag.data_pagamento || new Date().toISOString().split('T')[0] }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['pagamentos'] }),
  });

  const totalPendente = pagamentos.filter(p => p.status === 'pendente').reduce((s, p) => s + (p.valor || 0), 0);

  const filtered = pagamentos.filter(p => {
    if (search && !p.colaborador_nome?.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusFilter === 'ativos' && p.status === 'cancelado') return false;
    if (statusFilter !== 'todos' && statusFilter !== 'ativos' && p.status !== statusFilter) return false;
    if (tipoFilter !== 'todos' && p.tipo !== tipoFilter) return false;
    return true;
  });

  const isBloqueado = (pag) => TIPOS_BLOQUEADOS.includes(pag.tipo);
  const isPago = (pag) => pag.status === 'pago';

  return (
    <div>
      <PageHeader title="Pagamentos" subtitle={`Pendente: R$ ${totalPendente.toFixed(2)}`} icon={CreditCard}>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5"><Plus className="w-4 h-4" /> Novo Pagamento</Button>
      </PageHeader>

      {/* Aviso */}
      <div className="mb-4 flex items-start gap-2 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2.5 text-xs text-blue-700">
        <Lock className="w-3.5 h-3.5 mt-0.5 shrink-0" />
        <span>Pagamentos do tipo <strong>Quinzena</strong> são gerados automaticamente por Fechamentos. Para excluí-los, primeiro <strong>estorne</strong> o lançamento aqui, depois exclua-o em Fechamentos.</span>
      </div>

      <div className="flex gap-2 mb-4 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={tipoFilter} onValueChange={setTipoFilter}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Tipo" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os tipos</SelectItem>
            {Object.entries(TIPO_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ativos">Ocultar cancelados</SelectItem>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="pendente">Pendente</SelectItem>
            <SelectItem value="pago">Pago</SelectItem>
            <SelectItem value="cancelado">Cancelado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted">
              <th className="text-left px-4 py-3 font-medium">Colaborador</th>
              <th className="text-left px-4 py-3 font-medium">Tipo</th>
              <th className="text-left px-4 py-3 font-medium">Referência</th>
              <th className="text-right px-4 py-3 font-medium">Valor</th>
              <th className="text-left px-4 py-3 font-medium">Status</th>
              <th className="text-left px-4 py-3 font-medium">Data Pgto</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Nenhum pagamento encontrado</td></tr>
            ) : (
              filtered.map(p => {
                const bloqueado = isBloqueado(p);
                const estornado = p.status === 'cancelado';
                return (
                  <tr key={p.id} className={`border-t hover:bg-muted/30 ${estornado ? 'opacity-50' : ''}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        {p.quinzena && p.data_pagamento && (
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold whitespace-nowrap ${
                            p.quinzena === 1
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-purple-100 text-purple-700'
                          }`}>
                            {p.quinzena === 1 ? '1Q' : '2Q'} · {new Date(p.data_pagamento + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }).replace('.', '')}
                          </span>
                        )}
                        <span className="font-medium">{p.colaborador_nome}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${bloqueado ? 'bg-blue-100 text-blue-700' : 'bg-muted text-muted-foreground'}`}>
                        {TIPO_LABEL[p.tipo] || p.tipo}
                        {bloqueado && <Lock className="inline w-2.5 h-2.5 ml-1 mb-0.5" />}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      <div>
                        {p.descricao || p.referencia || '-'}
                        {p.descontar && <div className="text-xs text-orange-600 font-medium">Desconto: {p.data_desconto}</div>}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right font-semibold">R$ {p.valor?.toFixed(2)}</td>
                    <td className="px-4 py-3"><StatusBadge status={p.status} /></td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {p.data_pagamento
                        ? new Date(p.data_pagamento + 'T00:00:00').toLocaleDateString('pt-BR')
                        : <span className="text-muted-foreground/50">—</span>}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1 justify-end">
                        {estornado ? null : isPago(p) ? (
                          <Button
                            size="icon" variant="ghost"
                            className="text-orange-500 hover:text-orange-700 hover:bg-orange-50 h-7 w-7"
                            title="Estornar"
                            onClick={() => setConfirmEstorno(p)}
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </Button>
                        ) : (
                          <>
                            <Button
                              size="sm" variant="outline"
                              className="gap-1 text-green-700 border-green-200 hover:bg-green-50 text-xs h-7 px-2"
                              onClick={() => marcarPagoMutation.mutate(p)}
                              disabled={marcarPagoMutation.isPending}
                            >
                              <CheckCircle2 className="w-3 h-3" /> Pago
                            </Button>
                            {bloqueado ? (
                               <Button
                                size="icon" variant="ghost"
                                className="text-orange-500 hover:text-orange-700 hover:bg-orange-50 h-7 w-7"
                                title="Estornar"
                                onClick={() => setConfirmEstorno(p)}
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                              </Button>
                            ) : (
                              <Button
                                size="sm" variant="ghost"
                                className={`h-7 w-7 ${p.tipo === 'premio' ? 'text-orange-500 hover:text-orange-700 hover:bg-orange-50' : 'text-destructive hover:text-destructive'}`}
                                onClick={() => setConfirmDelete(p)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Dialog Novo Pagamento */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Novo Pagamento Manual</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={form.colaborador_id} onValueChange={v => setForm({...form, colaborador_id: v})}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{colaboradores.filter(c => c.status === 'ativo').map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Tipo</Label>
              <Select value={form.tipo} onValueChange={v => setForm({...form, tipo: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="adiantamento">Adiantamento</SelectItem>
                  <SelectItem value="vale_transporte">Vale Transporte</SelectItem>
                  <SelectItem value="premio">Prêmio</SelectItem>
                  <SelectItem value="rescisao">Rescisão</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Descrição</Label><Input value={form.descricao} onChange={e => setForm({...form, descricao: e.target.value})} placeholder="Ex: Adiantamento de férias, Bônus por desempenho" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Valor (R$)</Label><Input type="number" value={form.valor} onChange={e => setForm({...form, valor: Number(e.target.value)})} /></div>
              <div><Label>Data Pagamento</Label><Input type="date" value={form.data_pagamento} onChange={e => setForm({...form, data_pagamento: e.target.value})} /></div>
            </div>
            <div>
              <Label>Forma de Pagamento</Label>
              <Select value={form.forma_pagamento} onValueChange={v => setForm({...form, forma_pagamento: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="transferencia">Transferência</SelectItem>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <label className="flex items-center gap-2 text-sm font-medium">
              <input
                type="checkbox"
                checked={form.descontar}
                onChange={e => setForm({...form, descontar: e.target.checked})}
              />
              Descontar no fechamento (Adiant)
            </label>
            <div><Label>Observações</Label><Input value={form.observacoes} onChange={e => setForm({...form, observacoes: e.target.value})} placeholder="Observações" /></div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending}>Salvar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirm Estorno */}
      <Dialog open={!!confirmEstorno} onOpenChange={() => setConfirmEstorno(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Estornar Pagamento</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Você está prestes a <strong>estornar</strong> o pagamento de <strong>{confirmEstorno?.colaborador_nome}</strong> — {confirmEstorno?.referencia} — R$ {confirmEstorno?.valor?.toFixed(2)}.
          </p>
          <p className="text-xs bg-orange-50 border border-orange-200 text-orange-700 rounded px-3 py-2 mt-1">
            O pagamento será marcado como <strong>cancelado</strong>. Para excluí-lo definitivamente, acesse <strong>Fechamentos</strong> e exclua o lançamento correspondente.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setConfirmEstorno(null)}>Cancelar</Button>
            <Button
              className="bg-orange-600 hover:bg-orange-700"
              onClick={() => estornarMutation.mutate(confirmEstorno)}
              disabled={estornarMutation.isPending}
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Confirmar Estorno
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirm Delete (pagamentos manuais) */}
      <Dialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{confirmDelete?.tipo === 'premio' ? 'Revogar Prêmio' : 'Excluir Pagamento'}</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            {confirmDelete?.tipo === 'premio' 
              ? `Tem certeza que deseja revogar o prêmio de ${confirmDelete?.colaborador_nome}? Ele retornará ao status "Pendente" e poderá ser editado.`
              : `Tem certeza que deseja excluir o pagamento de ${confirmDelete?.colaborador_nome} — R$ ${confirmDelete?.valor?.toFixed(2)}? Esta ação não pode ser desfeita.`}
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setConfirmDelete(null)}>Cancelar</Button>
            <Button 
              variant={confirmDelete?.tipo === 'premio' ? 'outline' : 'destructive'} 
              onClick={() => deleteMutation.mutate(confirmDelete)} 
              disabled={deleteMutation.isPending}
              className={confirmDelete?.tipo === 'premio' ? 'text-orange-600 border-orange-200 hover:bg-orange-50' : ''}
            >
              <Trash2 className="w-3.5 h-3.5 mr-1.5" /> {confirmDelete?.tipo === 'premio' ? 'Revogar' : 'Excluir'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}