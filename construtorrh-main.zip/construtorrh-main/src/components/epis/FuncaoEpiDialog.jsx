import React, { useState, useMemo, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { toast } from 'sonner';
import { Plus, ChevronDown } from 'lucide-react';

const CATEGORIA_LABELS = {
  cabeca: '👷 Proteção da Cabeça',
  olhos_face: '👁️ Proteção dos Olhos e Face',
  audicao: '🔇 Proteção Auditiva',
  respiratorio: '😷 Proteção Respiratória',
  tronco: '🦺 Proteção do Corpo',
  maos_bracos: '🧤 Luvas e Proteção de Mãos',
  pes_pernas: '🥾 Calçados e Proteção de Pernas',
  queda: '🧗 Trabalho em Altura',
  outros: '🔧 Outros',
};

export default function FuncaoEpiDialog({ open, onOpenChange, selectedFuncaoIdProp = null }) {
  const [funcaoId, setFuncaoId] = useState('');
  const [selectedEpis, setSelectedEpis] = useState([]);
  const [filtroCategoria, setFiltroCategoria] = useState('todas');
  const queryClient = useQueryClient();

  useEffect(() => {
    if (open && selectedFuncaoIdProp) {
      setFuncaoId(selectedFuncaoIdProp);
    } else if (!open) {
      setFuncaoId('');
      setSelectedEpis([]);
      setFiltroCategoria('todas');
    }
  }, [open, selectedFuncaoIdProp]);

  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list(),
  });

  const { data: catalogo = [] } = useQuery({
    queryKey: ['epi_catalogo'],
    queryFn: () => base44.entities.EpiCatalogo.list(),
  });

  const { data: funcaoEpis = [] } = useQuery({
    queryKey: ['funcao_epis'],
    queryFn: () => base44.entities.FuncaoEpi.list(),
  });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      // Delete existing EPIs for this function
      const existingEpis = funcaoEpis.filter(fe => fe.funcao_id === funcaoId);
      for (const fe of existingEpis) {
        await base44.entities.FuncaoEpi.delete(fe.id);
      }

      // Create new ones
      const results = [];
      for (const epiId of selectedEpis) {
        const epi = catalogo.find(e => e.id === epiId);
        if (epi) {
          results.push(
            base44.entities.FuncaoEpi.create({
              funcao_id: funcaoId,
              funcao_nome: funcoes.find(f => f.id === funcaoId)?.nome || '',
              epi_id: epiId,
              epi_nome: epi.nome,
              ca: epi.ca || '',
              requer_tamanho: epi.requer_tamanho || false,
            })
          );
        }
      }
      return Promise.all(results);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['funcao_epis'] });
      toast.success('EPIs vinculados à função com sucesso!');
      handleReset();
      onOpenChange(false);
    },
    onError: () => {
      toast.error('Erro ao vincular EPIs');
    },
  });

  const funcaoAtual = funcoes.find(f => f.id === funcaoId);
  const episDaFuncao = funcaoEpis.filter(fe => fe.funcao_id === funcaoId).map(fe => fe.epi_id);

  // Agrupa EPIs por categoria e filtra
  const episPorCategoria = useMemo(() => {
    const filtered = filtroCategoria === 'todas'
      ? catalogo
      : catalogo.filter(e => (e.categoria || 'outros') === filtroCategoria);
    
    const map = {};
    filtered.forEach(epi => {
      const cat = epi.categoria || 'outros';
      if (!map[cat]) map[cat] = [];
      map[cat].push(epi);
    });
    return map;
  }, [catalogo, filtroCategoria]);

  const handleReset = () => {
    setFuncaoId('');
    setSelectedEpis([]);
  };

  const handleToggleEpi = (epiId) => {
    if (selectedEpis.includes(epiId)) {
      setSelectedEpis(selectedEpis.filter(id => id !== epiId));
    } else {
      setSelectedEpis([...selectedEpis, epiId]);
    }
  };

  const handleSave = () => {
    if (!funcaoId || selectedEpis.length === 0) {
      toast.error('Selecione uma função e pelo menos um EPI');
      return;
    }
    saveMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Vincular EPIs à Função</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Função *</Label>
            <Select value={funcaoId} onValueChange={setFuncaoId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecionar função..." />
              </SelectTrigger>
              <SelectContent>
                {funcoes.map(f => (
                  <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {funcaoId && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold">Selecionar EPIs obrigatórios para {funcaoAtual?.nome}</Label>
                <div className="flex items-center gap-2">
                  <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Todas</SelectItem>
                      {Object.keys(CATEGORIA_LABELS).map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {CATEGORIA_LABELS[cat]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedEpis(catalogo.map(e => e.id))}
                  >
                    Selecionar Todos
                  </Button>
                </div>
              </div>

              <div className="border rounded-lg max-h-96 overflow-y-auto">
                {catalogo.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Nenhum EPI no catálogo</p>
                ) : (
                  Object.entries(episPorCategoria).map(([categoria, epis]) => (
                    <Collapsible key={categoria} defaultOpen>
                      <CollapsibleTrigger className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted border-b transition-colors">
                        <span className="font-semibold text-sm">
                          {CATEGORIA_LABELS[categoria] || categoria}
                        </span>
                        <ChevronDown className="w-4 h-4 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-1.5 p-4 bg-muted/30">
                        {epis.map(epi => (
                          <div key={epi.id} className="flex items-center gap-3 p-2 hover:bg-muted rounded">
                            <Checkbox
                              id={epi.id}
                              checked={selectedEpis.includes(epi.id)}
                              onCheckedChange={() => handleToggleEpi(epi.id)}
                              disabled={episDaFuncao.includes(epi.id) && !selectedEpis.includes(epi.id)}
                            />
                            <label htmlFor={epi.id} className="flex-1 cursor-pointer text-sm">
                              <div className="font-medium">{epi.nome}</div>
                              <div className="text-xs text-muted-foreground">
                                {epi.requer_tamanho && '📏 Requer tamanho'} {epi.validade_meses && `• Validade: ${epi.validade_meses} meses`}
                              </div>
                            </label>
                            {episDaFuncao.includes(epi.id) && !selectedEpis.includes(epi.id) && (
                              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Já vinculado</span>
                            )}
                          </div>
                        ))}
                      </CollapsibleContent>
                    </Collapsible>
                  ))
                )}
              </div>

              <div className="text-sm text-muted-foreground">
                {selectedEpis.length} EPI(s) selecionado(s)
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => { handleReset(); onOpenChange(false); }}>
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={!funcaoId || selectedEpis.length === 0 || saveMutation.isPending}>
              {saveMutation.isPending ? 'Vinculando...' : 'Vincular EPIs'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}