import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const TAMANHOS = ['PP', 'P', 'M', 'G', 'GG', 'XG', 'XXG', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45'];
const CORES = ['Amarelo', 'Branco', 'Azul', 'Laranja', 'Verde', 'Vermelho', 'Cinza', 'Preto', 'Natural'];

export default function ColaboradorEpiSetup({ colaboradorId, funcaoId, obraId, onComplete }) {
  const queryClient = useQueryClient();
  const [registros, setRegistros] = useState([]);

  const { data: vinculos = [] } = useQuery({
    queryKey: ['funcao_epi'],
    queryFn: () => base44.entities.FuncaoEpi.list(),
  });

  const { data: catalogo = [] } = useQuery({
    queryKey: ['epi_catalogo'],
    queryFn: () => base44.entities.EpiCatalogo.list(),
  });

  const { data: obras = [] } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list(),
  });

  const episDaFuncao = funcaoId ? vinculos.filter(v => v.funcao_id === funcaoId) : [];

  // Inicializar com EPIs da função
  useEffect(() => {
    if (funcaoId && episDaFuncao.length > 0) {
      const novos = episDaFuncao.map(v => ({
        epi_id: v.epi_id,
        epi_nome: v.epi_nome,
        ca: v.ca || '',
        requer_tamanho: v.requer_tamanho,
        tamanho: '',
        cor: '',
      }));
      setRegistros(novos);
    }
  }, [funcaoId, episDaFuncao]);

  const saveMutation = useMutation({
    mutationFn: (data) => base44.entities.EpiRegistro.create(data),
  });

  const salvarEpis = async () => {
    if (registros.length === 0) {
      toast.error('Adicione pelo menos um EPI');
      return;
    }

    // Validar se todos têm tamanho e cor preenchidos quando necessário
    const invalidos = registros.filter(r => (r.requer_tamanho && !r.tamanho) || !r.cor);
    if (invalidos.length > 0) {
      toast.error('Preenchimento obrigatório: tamanho (se necessário) e cor para todos os EPIs');
      return;
    }

    const obra = obras.find(o => o.id === obraId);
    try {
      await Promise.all(
        registros.map(r =>
          saveMutation.mutateAsync({
            colaborador_id: colaboradorId,
            obra_id: obraId || '',
            obra_nome: obra?.nome || '',
            epi_catalogo_id: r.epi_id,
            equipamento: r.epi_nome,
            ca: r.ca,
            tamanho: r.tamanho || '',
            cor: r.cor,
            pendente_compra: true,
            status: 'ativo',
          })
        )
      );
      toast.success('EPIs configurados com sucesso!');
      onComplete?.();
    } catch {
      toast.error('Erro ao salvar EPIs');
    }
  };

  const updateRegistro = (index, field, value) => {
    const novo = [...registros];
    novo[index] = { ...novo[index], [field]: value };
    setRegistros(novo);
  };

  const removeRegistro = (index) => {
    setRegistros(registros.filter((_, i) => i !== index));
  };

  if (!funcaoId || episDaFuncao.length === 0) {
    return (
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-2">
        <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
        <p className="text-sm text-blue-700">Essa função não possui EPIs obrigatórios configurados.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2">
        <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
        <div className="text-sm text-amber-700">
          <p className="font-medium">Preenchimento obrigatório de EPIs</p>
          <p className="text-xs mt-1">Configure tamanho (quando necessário) e cor para todos os EPIs da função.</p>
        </div>
      </div>

      <div className="space-y-2">
        {registros.map((r, idx) => (
          <div key={idx} className="border rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{r.epi_nome}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-destructive"
                onClick={() => removeRegistro(idx)}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>

            {r.ca && <span className="text-xs text-muted-foreground">CA {r.ca}</span>}

            <div className="grid grid-cols-2 gap-2">
              {r.requer_tamanho && (
                <div>
                  <Label className="text-xs">Tamanho *</Label>
                  <Select value={r.tamanho} onValueChange={v => updateRegistro(idx, 'tamanho', v)}>
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue placeholder="Selecionar" />
                    </SelectTrigger>
                    <SelectContent>
                      {TAMANHOS.map(t => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div>
                <Label className="text-xs">Cor *</Label>
                <Select value={r.cor} onValueChange={v => updateRegistro(idx, 'cor', v)}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Selecionar" />
                  </SelectTrigger>
                  <SelectContent>
                    {CORES.map(c => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Button onClick={salvarEpis} className="w-full" disabled={saveMutation.isPending}>
        {saveMutation.isPending ? 'Salvando...' : 'Concluir Cadastro'}
      </Button>
    </div>
  );
}