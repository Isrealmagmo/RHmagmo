import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Pencil, Trash2, Shield } from 'lucide-react';

const emptyFuncao = { nome: '', cbo: '', cbo_numero: '', piso_autonomo: 0, piso_clt: 0, descricao: '' };

export default function FuncoesDialog({ open, onOpenChange }) {
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyFuncao);
  const [showForm, setShowForm] = useState(false);
  const queryClient = useQueryClient();

  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list(),
  });

  const { data: funcaoEpis = [] } = useQuery({
    queryKey: ['funcao_epis'],
    queryFn: () => base44.entities.FuncaoEpi.list(),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editing
      ? base44.entities.Funcao.update(editing.id, data)
      : base44.entities.Funcao.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['funcoes'] });
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Funcao.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['funcoes'] }),
  });

  const resetForm = () => { setForm(emptyFuncao); setEditing(null); setShowForm(false); };

  const startEdit = (f) => {
    setEditing(f);
    setForm({ nome: f.nome || '', cbo: f.cbo || '', cbo_numero: f.cbo_numero || '', piso_autonomo: f.piso_autonomo || 0, piso_clt: f.piso_clt || 0, descricao: f.descricao || '' });
    setShowForm(true);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Funções e Cargos</DialogTitle>
            <Button size="sm" onClick={() => { resetForm(); setShowForm(true); }}>
              <Plus className="w-3 h-3 mr-1" /> Nova Função
            </Button>
          </div>
        </DialogHeader>

        {showForm && (
          <div className="border rounded-lg p-4 space-y-3 bg-muted/30">
            <p className="text-sm font-semibold">{editing ? 'Editar Função' : 'Nova Função'}</p>
            <div><Label>Nome *</Label><Input value={form.nome} onChange={e => setForm({...form, nome: e.target.value})} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>CBO</Label><Input value={form.cbo} onChange={e => setForm({...form, cbo: e.target.value})} /></div>
              <div><Label>Nº CBO</Label><Input value={form.cbo_numero} onChange={e => setForm({...form, cbo_numero: e.target.value})} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Piso Autônomo (R$/hora)</Label><Input type="number" step="0.01" value={form.piso_autonomo} onChange={e => setForm({...form, piso_autonomo: Number(e.target.value)})} /></div>
              <div><Label>Piso CLT (R$/hora)</Label><Input type="number" step="0.01" value={form.piso_clt} onChange={e => setForm({...form, piso_clt: Number(e.target.value)})} /></div>
            </div>
            <div><Label>Descrição</Label><Textarea value={form.descricao} onChange={e => setForm({...form, descricao: e.target.value})} /></div>
            
            {editing && (
              <div className="border-t pt-3 mt-3">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-primary" />
                  <Label className="text-sm font-semibold">EPIs Obrigatórios</Label>
                </div>
                {funcaoEpis.filter(fe => fe.funcao_id === editing.id).length === 0 ? (
                  <p className="text-xs text-muted-foreground italic">Nenhum EPI configurado para esta função</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {funcaoEpis.filter(fe => fe.funcao_id === editing.id).map(fe => (
                      <span key={fe.id} className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">
                        {fe.epi_nome}
                      </span>
                    ))}
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  Gerencie EPIs na aba "EPIs por Função" → "Adicionar EPI à Função"
                </p>
              </div>
            )}
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={resetForm}>Cancelar</Button>
              <Button size="sm" onClick={() => saveMutation.mutate(form)} disabled={!form.nome}>Salvar</Button>
            </div>
          </div>
        )}

        <div className="space-y-2">
          {funcoes.map(f => (
            <div key={f.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-semibold text-sm">{f.nome}</p>
                <p className="text-xs text-muted-foreground">
                  {[f.cbo && `(${f.cbo})`, f.cbo_numero, f.piso_autonomo && `Aut. R$${f.piso_autonomo}/h`, f.piso_clt && `CLT R$${f.piso_clt}/h`].filter(Boolean).join(' · ')}
                </p>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => startEdit(f)}><Pencil className="w-3 h-3" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteMutation.mutate(f.id)}><Trash2 className="w-3 h-3" /></Button>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}