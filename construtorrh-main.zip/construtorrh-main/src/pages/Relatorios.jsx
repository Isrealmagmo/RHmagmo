import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  FileText, Download, Search, Filter, BarChart2, Users, Building2, Briefcase, Calendar,
  ChevronDown, ChevronUp, TrendingUp, DollarSign, Clock, Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import PageHeader from '@/components/ui/PageHeader';
import { calcTotaisColaborador, calcINSS, formatHoras } from '@/lib/pontoCalc';
import { gerarRelatorioColaboradorPDF, gerarRelatorioGerencialPDF } from '@/components/relatorios/RelatoriosPDF';

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const MONTHS_SHORT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

function fmt(v) { return `R$ ${Number(v||0).toFixed(2)}`; }

export default function Relatorios() {
  const now = new Date();
  const [aba, setAba] = useState('colaborador');
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [quinzena, setQuinzena] = useState('todas');
  const [search, setSearch] = useState('');
  const [filterObra, setFilterObra] = useState('todas');
  const [filterFuncao, setFilterFuncao] = useState('todas');
  const [filterContrato, setFilterContrato] = useState('todos');
  const [periodoTipo, setPeriodoTipo] = useState('mes'); // 'mes' | 'quinzena' | 'periodo'
  const [dataInicio, setDataInicio] = useState(`${year}-${String(month).padStart(2,'0')}-01`);
  const [dataFim, setDataFim] = useState(`${year}-${String(month).padStart(2,'0')}-31`);
  const [expandido, setExpandido] = useState({});

  // Data fetching
  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });
  const { data: funcoes = [] } = useQuery({ queryKey: ['funcoes'], queryFn: () => base44.entities.Funcao.list() });
  const { data: obras = [] } = useQuery({ queryKey: ['obras'], queryFn: () => base44.entities.Obra.list() });
  const { data: registros = [], isLoading: loadingRegistros } = useQuery({
    queryKey: ['pontos-rel', month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: month, ano: year }),
  });
  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-rel', month, year],
    queryFn: () => base44.entities.Pagamento.filter({ mes: month, ano: year }),
  });
  const { data: premios = [] } = useQuery({
    queryKey: ['premios-rel'],
    queryFn: () => base44.entities.Premio.list(),
  });
  const { data: vtLancamentos = [] } = useQuery({
    queryKey: ['vt-rel', month, year],
    queryFn: () => base44.entities.ValeTransporteLancamento.filter({ mes: month, ano: year }),
  });
  const { data: configs = [] } = useQuery({ queryKey: ['configs'], queryFn: () => base44.entities.ConfiguracaoSistema.list() });

  const configClt = useMemo(() => {
    const cfg = configs.find(c => c.chave === 'descontos_clt');
    return {
      vt_aliquota: cfg?.valor?.vt_aliquota ?? 0.06,
      usar_inss_progressivo: cfg?.valor?.usar_inss_progressivo ?? true,
      inss_aliquota_fixa: cfg?.valor?.inss_aliquota_fixa ?? 0.075,
      ir_aliquota: cfg?.valor?.ir_aliquota ?? 0,
    };
  }, [configs]);

  // Filtra registros por quinzena e ativo status se necessário
  const registrosFiltrados = useMemo(() => {
    let filtered = registros;
    if (quinzena !== 'todas') {
      filtered = filtered.filter(r => r.quinzena === Number(quinzena));
    }
    return filtered;
  }, [registros, quinzena]);

  // Dados por colaborador
  const dadosColaboradores = useMemo(() => {
    return colaboradores
      .filter(c => {
        if (c.status !== 'ativo') return false;
        if (search && !c.nome?.toLowerCase().includes(search.toLowerCase())) return false;
        if (filterObra !== 'todas' && c.obra_id !== filterObra) return false;
        if (filterFuncao !== 'todas' && c.funcao_id !== filterFuncao) return false;
        if (filterContrato !== 'todos' && c.tipo_contrato !== filterContrato) return false;
        return true;
      })
      .map(col => {
        const funcao = funcoes.find(f => f.id === col.funcao_id);
        const obra = obras.find(o => o.id === col.obra_id);
        const valorHora = col.tipo_contrato === 'clt'
          ? (funcao?.piso_clt || col.salario || 0)
          : (funcao?.piso_autonomo || col.salario || 0);

        const colRegs = registrosFiltrados.filter(r => r.colaborador_id === col.id);
        const totais = calcTotaisColaborador(colRegs, valorHora, col.tipo_contrato, obra);

        // Descontos
        let descontoINSS = 0, descontoVT = 0, descontoIR = 0;
        const vtPago = vtLancamentos.find(v => v.colaborador_id === col.id);
        if (vtPago) descontoVT = vtPago.valor_total || 0;
        if (col.tipo_contrato === 'clt') {
          descontoINSS = configClt.usar_inss_progressivo
            ? calcINSS(totais.totalBruto)
            : totais.totalBruto * configClt.inss_aliquota_fixa;
          if (descontoVT > 0) descontoVT = Math.min(descontoVT, totais.totalBruto * configClt.vt_aliquota);
          descontoIR = configClt.ir_aliquota > 0 ? totais.totalBruto * configClt.ir_aliquota : 0;
        }

        const adiantamentos = pagamentos.filter(p => p.colaborador_id === col.id && p.tipo === 'adiantamento' && p.descontar && p.status !== 'cancelado');
        const totalAdiant = adiantamentos.reduce((s, p) => s + (p.valor || 0), 0);
        const pagGerado = pagamentos.filter(p => p.colaborador_id === col.id && p.tipo === 'quinzena' && p.status !== 'cancelado');
        const totalPago = pagGerado.reduce((s, p) => s + (p.valor || 0), 0);

        const premiosColab = premios.filter(p => p.colaborador_id === col.id);
        const totalPremios = premiosColab.reduce((s, p) => s + (p.valor || 0), 0);

        const vtLanc = vtLancamentos.find(v => v.colaborador_id === col.id);

        const liquido = Math.max(0, totais.totalBruto - descontoINSS - descontoVT - descontoIR - totalAdiant);

        return {
          ...col,
          ...totais,
          valorHora,
          funcao_nome: funcao?.nome || col.funcao_nome || '—',
          obra_nome: obra?.nome || col.obra_nome || '—',
          descontoINSS,
          descontoVT,
          descontoIR,
          totalAdiant,
          totalPago,
          totalPremios,
          liquido,
          registros: colRegs,
          adiantamentos,
          premiosColab,
          vtLanc: vtLanc || null,
        };
      });
  }, [colaboradores, funcoes, obras, registrosFiltrados, pagamentos, premios, vtLancamentos, configClt, search, filterObra, filterFuncao, filterContrato]);

  // Agrupamento por obra
  const dadosPorObra = useMemo(() => {
    const map = {};
    dadosColaboradores.forEach(c => {
      const key = c.obra_id || 'sem_obra';
      const nome = c.obra_nome || 'Sem Obra';
      if (!map[key]) map[key] = { id: key, nome, colaboradores: [], totalBruto: 0, totalHorasNormais: 0, totalHorasExtra: 0, totalProducao: 0, liquido: 0, dias: 0 };
      map[key].colaboradores.push(c);
      map[key].totalBruto += c.totalBruto;
      map[key].totalHorasNormais += c.totalHorasNormais;
      map[key].totalHorasExtra += c.totalHorasExtra;
      map[key].totalProducao += c.totalProducao;
      map[key].liquido += c.liquido;
      map[key].dias += c.dias;
    });
    return Object.values(map).sort((a, b) => b.totalBruto - a.totalBruto);
  }, [dadosColaboradores]);

  // Agrupamento por função
  const dadosPorFuncao = useMemo(() => {
    const map = {};
    dadosColaboradores.forEach(c => {
      const key = c.funcao_id || 'sem_funcao';
      const nome = c.funcao_nome || 'Sem Função';
      if (!map[key]) map[key] = { id: key, nome, colaboradores: [], totalBruto: 0, liquido: 0, totalHorasNormais: 0, totalProducao: 0, count: 0 };
      map[key].colaboradores.push(c);
      map[key].totalBruto += c.totalBruto;
      map[key].liquido += c.liquido;
      map[key].totalHorasNormais += c.totalHorasNormais;
      map[key].totalProducao += c.totalProducao;
      map[key].count += 1;
    });
    return Object.values(map).sort((a, b) => b.totalBruto - a.totalBruto);
  }, [dadosColaboradores]);

  // Totais gerais
  const totaisGerais = useMemo(() => ({
    colaboradores: dadosColaboradores.length,
    totalBruto: dadosColaboradores.reduce((s, c) => s + c.totalBruto, 0),
    totalHorasNormais: dadosColaboradores.reduce((s, c) => s + c.totalHorasNormais, 0),
    totalHorasExtra: dadosColaboradores.reduce((s, c) => s + c.totalHorasExtra, 0),
    totalProducao: dadosColaboradores.reduce((s, c) => s + c.totalProducao, 0),
    totalDescontoINSS: dadosColaboradores.reduce((s, c) => s + c.descontoINSS, 0),
    totalDescontoVT: dadosColaboradores.reduce((s, c) => s + c.descontoVT, 0),
    totalAdiant: dadosColaboradores.reduce((s, c) => s + c.totalAdiant, 0),
    totalPremios: dadosColaboradores.reduce((s, c) => s + c.totalPremios, 0),
    totalLiquido: dadosColaboradores.reduce((s, c) => s + c.liquido, 0),
    dias: dadosColaboradores.reduce((s, c) => s + c.dias, 0),
  }), [dadosColaboradores]);

  const toggleExpandido = (id) => setExpandido(prev => ({ ...prev, [id]: !prev[id] }));

  // ── PDF handlers ──────────────────────────────────────────────────────────────
  const handlePDFColaborador = (c) => {
    gerarRelatorioColaboradorPDF({
      colaborador: c, registros: c.registros, adiantamentos: c.adiantamentos,
      premios: c.premiosColab, vtLancamento: c.vtLanc,
      descontoINSS: c.descontoINSS, descontoVT: c.descontoVT, descontoIR: c.descontoIR,
      liquido: c.liquido, totalBruto: c.totalBruto,
      totalHorasNormais: c.totalHorasNormais, totalHorasExtra: c.totalHorasExtra,
      totalProducao: c.totalProducao, mes: month, ano: year, quinzena,
    });
  };

  const handlePDFGerencial = (tipo, dados, titulo) => {
    gerarRelatorioGerencialPDF({ tipo, dados, titulo, totaisGerais, mes: month, ano: year, quinzena });
  };

  const handlePDFTodos = () => {
    dadosColaboradores.forEach(c => handlePDFColaborador(c));
  };

  return (
    <div>
      <PageHeader title="Relatórios" subtitle="Análise completa de ponto, produção e pagamentos" icon={BarChart2}>
        <Button
          className="gap-1.5 bg-blue-700 hover:bg-blue-800"
          onClick={() => handlePDFGerencial('geral', dadosColaboradores, `Relatório Geral — ${MONTHS[month-1]}/${year}`)}
        >
          <Download className="w-4 h-4" /> PDF Gerencial
        </Button>
      </PageHeader>

      {/* Filtros globais */}
      <div className="bg-card border rounded-xl p-4 mb-5 space-y-3">
        <div className="flex flex-wrap gap-2 items-center">
          <Select value={periodoTipo} onValueChange={setPeriodoTipo}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="mes">Por Mês</SelectItem>
              <SelectItem value="quinzena">Por Quinzena</SelectItem>
            </SelectContent>
          </Select>
          <Select value={String(month)} onValueChange={v => setMonth(Number(v))}>
            <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
            <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i} value={String(i+1)}>{m}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={String(year)} onValueChange={v => setYear(Number(v))}>
            <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
            <SelectContent>{[2024,2025,2026,2027].map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
          </Select>
          {periodoTipo === 'quinzena' && (
            <Select value={quinzena} onValueChange={setQuinzena}>
              <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as Quinzenas</SelectItem>
                <SelectItem value="1">1ª Quinzena (1–15)</SelectItem>
                <SelectItem value="2">2ª Quinzena (16–fim)</SelectItem>
              </SelectContent>
            </Select>
          )}
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={filterObra} onValueChange={setFilterObra}>
            <SelectTrigger className="w-44"><SelectValue placeholder="Todas as obras" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as Obras</SelectItem>
              {obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterFuncao} onValueChange={setFilterFuncao}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Todas as funções" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as Funções</SelectItem>
              {funcoes.map(f => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterContrato} onValueChange={setFilterContrato}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">CLT + Autônomo</SelectItem>
              <SelectItem value="clt">Somente CLT</SelectItem>
              <SelectItem value="autonomo">Somente Autônomo</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Cards de Totais */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 mb-5">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-3">
            <p className="text-[10px] uppercase text-muted-foreground font-semibold flex items-center gap-1"><Users className="w-3 h-3"/>Colaboradores</p>
            <p className="text-xl font-bold">{totaisGerais.colaboradores}</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-slate-500">
          <CardContent className="p-3">
            <p className="text-[10px] uppercase text-muted-foreground font-semibold flex items-center gap-1"><Clock className="w-3 h-3"/>Horas Normais</p>
            <p className="text-xl font-bold">{formatHoras(totaisGerais.totalHorasNormais)}</p>
            {totaisGerais.totalHorasExtra > 0 && <p className="text-xs text-orange-600">+{formatHoras(totaisGerais.totalHorasExtra)} extra</p>}
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-3">
            <p className="text-[10px] uppercase text-muted-foreground font-semibold flex items-center gap-1"><TrendingUp className="w-3 h-3"/>Produção Total</p>
            <p className="text-xl font-bold text-green-700">{fmt(totaisGerais.totalProducao)}</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="p-3">
            <p className="text-[10px] uppercase text-muted-foreground font-semibold flex items-center gap-1"><DollarSign className="w-3 h-3"/>Total Bruto</p>
            <p className="text-xl font-bold">{fmt(totaisGerais.totalBruto)}</p>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-emerald-600">
          <CardContent className="p-3">
            <p className="text-[10px] uppercase text-muted-foreground font-semibold flex items-center gap-1"><Award className="w-3 h-3"/>Total Líquido</p>
            <p className="text-xl font-bold text-emerald-700">{fmt(totaisGerais.totalLiquido)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Abas */}
      <Tabs value={aba} onValueChange={setAba}>
        <TabsList className="mb-4 flex-wrap h-auto gap-1">
          <TabsTrigger value="colaborador" className="gap-1.5"><Users className="w-3.5 h-3.5"/>Por Colaborador</TabsTrigger>
          <TabsTrigger value="obra" className="gap-1.5"><Building2 className="w-3.5 h-3.5"/>Por Obra</TabsTrigger>
          <TabsTrigger value="funcao" className="gap-1.5"><Briefcase className="w-3.5 h-3.5"/>Por Função</TabsTrigger>
          <TabsTrigger value="geral" className="gap-1.5"><BarChart2 className="w-3.5 h-3.5"/>Resumo Geral</TabsTrigger>
        </TabsList>

        {/* ── ABA: POR COLABORADOR ─────────────────────────────────────── */}
        <TabsContent value="colaborador">
          <div className="flex justify-between items-center mb-3">
            <p className="text-sm text-muted-foreground">{dadosColaboradores.length} colaboradores · {MONTHS[month-1]}/{year}</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="gap-1.5" onClick={handlePDFTodos}>
                <Download className="w-3.5 h-3.5"/> PDF Todos ({dadosColaboradores.length})
              </Button>
            </div>
          </div>
          <div className="border rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-sidebar text-sidebar-foreground">
                  <th className="text-left px-4 py-3 font-medium">Colaborador</th>
                  <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Obra / Função</th>
                  <th className="text-right px-4 py-3 font-medium">Horas</th>
                  <th className="text-right px-4 py-3 font-medium">Produção</th>
                  <th className="text-right px-4 py-3 font-medium">Bruto</th>
                  <th className="text-right px-4 py-3 font-medium">Descontos</th>
                  <th className="text-right px-4 py-3 font-medium">Líquido</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {loadingRegistros ? (
                  <tr><td colSpan={8} className="text-center py-8 text-muted-foreground">Carregando dados...</td></tr>
                ) : dadosColaboradores.length === 0 ? (
                  <tr><td colSpan={8} className="text-center py-8 text-muted-foreground">Nenhum colaborador encontrado</td></tr>
                ) : (
                  dadosColaboradores.map(c => (
                    <React.Fragment key={c.id}>
                      <tr className="border-t hover:bg-muted/30">
                        <td className="px-4 py-3">
                          <p className="font-medium">{c.nome}</p>
                          <div className="flex gap-1 mt-0.5 flex-wrap">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${c.tipo_contrato === 'clt' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>
                              {c.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo'}
                            </span>
                            {c.chapa && <span className="text-[10px] text-muted-foreground">#{c.chapa}</span>}
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <p className="text-xs font-medium">{c.obra_nome}</p>
                          <p className="text-[11px] text-muted-foreground">{c.funcao_nome}</p>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <p className="font-medium">{formatHoras(c.totalHorasNormais)}</p>
                          {c.totalHorasExtra > 0 && <p className="text-[11px] text-orange-600">+{formatHoras(c.totalHorasExtra)} ext</p>}
                          <p className="text-[11px] text-muted-foreground">{c.dias}d</p>
                        </td>
                        <td className="px-4 py-3 text-right">
                          {c.totalProducao > 0 ? (
                            <span className="text-green-700 font-semibold">{fmt(c.totalProducao)}</span>
                          ) : <span className="text-muted-foreground">—</span>}
                        </td>
                        <td className="px-4 py-3 text-right font-semibold">{fmt(c.totalBruto)}</td>
                        <td className="px-4 py-3 text-right">
                          {(c.descontoINSS + c.descontoVT + c.descontoIR + c.totalAdiant) > 0 ? (
                            <span className="text-red-600 font-medium">- {fmt(c.descontoINSS + c.descontoVT + c.descontoIR + c.totalAdiant)}</span>
                          ) : <span className="text-muted-foreground">—</span>}
                        </td>
                        <td className="px-4 py-3 text-right font-bold text-emerald-700">{fmt(c.liquido)}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1 justify-end">
                            <Button size="sm" variant="ghost" onClick={() => toggleExpandido(c.id)} title="Detalhes">
                              {expandido[c.id] ? <ChevronUp className="w-4 h-4"/> : <ChevronDown className="w-4 h-4"/>}
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => handlePDFColaborador(c)} title="Gerar PDF">
                              <FileText className="w-4 h-4 text-blue-600"/>
                            </Button>
                          </div>
                        </td>
                      </tr>
                      {expandido[c.id] && (
                        <tr className="bg-slate-50 border-t">
                          <td colSpan={8} className="px-6 py-4">
                            <DetalheColaborador c={c} />
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))
                )}
              </tbody>
              {dadosColaboradores.length > 0 && (
                <tfoot>
                  <tr className="border-t bg-muted/70 font-bold">
                    <td className="px-4 py-2" colSpan={2}>TOTAL ({dadosColaboradores.length} colaboradores)</td>
                    <td className="px-4 py-2 text-right">{formatHoras(totaisGerais.totalHorasNormais)}</td>
                    <td className="px-4 py-2 text-right text-green-700">{fmt(totaisGerais.totalProducao)}</td>
                    <td className="px-4 py-2 text-right">{fmt(totaisGerais.totalBruto)}</td>
                    <td className="px-4 py-2 text-right text-red-600">- {fmt(totaisGerais.totalDescontoINSS + totaisGerais.totalDescontoVT + totaisGerais.totalAdiant)}</td>
                    <td className="px-4 py-2 text-right text-emerald-700">{fmt(totaisGerais.totalLiquido)}</td>
                    <td />
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </TabsContent>

        {/* ── ABA: POR OBRA ─────────────────────────────────────────────── */}
        <TabsContent value="obra">
          <div className="flex justify-between items-center mb-3">
            <p className="text-sm text-muted-foreground">{dadosPorObra.length} obras · {MONTHS[month-1]}/{year}</p>
            <Button size="sm" variant="outline" className="gap-1.5" onClick={() => handlePDFGerencial('obra', dadosPorObra, `Relatório por Obra — ${MONTHS[month-1]}/${year}`)}>
              <Download className="w-3.5 h-3.5"/> PDF por Obra
            </Button>
          </div>
          <div className="space-y-3">
            {dadosPorObra.map(obra => (
              <div key={obra.id} className="border rounded-xl overflow-hidden">
                <div
                  className="bg-sidebar text-sidebar-foreground px-4 py-3 flex items-center justify-between cursor-pointer hover:bg-sidebar/90"
                  onClick={() => toggleExpandido(obra.id)}
                >
                  <div className="flex items-center gap-3">
                    <Building2 className="w-4 h-4 opacity-70"/>
                    <div>
                      <p className="font-semibold">{obra.nome}</p>
                      <p className="text-xs opacity-70">{obra.colaboradores.length} colaboradores</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 text-right">
                    <div className="hidden md:block">
                      <p className="text-xs opacity-70">Horas</p>
                      <p className="font-semibold">{formatHoras(obra.totalHorasNormais)}</p>
                    </div>
                    <div className="hidden md:block">
                      <p className="text-xs opacity-70">Bruto</p>
                      <p className="font-semibold">{fmt(obra.totalBruto)}</p>
                    </div>
                    <div>
                      <p className="text-xs opacity-70">Líquido</p>
                      <p className="font-bold text-green-300">{fmt(obra.liquido)}</p>
                    </div>
                    {expandido[obra.id] ? <ChevronUp className="w-4 h-4"/> : <ChevronDown className="w-4 h-4"/>}
                  </div>
                </div>
                {expandido[obra.id] && (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted">
                        <th className="text-left px-4 py-2 font-medium">Colaborador</th>
                        <th className="text-left px-4 py-2 font-medium hidden md:table-cell">Função</th>
                        <th className="text-right px-4 py-2 font-medium">Horas</th>
                        <th className="text-right px-4 py-2 font-medium">Produção</th>
                        <th className="text-right px-4 py-2 font-medium">Bruto</th>
                        <th className="text-right px-4 py-2 font-medium">Líquido</th>
                        <th className="px-4 py-2"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {obra.colaboradores.map(c => (
                        <tr key={c.id} className="border-t hover:bg-muted/20">
                          <td className="px-4 py-2">
                            <p className="font-medium text-xs">{c.nome}</p>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${c.tipo_contrato === 'clt' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>
                              {c.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo'}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-xs text-muted-foreground hidden md:table-cell">{c.funcao_nome}</td>
                          <td className="px-4 py-2 text-right text-xs">{formatHoras(c.totalHorasNormais)}{c.totalHorasExtra > 0 && <span className="text-orange-600"> +{formatHoras(c.totalHorasExtra)}</span>}</td>
                          <td className="px-4 py-2 text-right text-xs text-green-700">{c.totalProducao > 0 ? fmt(c.totalProducao) : '—'}</td>
                          <td className="px-4 py-2 text-right text-xs font-semibold">{fmt(c.totalBruto)}</td>
                          <td className="px-4 py-2 text-right text-xs font-bold text-emerald-700">{fmt(c.liquido)}</td>
                          <td className="px-4 py-2">
                            <Button size="sm" variant="ghost" onClick={() => handlePDFColaborador(c)} title="PDF">
                              <FileText className="w-3.5 h-3.5 text-blue-600"/>
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="border-t bg-muted/50 font-bold text-xs">
                        <td className="px-4 py-2" colSpan={2}>Total</td>
                        <td className="px-4 py-2 text-right">{formatHoras(obra.totalHorasNormais)}</td>
                        <td className="px-4 py-2 text-right text-green-700">{fmt(obra.totalProducao)}</td>
                        <td className="px-4 py-2 text-right">{fmt(obra.totalBruto)}</td>
                        <td className="px-4 py-2 text-right text-emerald-700">{fmt(obra.liquido)}</td>
                        <td/>
                      </tr>
                    </tfoot>
                  </table>
                )}
              </div>
            ))}
          </div>
        </TabsContent>

        {/* ── ABA: POR FUNÇÃO ───────────────────────────────────────────── */}
        <TabsContent value="funcao">
          <div className="flex justify-between items-center mb-3">
            <p className="text-sm text-muted-foreground">{dadosPorFuncao.length} funções · {MONTHS[month-1]}/{year}</p>
            <Button size="sm" variant="outline" className="gap-1.5" onClick={() => handlePDFGerencial('funcao', dadosPorFuncao, `Relatório por Função — ${MONTHS[month-1]}/${year}`)}>
              <Download className="w-3.5 h-3.5"/> PDF por Função
            </Button>
          </div>
          <div className="space-y-3">
            {dadosPorFuncao.map(func => (
              <div key={func.id} className="border rounded-xl overflow-hidden">
                <div
                  className="bg-slate-700 text-white px-4 py-3 flex items-center justify-between cursor-pointer hover:bg-slate-600"
                  onClick={() => toggleExpandido(func.id)}
                >
                  <div className="flex items-center gap-3">
                    <Briefcase className="w-4 h-4 opacity-70"/>
                    <div>
                      <p className="font-semibold">{func.nome}</p>
                      <p className="text-xs opacity-70">{func.count} colaboradores</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 text-right">
                    <div className="hidden md:block">
                      <p className="text-xs opacity-70">Total Horas</p>
                      <p className="font-semibold">{formatHoras(func.totalHorasNormais)}</p>
                    </div>
                    <div className="hidden md:block">
                      <p className="text-xs opacity-70">Produção</p>
                      <p className="font-semibold">{fmt(func.totalProducao)}</p>
                    </div>
                    <div>
                      <p className="text-xs opacity-70">Bruto Total</p>
                      <p className="font-bold text-yellow-300">{fmt(func.totalBruto)}</p>
                    </div>
                    {expandido[func.id] ? <ChevronUp className="w-4 h-4"/> : <ChevronDown className="w-4 h-4"/>}
                  </div>
                </div>
                {expandido[func.id] && (
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted">
                        <th className="text-left px-4 py-2 font-medium">Colaborador</th>
                        <th className="text-left px-4 py-2 font-medium hidden md:table-cell">Obra</th>
                        <th className="text-right px-4 py-2 font-medium">Contrato</th>
                        <th className="text-right px-4 py-2 font-medium">Horas</th>
                        <th className="text-right px-4 py-2 font-medium">Bruto</th>
                        <th className="text-right px-4 py-2 font-medium">Líquido</th>
                        <th className="px-4 py-2"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {func.colaboradores.map(c => (
                        <tr key={c.id} className="border-t hover:bg-muted/20">
                          <td className="px-4 py-2 font-medium text-xs">{c.nome}</td>
                          <td className="px-4 py-2 text-xs text-muted-foreground hidden md:table-cell">{c.obra_nome}</td>
                          <td className="px-4 py-2 text-right">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${c.tipo_contrato === 'clt' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>
                              {c.tipo_contrato === 'clt' ? 'CLT' : 'Aut.'}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-right text-xs">{formatHoras(c.totalHorasNormais)}</td>
                          <td className="px-4 py-2 text-right text-xs font-semibold">{fmt(c.totalBruto)}</td>
                          <td className="px-4 py-2 text-right text-xs font-bold text-emerald-700">{fmt(c.liquido)}</td>
                          <td className="px-4 py-2">
                            <Button size="sm" variant="ghost" onClick={() => handlePDFColaborador(c)}>
                              <FileText className="w-3.5 h-3.5 text-blue-600"/>
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            ))}
          </div>
        </TabsContent>

        {/* ── ABA: RESUMO GERAL ─────────────────────────────────────────── */}
        <TabsContent value="geral">
          <div className="flex justify-end mb-3">
            <Button size="sm" variant="outline" className="gap-1.5" onClick={() => handlePDFGerencial('geral', dadosColaboradores, `Resumo Geral — ${MONTHS[month-1]}/${year}`)}>
              <Download className="w-3.5 h-3.5"/> PDF Resumo
            </Button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {/* Resumo financeiro */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Resumo Financeiro — {MONTHS[month-1]}/{year}</CardTitle></CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Total Horas Normais</span><span className="font-medium">{formatHoras(totaisGerais.totalHorasNormais)}</span></div>
                <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Total Horas Extras</span><span className="font-medium text-orange-600">{formatHoras(totaisGerais.totalHorasExtra)}</span></div>
                <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Total Produção</span><span className="font-medium text-green-700">{fmt(totaisGerais.totalProducao)}</span></div>
                <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Prêmios / Bônus</span><span className="font-medium text-purple-700">{fmt(totaisGerais.totalPremios)}</span></div>
                <div className="flex justify-between py-1 border-b font-semibold"><span>Total Bruto</span><span>{fmt(totaisGerais.totalBruto)}</span></div>
                <div className="flex justify-between py-1 border-b text-red-600"><span>(-) INSS Total</span><span>- {fmt(totaisGerais.totalDescontoINSS)}</span></div>
                <div className="flex justify-between py-1 border-b text-red-600"><span>(-) VT Total</span><span>- {fmt(totaisGerais.totalDescontoVT)}</span></div>
                <div className="flex justify-between py-1 border-b text-red-600"><span>(-) Adiantamentos</span><span>- {fmt(totaisGerais.totalAdiant)}</span></div>
                <div className="flex justify-between py-2 font-bold text-base border-t-2 text-emerald-700"><span>TOTAL LÍQUIDO</span><span>{fmt(totaisGerais.totalLiquido)}</span></div>
              </CardContent>
            </Card>

            {/* Resumo por obra */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Custo por Obra</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {dadosPorObra.map(o => (
                    <div key={o.id} className="flex items-center gap-2">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="font-medium truncate">{o.nome}</span>
                          <span className="text-muted-foreground ml-2">{o.colaboradores.length} col.</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full"
                            style={{ width: `${totaisGerais.totalBruto > 0 ? (o.totalBruto / totaisGerais.totalBruto) * 100 : 0}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-xs font-bold w-24 text-right">{fmt(o.totalBruto)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Resumo por função */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Custo por Função</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {dadosPorFuncao.map(f => (
                    <div key={f.id} className="flex items-center gap-2">
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="font-medium truncate">{f.nome}</span>
                          <span className="text-muted-foreground ml-2">{f.count} col.</span>
                        </div>
                        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-purple-500 rounded-full"
                            style={{ width: `${totaisGerais.totalBruto > 0 ? (f.totalBruto / totaisGerais.totalBruto) * 100 : 0}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-xs font-bold w-24 text-right">{fmt(f.totalBruto)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Top colaboradores */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-base">Top Colaboradores por Bruto</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[...dadosColaboradores].sort((a,b) => b.totalBruto - a.totalBruto).slice(0, 8).map((c, i) => (
                    <div key={c.id} className="flex items-center gap-2 text-xs">
                      <span className="w-5 h-5 rounded-full bg-muted flex items-center justify-center font-bold text-[10px]">{i+1}</span>
                      <span className="flex-1 truncate font-medium">{c.nome}</span>
                      <span className="text-muted-foreground">{c.obra_nome.slice(0,12)}</span>
                      <span className="font-bold w-20 text-right">{fmt(c.totalBruto)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Sub-componente de detalhe expandido
function DetalheColaborador({ c }) {
  function fmt(v) { return `R$ ${Number(v||0).toFixed(2)}`; }
  const diasPresentes = c.registros?.filter(r => r.presente).length || 0;
  const diasFaltas = c.registros?.filter(r => r.tipo === 'falta').length || 0;
  const diasAtestado = c.registros?.filter(r => r.tipo === 'atestado').length || 0;
  const diasFeriado = c.registros?.filter(r => r.tipo === 'feriado').length || 0;
  const diasFolga = c.registros?.filter(r => r.tipo === 'folga').length || 0;
  
  return (
    <div className="grid md:grid-cols-3 gap-4 text-xs">
      <div>
        <p className="font-semibold text-xs text-muted-foreground uppercase mb-2">Ponto — Dias</p>
        <div className="space-y-1">
          <div className="flex justify-between"><span>Presentes</span><span className="font-medium text-green-600">{diasPresentes}</span></div>
          {diasFaltas > 0 && <div className="flex justify-between"><span>Faltas</span><span className="font-medium text-red-600">{diasFaltas}</span></div>}
          {diasAtestado > 0 && <div className="flex justify-between"><span>Atestados</span><span className="font-medium text-orange-600">{diasAtestado}</span></div>}
          {diasFeriado > 0 && <div className="flex justify-between"><span>Feriados</span><span className="font-medium">{diasFeriado}</span></div>}
          {diasFolga > 0 && <div className="flex justify-between"><span>Folgas</span><span className="font-medium">{diasFolga}</span></div>}
        </div>
      </div>
      <div>
        <p className="font-semibold text-xs text-muted-foreground uppercase mb-2">Ponto — Horas</p>
        <div className="space-y-1">
          <div className="flex justify-between"><span>Normais</span><span className="font-medium">{formatHoras(c.totalHorasNormais)}</span></div>
          <div className="flex justify-between"><span>Extras</span><span className="font-medium text-orange-600">{formatHoras(c.totalHorasExtra)}</span></div>
          <div className="flex justify-between"><span>Valor/hora</span><span className="font-medium">{fmt(c.valorHora)}/h</span></div>
        </div>
      </div>
      <div>
        <p className="font-semibold text-xs text-muted-foreground uppercase mb-2">Financeiro</p>
        <div className="space-y-1">
          <div className="flex justify-between"><span>Bruto</span><span className="font-medium">{fmt(c.totalBruto)}</span></div>
          {c.totalProducao > 0 && <div className="flex justify-between"><span>Produção</span><span className="font-medium text-green-700">{fmt(c.totalProducao)}</span></div>}
          {c.totalPremios > 0 && <div className="flex justify-between"><span>Prêmios</span><span className="font-medium text-purple-700">{fmt(c.totalPremios)}</span></div>}
          {c.descontoINSS > 0 && <div className="flex justify-between text-red-600"><span>(-) INSS</span><span>- {fmt(c.descontoINSS)}</span></div>}
          {c.descontoVT > 0 && <div className="flex justify-between text-red-600"><span>(-) VT</span><span>- {fmt(c.descontoVT)}</span></div>}
          {c.descontoIR > 0 && <div className="flex justify-between text-red-600"><span>(-) IR</span><span>- {fmt(c.descontoIR)}</span></div>}
          {c.totalAdiant > 0 && <div className="flex justify-between text-red-600"><span>(-) Adiant.</span><span>- {fmt(c.totalAdiant)}</span></div>}
          <div className="flex justify-between font-bold border-t pt-1 text-emerald-700"><span>Líquido</span><span>{fmt(c.liquido)}</span></div>
        </div>
      </div>
      <div>
        <p className="font-semibold text-xs text-muted-foreground uppercase mb-2">Extras</p>
        <div className="space-y-1">
          {c.totalPremios > 0 && <div className="flex justify-between text-purple-700"><span>Prêmios</span><span className="font-medium">{fmt(c.totalPremios)}</span></div>}
          {c.vtLanc && <div className="flex justify-between text-cyan-700"><span>VT Recebido</span><span className="font-medium">{fmt(c.vtLanc.valor_total)}</span></div>}
          {c.pix_chave && <div className="flex justify-between"><span>PIX</span><span className="font-medium text-[10px] truncate ml-2">{c.pix_chave}</span></div>}
          {c.banco && <div className="flex justify-between"><span>Banco</span><span className="font-medium">{c.banco}</span></div>}
        </div>
      </div>
    </div>
  );
}