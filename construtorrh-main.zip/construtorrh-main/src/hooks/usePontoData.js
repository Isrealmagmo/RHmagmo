import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

/**
 * Hook para buscar TODOS os registros de ponto do colaborador em um mês/ano
 * (independente da obra), para validação de duplicidade por data
 */
export function useAllPontoData(colaboradorId, month, year) {
  return useQuery({
    queryKey: ['pontos-all', colaboradorId, month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({
      colaborador_id: colaboradorId,
      mes: month,
      ano: year,
    }),
    enabled: !!colaboradorId,
  });
}

/**
 * Hook para buscar registros de ponto de uma obra específica
 */
export function usePontoDataByObra(colaboradorId, obraId, month, year) {
  return useQuery({
    queryKey: ['pontos-obra', colaboradorId, obraId, month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({
      colaborador_id: colaboradorId,
      obra_id: obraId,
      mes: month,
      ano: year,
    }),
    enabled: !!colaboradorId && !!obraId,
  });
}