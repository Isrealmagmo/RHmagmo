import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { colaborador_id } = await req.json();

    if (!colaborador_id) {
      return Response.json({ error: 'Missing colaborador_id' }, { status: 400 });
    }

    // Buscar dados do colaborador
    const colaborador = await base44.asServiceRole.entities.Colaborador.get(colaborador_id);
    if (!colaborador || !colaborador.vt_tipo || colaborador.vt_tipo === 'sem_vt') {
      return Response.json({ error: 'Colaborador ineligible or no VT' }, { status: 400 });
    }

    // Datas de admissão
    const dataAdmissao = new Date(colaborador.data_admissao);
    const mes = dataAdmissao.getMonth() + 1;
    const ano = dataAdmissao.getFullYear();
    const diaAdmissao = dataAdmissao.getDate();

    // Determinar quinzena de admissão e gerar ordem para dias faltantes
    const diasFaltantes = diaAdmissao <= 15 ? 15 - diaAdmissao : new Date(ano, mes, 0).getDate() - diaAdmissao;
    const quinzena = diaAdmissao <= 15 ? 1 : 2;
    const valorDiario = colaborador.vt_valor_diario || 0;
    const valorVT = diasFaltantes * valorDiario;

    if (valorVT > 0) {
      // Criar ordem de pagamento para dias faltantes da quinzena
      await base44.asServiceRole.entities.Pagamento.create({
        colaborador_id,
        colaborador_nome: colaborador.nome,
        tipo: 'outros',
        descricao: `VT - Dias faltantes da ${quinzena === 1 ? '1ª' : '2ª'} quinzena (${diasFaltantes} dias)`,
        referencia: `${String(mes).padStart(2, '0')}/${ano} - ${quinzena === 1 ? '1ª' : '2ª'} Quinzena`,
        mes,
        ano,
        quinzena,
        valor: valorVT,
        descontar: false,
        status: 'pendente'
      });
    }

    return Response.json({ success: true, diasFaltantes, valorVT, message: 'VT order created for missing days' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});