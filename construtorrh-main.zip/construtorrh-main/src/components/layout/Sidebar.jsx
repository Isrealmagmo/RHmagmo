import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import {
  LayoutDashboard, Building2, Users, FileHeart, Clock, Bus, 
  CreditCard, Award, DollarSign, FileText,
  BarChart3, Settings, Users2, User, LogOut, Menu, X, HardHat
} from 'lucide-react';
import { cn } from '@/lib/utils';

const menuSections = [
  {
    title: 'PRINCIPAL',
    items: [
      { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
      { icon: Building2, label: 'Obras', path: '/obras' },
      { icon: Building2, label: 'Playbook por Obra', path: '/playbook-obras' },
      { icon: Users, label: 'Colaboradores', path: '/colaboradores' },
      { icon: FileHeart, label: 'Documentos', path: '/documentos' },
    ]
  },
  {
    title: 'PONTO & PAGAMENTO',
    items: [
      { icon: Clock, label: 'Controle de Ponto', path: '/controle-ponto' },
      { icon: Bus, label: 'Pagamento de Vale Transporte', path: '/vale-transporte' },
      { icon: FileText, label: 'Fechamentos de Ponto', path: '/fechamentos' },
      { icon: Award, label: 'Prêmios e Bônus', path: '/premios' },
      { icon: CreditCard, label: 'Pagamentos', path: '/pagamentos' },
      { icon: HardHat, label: 'EPIs', path: '/epis' },
    ]
  },
  {
    title: 'ADMIN',
    items: [
      { icon: BarChart3, label: 'Relatórios', path: '/relatorios' },
      { icon: Settings, label: 'Configurações', path: '/configuracoes' },
      { icon: Users2, label: 'Usuários', path: '/usuarios' },
    ]
  }
];

export default function Sidebar() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    base44.auth.logout();
  };

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-5 pb-6">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
            <Building2 className="w-4.5 h-4.5 text-accent-foreground" />
          </div>
          <span className="text-lg font-bold text-white tracking-tight">ConstrutorRH</span>
        </div>
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto px-3 space-y-5">
        {menuSections.map((section) => (
          <div key={section.title}>
            <p className="text-[10px] font-semibold text-sidebar-foreground/40 uppercase tracking-widest px-3 mb-1.5">
              {section.title}
            </p>
            <div className="space-y-0.5">
              {section.items.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all duration-150",
                    isActive(item.path)
                      ? "bg-sidebar-primary text-white shadow-md shadow-sidebar-primary/25"
                      : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                  )}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-sidebar-border">
        <Link
          to="/meu-perfil"
          onClick={() => setMobileOpen(false)}
          className={cn(
            "flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all",
            isActive('/meu-perfil')
              ? "bg-sidebar-primary text-white"
              : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          )}
        >
          <User className="w-4 h-4" />
          Meu Perfil
        </Link>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent w-full transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sair
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(true)}
        className="lg:hidden fixed top-3 left-3 z-50 p-2 rounded-lg bg-sidebar text-white shadow-lg"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 h-screen bg-sidebar z-50 transition-transform duration-300 w-[220px] flex-shrink-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {mobileOpen && (
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden absolute top-4 right-4 text-sidebar-foreground/70"
          >
            <X className="w-5 h-5" />
          </button>
        )}
        <SidebarContent />
      </aside>
    </>
  );
}