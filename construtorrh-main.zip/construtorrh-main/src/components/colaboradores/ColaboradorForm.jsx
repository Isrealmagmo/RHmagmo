import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Trash2, Bus, ArrowDown, ArrowUp, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import ColaboradorEpiSetup from '@/components/epis/ColaboradorEpiSetup';
import ColaboradorEpiTab from '@/components/epis/ColaboradorEpiTab';
import HistoricoChapasTab from '@/components/colaboradores/HistoricoChapasTab';
import VTTrechoModal from '@/components/colaboradores/VTTrechoModal';
import { formatCPF, formatPhone, formatPIS, formatRG } from '@/utils/formatters';
import { generateChapa } from '@/utils/chapaMaker';

const emptyForm = {
  nome: '', cpf: '', rg: '', data_nascimento: '', telefone: '', endereco: '',
  pis_nit: '', ctps_numero: '', contato_emergencia_nome: '', contato_emergencia_telefone: '',
  funcao_id: '', funcao_nome: '', tipo_contrato: 'autonomo', chapa: '',
  obra_id: '', obra_nome: '', data_admissao: '', status: 'ativo', salario: 0,
  pix_tipo: 'cpf', pix_chave: '', banco: '', agencia: '', conta: '', tipo_conta: 'corrente',
  vt_tipo: 'sem_vt', vt_cartao_numero: '', vt_trechos_ida: [], vt_trechos_volta: [], vt_valor_diario: 0,
};

const emptyTrecho = { tipo: 'onibus', valor: 0, linha: '', nome_linha: '' };

export default function ColaboradorForm({ colaborador, onSave, onCancel }) {
  const [form, setForm] = useState(emptyForm);
  const [tab, setTab] = useState(colaborador ? 'pessoal' : 'contrato');
  const [step, setStep] = useState(colaborador ? null : 1); // 1=funcao, 2=chapa, 3=obra, null=normal, 'epis'=configurar epis
  const [trechoModalOpen, setTrechoModalOpen] = useState(false);
  const [trechoEditingDirection, setTrechoEditingDirection] = useState(null);
  const [trechoEditingIndex, setTrechoEditingIndex] = useState(null);
  const [trechoBeingEdited, setTrechoBeingEdited] = useState(null);

  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list(),
  });

  const { data: obras = [] } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list(),
  });

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  useEffect(() => {
    if (colaborador) {
      setForm({
        ...emptyForm,
        ...colaborador,
        vt_trechos_ida: colaborador.vt_trechos_ida || [],
        vt_trechos_volta: colaborador.vt_trechos_volta || [],
      });
    }
  }, [colaborador]);

  const set = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleFuncaoChange = (funcaoId) => {
    const funcao = funcoes.find(f => f.id === funcaoId);
    set('funcao_id', funcaoId);
    set('funcao_nome', funcao?.nome || '');
    if (funcao) {
      const salario = form.tipo_contrato === 'clt' ? funcao.piso_clt : funcao.piso_autonomo;
      if (salario) set('salario', salario);
    }
    
    // Gera chapa automaticamente (única globalmente) com data de admissão
    const chapa = generateChapa(funcao?.nome, colaboradores, form.data_admissao);
    set('chapa', chapa);
    
    // Se está no fluxo novo (step), avança
    if (step === 1) {
      setStep(2);
    }
  };

  const handleAvancarObra = () => {
    if (!form.funcao_id || !form.data_admissao) {
      toast.error('Função e Data de Início são obrigatórios');
      return;
    }
    if (form.funcao_id && form.chapa) {
      setStep(3);
    }
  };

  const handleConcluirSetup = () => {
    if (form.funcao_id && form.chapa) {
      setStep(null);
      setTab('pessoal');
    }
  };

  const handleObraChange = (obraId) => {
    const obra = obras.find(o => o.id === obraId);
    set('obra_id', obraId === 'sem_obra' ? '' : obraId);
    set('obra_nome', obraId === 'sem_obra' ? '' : obra?.nome || '');
  };

  const addTrecho = (direction) => {
    const key = direction === 'ida' ? 'vt_trechos_ida' : 'vt_trechos_volta';
    set(key, [...form[key], { ...emptyTrecho }]);
  };

  const removeTrecho = (direction, index) => {
    const key = direction === 'ida' ? 'vt_trechos_ida' : 'vt_trechos_volta';
    set(key, form[key].filter((_, i) => i !== index));
  };

  const updateTrecho = (direction, index, field, value) => {
    const key = direction === 'ida' ? 'vt_trechos_ida' : 'vt_trechos_volta';
    const updated = [...form[key]];
    updated[index] = { ...updated[index], [field]: value };
    set(key, updated);
  };

  const calcVtTotal = () => {
    const idaTotal = (form.vt_trechos_ida || []).reduce((s, t) => s + (Number(t.valor) || 0), 0);
    const voltaTotal = (form.vt_trechos_volta || []).reduce((s, t) => s + (Number(t.valor) || 0), 0);
    return idaTotal + voltaTotal;
  };

  const handleSave = async () => {
    if (!form.nome) return;
    const vtDiario = calcVtTotal();
    const toastId = toast.loading(colaborador ? 'Atualizando colaborador...' : 'Criando colaborador...');
    
    try {
      const novoColaborador = await Promise.resolve(onSave({ ...form, vt_valor_diario: vtDiario }));
      
      // Se é um novo colaborador ou chapa mudou, registra no histórico
      if (novoColaborador?.id) {
        const chapaAnterior = colaborador?.chapa;
        const chapaNova = form.chapa;
        
        // Se chapa mudou ou é novo, registra na história
        if (!chapaAnterior || chapaAnterior !== chapaNova) {
          // Finaliza chapa anterior se existe
          if (chapaAnterior) {
            const historicoAnterior = await base44.entities.HistoricoChapa.filter({
              colaborador_id: novoColaborador.id,
              chapa: chapaAnterior,
              data_saida: { $exists: false }
            });
            
            if (historicoAnterior.length > 0) {
              await base44.entities.HistoricoChapa.update(historicoAnterior[0].id, {
                data_saida: new Date().toISOString().split('T')[0],
                ativa: false
              });
            }
          }
          
          // Cria novo registro de chapa
          await base44.entities.HistoricoChapa.create({
            colaborador_id: novoColaborador.id,
            colaborador_nome: form.nome,
            chapa: chapaNova,
            funcao_id: form.funcao_id,
            funcao_nome: form.funcao_nome,
            data_inicio: form.data_admissao,
            ativa: true
          });
        }
      }
      
      toast.success(colaborador ? 'Colaborador atualizado com sucesso!' : 'Colaborador criado com sucesso!', { id: toastId });
      if (!colaborador && novoColaborador?.id) {
        setForm(prev => ({ ...prev, id: novoColaborador.id }));
        setStep('epis');
      }
    } catch (error) {
      toast.error('Erro ao salvar colaborador', { id: toastId });
    }
  };

  const handleEditTrecho = (direction, index) => {
    setTrechoEditingDirection(direction);
    setTrechoEditingIndex(index);
    const key = direction === 'ida' ? 'vt_trechos_ida' : 'vt_trechos_volta';
    setTrechoBeingEdited(form[key][index]);
    setTrechoModalOpen(true);
  };

  const handleSaveTrecho = (updatedTrecho) => {
    updateTrecho(trechoEditingDirection, trechoEditingIndex, 'tipo', updatedTrecho.tipo);
    updateTrecho(trechoEditingDirection, trechoEditingIndex, 'valor', updatedTrecho.valor);
    updateTrecho(trechoEditingDirection, trechoEditingIndex, 'linha', updatedTrecho.linha);
    updateTrecho(trechoEditingDirection, trechoEditingIndex, 'nome_linha', updatedTrecho.nome_linha);
    setTrechoModalOpen(false);
  };

  const handleAddTrechoModal = (direction) => {
    setTrechoEditingDirection(direction);
    setTrechoEditingIndex(form[direction === 'ida' ? 'vt_trechos_ida' : 'vt_trechos_volta'].length);
    setTrechoBeingEdited({ tipo: 'onibus', valor: 0, linha: '', nome_linha: '' });
    setTrechoModalOpen(true);
  };

  const TrechoSection = ({ direction, label, icon, trechos }) => {
    const totalTrechos = trechos.reduce((s, t) => s + (Number(t.valor) || 0), 0);
    
    return (
      <div className="border rounded-lg p-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium flex items-center gap-1.5">
            {icon} {label}
          </span>
          <Button type="button" variant="outline" size="sm" onClick={() => handleAddTrechoModal(direction)}>
            <Plus className="w-3 h-3 mr-1" /> Trecho
          </Button>
        </div>
        
        {trechos.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-2">Nenhum trecho</p>
        ) : (
          <>
            {/* Listagem inline de trechos */}
            <div className="space-y-1">
              {trechos.map((t, i) => {
                const tipoEmoji = { onibus: '🚌', metro: '🚇', trem: '🚂', van: '🚐' }[t.tipo] || '🚌';
                return (
                  <div key={i} className="flex items-center gap-2 text-xs bg-muted/30 p-2 rounded border-l-2 border-primary hover:bg-muted/50 transition group cursor-pointer" onClick={() => handleEditTrecho(direction, i)}>
                    <span>{tipoEmoji}</span>
                    <span className="flex-1 font-medium">{t.nome_linha || `Linha ${t.linha || 'N/A'}`}</span>
                    <span className="font-semibold text-primary">R$ {Number(t.valor || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    <Button variant="ghost" size="icon" className="h-5 w-5 text-destructive opacity-0 group-hover:opacity-100 transition" onClick={(e) => { e.stopPropagation(); removeTrecho(direction, i); }}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                );
              })}
            </div>
            
            {/* Resumo total */}
            <div className="border-t pt-2 text-right">
              <span className="text-xs text-muted-foreground">Total {label}: </span>
              <span className="font-bold text-primary">
                R$ {totalTrechos.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </>
        )}
      </div>
    );
  };

  // Fluxo de configuração de EPIs (pós-cadastro)
  if (step === 'epis') {
    return (
      <div className="space-y-4">
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <p className="text-sm font-semibold text-green-700">✓ Colaborador criado com sucesso!</p>
          <p className="text-sm text-green-600">Agora configure os EPIs para completar o cadastro.</p>
        </div>
        
        <ColaboradorEpiSetup
          colaboradorId={form.id}
          funcaoId={form.funcao_id}
          obraId={form.obra_id}
          onComplete={() => {
            toast.success('Cadastro completo!');
            onCancel();
          }}
        />
      </div>
    );
  }

  // Fluxo de novo colaborador (setup inicial)
  if (step) {
    return (
      <div className="space-y-4">
        {step === 1 && (
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-start gap-2">
               <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
               <p className="text-sm text-blue-700">Selecione a data de início e função. A chapa será gerada automaticamente (ex: PED0326-001).</p>
             </div>
            <div>
              <Label>Data de Início *</Label>
              <Input type="date" value={form.data_admissao} onChange={e => {
                set('data_admissao', e.target.value);
                if (form.funcao_id) {
                  const funcao = funcoes.find(f => f.id === form.funcao_id);
                  const chapa = generateChapa(funcao?.nome, colaboradores, e.target.value);
                  set('chapa', chapa);
                }
              }} />
            </div>
            <div>
              <Label>Função * {!form.data_admissao && <span className="text-xs text-muted-foreground">(preenchimento bloqueado até data de início)</span>}</Label>
              <Select value={form.funcao_id} onValueChange={handleFuncaoChange} disabled={!form.data_admissao}>
                <SelectTrigger><SelectValue placeholder={!form.data_admissao ? "Preenchimento bloqueado" : "Selecionar função *"} /></SelectTrigger>
                <SelectContent>
                  {funcoes.map(f => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm font-semibold text-green-700 mb-1">✓ Função: {form.funcao_nome}</p>
              <p className="text-sm text-green-600">Chapa gerada: <span className="font-mono font-bold text-primary">{form.chapa}</span></p>
            </div>
            <Button onClick={handleAvancarObra} className="w-full">
              Avançar para Alocação de Obra
            </Button>
            <Button variant="outline" onClick={() => setStep(1)} className="w-full">
              Voltar
            </Button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm"><strong>Função:</strong> {form.funcao_nome}</p>
              <p className="text-sm"><strong>Chapa:</strong> <span className="font-mono font-bold text-primary">{form.chapa}</span></p>
            </div>
            <div>
              <Label>Obra (Opcional)</Label>
              <Select value={form.obra_id || 'sem_obra'} onValueChange={v => {
                set('obra_id', v === 'sem_obra' ? '' : v);
                set('obra_nome', v === 'sem_obra' ? '' : obras.find(o => o.id === v)?.nome || '');
              }}>
                <SelectTrigger><SelectValue placeholder="Sem obra" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sem_obra">Sem obra</SelectItem>
                  {obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleConcluirSetup} className="w-full">
              Concluir Setup e Preencer Dados
            </Button>
            <Button variant="outline" onClick={() => setStep(2)} className="w-full">
              Voltar
            </Button>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" onClick={onCancel}>Cancelar</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-6 w-full">
          <TabsTrigger value="pessoal">Dados Pessoais</TabsTrigger>
          <TabsTrigger value="contrato">Contrato</TabsTrigger>
          <TabsTrigger value="pagamento">Pagamento</TabsTrigger>
          <TabsTrigger value="vt">Vale Transp.</TabsTrigger>
          <TabsTrigger value="epis">EPIs</TabsTrigger>
          {colaborador && <TabsTrigger value="historico">Histórico Chapas</TabsTrigger>}
        </TabsList>

        <TabsContent value="pessoal" className="space-y-4 mt-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Identificação</p>
          <div>
            <Label>Nome completo *</Label>
            <Input value={form.nome} onChange={e => set('nome', e.target.value)} placeholder="Nome completo" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>CPF *</Label><Input value={form.cpf} onChange={e => set('cpf', formatCPF(e.target.value))} placeholder="000.000.000-00" /></div>
            <div><Label>RG</Label><Input value={form.rg} onChange={e => set('rg', formatRG(e.target.value))} placeholder="RG" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Data de Nascimento</Label><Input type="date" value={form.data_nascimento} onChange={e => set('data_nascimento', e.target.value)} /></div>
            <div><Label>Telefone *</Label><Input value={form.telefone} onChange={e => set('telefone', formatPhone(e.target.value))} placeholder="(11) 99999-9999" /></div>
          </div>
          <div><Label>Endereço</Label><Input value={form.endereco} onChange={e => set('endereco', e.target.value)} placeholder="Rua, número, bairro, cidade" /></div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide pt-2">Documentos Trabalhistas</p>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>PIS / NIT</Label><Input value={form.pis_nit} onChange={e => set('pis_nit', formatPIS(e.target.value))} placeholder="PIS" /></div>
            <div><Label>CTPS Nº</Label><Input value={form.ctps_numero} onChange={e => set('ctps_numero', e.target.value)} placeholder="CTPS" /></div>
          </div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide pt-2">Contato de Emergência</p>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Nome</Label><Input value={form.contato_emergencia_nome} onChange={e => set('contato_emergencia_nome', e.target.value)} placeholder="Nome do contato" /></div>
            <div><Label>Telefone</Label><Input value={form.contato_emergencia_telefone} onChange={e => set('contato_emergencia_telefone', formatPhone(e.target.value))} placeholder="Telefone" /></div>
          </div>
        </TabsContent>

        <TabsContent value="contrato" className="space-y-4 mt-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Cargo & Contrato</p>
          <div>
            <Label>Função *</Label>
            <Select value={form.funcao_id} onValueChange={handleFuncaoChange}>
              <SelectTrigger><SelectValue placeholder="Selecionar função *" /></SelectTrigger>
              <SelectContent>
                {funcoes.map(f => <SelectItem key={f.id} value={f.id}>{f.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Tipo de Contrato *</Label>
              <Select value={form.tipo_contrato} onValueChange={v => set('tipo_contrato', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="autonomo">Autônomo</SelectItem>
                  <SelectItem value="clt">CLT</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Chapa (Gerada automaticamente)</Label>
              <Input value={form.chapa} placeholder="Será gerada ao selecionar função" className="bg-muted font-mono font-bold text-primary" readOnly />
            </div>
          </div>
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide pt-2">Alocação</p>
          <div>
            <Label>Obra</Label>
            <Select value={form.obra_id || 'sem_obra'} onValueChange={handleObraChange}>
              <SelectTrigger><SelectValue placeholder="Sem obra" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="sem_obra">Sem obra</SelectItem>
                {obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Data de Admissão</Label><Input type="date" value={form.data_admissao} onChange={e => {
              set('data_admissao', e.target.value);
              if (form.funcao_id) {
                const funcao = funcoes.find(f => f.id === form.funcao_id);
                const chapa = generateChapa(funcao?.nome, colaboradores, e.target.value);
                set('chapa', chapa);
              }
            }} /></div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => set('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                  <SelectItem value="afastado">Afastado</SelectItem>
                  <SelectItem value="ferias">Férias</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="pagamento" className="space-y-4 mt-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Dados de Pagamento</p>
          <div>
            <Label>Tipo de Chave PIX</Label>
            <Select value={form.pix_tipo} onValueChange={v => set('pix_tipo', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="cpf">CPF</SelectItem>
                <SelectItem value="email">E-mail</SelectItem>
                <SelectItem value="telefone">Telefone</SelectItem>
                <SelectItem value="chave_aleatoria">Chave Aleatória</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div><Label>Chave PIX</Label><Input value={form.pix_chave} onChange={e => set('pix_chave', e.target.value)} placeholder="Chave PIX" /></div>
          <div><Label>Banco</Label><Input value={form.banco} onChange={e => set('banco', e.target.value)} placeholder="Nome do banco" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Agência</Label><Input value={form.agencia} onChange={e => set('agencia', e.target.value)} placeholder="Agência" /></div>
            <div><Label>Conta</Label><Input value={form.conta} onChange={e => set('conta', e.target.value)} placeholder="Conta" /></div>
          </div>
          <div>
            <Label>Tipo de Conta</Label>
            <Select value={form.tipo_conta} onValueChange={v => set('tipo_conta', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="corrente">Corrente</SelectItem>
                <SelectItem value="poupanca">Poupança</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </TabsContent>

        <TabsContent value="vt" className="space-y-4 mt-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Vale Transporte</p>
          <div>
            <Label>Tipo de VT</Label>
            <Select value={form.vt_tipo} onValueChange={v => set('vt_tipo', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="bilhete_unico">Bilhete Único / Integração</SelectItem>
                <SelectItem value="cartao_transporte">Cartão Transporte</SelectItem>
                <SelectItem value="dinheiro">Dinheiro</SelectItem>
                <SelectItem value="sem_vt">Sem VT</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {form.vt_tipo !== 'sem_vt' && (
            <>
              <div><Label>Nº do Cartão</Label><Input value={form.vt_cartao_numero} onChange={e => set('vt_cartao_numero', e.target.value)} placeholder="Número do cartão" /></div>
              <TrechoSection direction="ida" label="Trechos de Ida" icon={<ArrowDown className="w-3.5 h-3.5 text-blue-500" />} trechos={form.vt_trechos_ida || []} />
              <TrechoSection direction="volta" label="Trechos de Volta" icon={<ArrowUp className="w-3.5 h-3.5 text-green-500" />} trechos={form.vt_trechos_volta || []} />
              <div className="bg-primary/5 rounded-lg p-3 border border-primary/20">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-semibold">Valor Diário Total:</span>
                  <span className="text-lg font-bold text-primary">
                    R$ {calcVtTotal().toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </>
          )}
        </TabsContent>
        <TabsContent value="epis" className="space-y-4 mt-4">
          {!colaborador ? (
            <p className="text-xs text-muted-foreground italic">EPIs serão configurados após criar o colaborador.</p>
          ) : (
            <ColaboradorEpiTab
              colaboradorId={colaborador.id}
              funcaoId={form.funcao_id}
              obraId={form.obra_id}
            />
          )}
        </TabsContent>

        {colaborador && (
          <TabsContent value="historico" className="space-y-4 mt-4">
            <HistoricoChapasTab colaboradorId={colaborador.id} />
          </TabsContent>
        )}
      </Tabs>

      <p className="text-xs text-muted-foreground">* Campos obrigatórios</p>
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onCancel}>Cancelar</Button>
        <Button onClick={handleSave}>Salvar Colaborador</Button>
      </div>

      <VTTrechoModal
        open={trechoModalOpen}
        onOpenChange={setTrechoModalOpen}
        trecho={trechoBeingEdited}
        onSave={handleSaveTrecho}
      />
    </div>
  );
}