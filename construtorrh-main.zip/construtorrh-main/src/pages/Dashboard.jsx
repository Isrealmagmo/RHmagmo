import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Users, Building2, CreditCard, AlertTriangle, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';

function StatCard({ icon: Icon, value, label, color }) {
  const colorMap = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    yellow: 'bg-yellow-50 text-yellow-600',
    red: 'bg-red-50 text-red-600',
  };
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-5">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${colorMap[color] || colorMap.blue}`}>
          <Icon className="w-5 h-5" />
        </div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const { data: obras = [] } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list(),
  });

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-dash'],
    queryFn: () => base44.entities.Pagamento.filter({ status: 'pendente' }),
  });

  const { data: atestados = [] } = useQuery({
    queryKey: ['atestados-dash'],
    queryFn: () => base44.entities.Atestado.filter({ status: 'ativo' }),
  });

  const colabAtivos = colaboradores.filter(c => c.status === 'ativo');
  const obrasAndamento = obras.filter(o => o.status === 'em_andamento');

  return (
    <div>
      <PageHeader title="Dashboard" subtitle="Visão geral do sistema" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} value={colabAtivos.length} label="Colaboradores Ativos" color="blue" />
        <StatCard icon={Building2} value={obrasAndamento.length} label="Obras em Andamento" color="green" />
        <StatCard icon={CreditCard} value={pagamentos.length} label="Pagamentos Pendentes" color="yellow" />
        <StatCard icon={AlertTriangle} value={atestados.length} label="Atestados Ativos" color="red" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {/* Obras Recentes */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="w-4 h-4 text-accent" />
                Obras Recentes
              </CardTitle>
              <Link to="/obras" className="text-xs text-primary hover:underline flex items-center gap-1">
                Ver todas <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {obras.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Nenhuma obra cadastrada</p>
            ) : (
              obras.slice(0, 5).map(obra => (
                <div key={obra.id} className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <span className="text-sm font-medium">{obra.nome}</span>
                  <StatusBadge status={obra.status} />
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Colaboradores Recentes */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="w-4 h-4 text-accent" />
                Colaboradores Recentes
              </CardTitle>
              <Link to="/colaboradores" className="text-xs text-primary hover:underline flex items-center gap-1">
                Ver todos <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {colaboradores.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Nenhum colaborador cadastrado</p>
            ) : (
              colaboradores.slice(0, 5).map(col => (
                <div key={col.id} className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-muted/50 transition-colors">
                  <div>
                    <p className="text-sm font-medium">{col.nome}</p>
                    <p className="text-xs text-muted-foreground">
                      {col.funcao_nome || 'Sem função'} {col.chapa && `· ${col.chapa}`}
                    </p>
                  </div>
                  <StatusBadge status={col.status} />
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}