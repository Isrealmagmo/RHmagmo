import React, { memo } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Lock, Clock } from 'lucide-react';

function toMin(t) {
  if (!t) return 0;
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}
function calcHorasNormais(entrada, saida, saida_almoco, retorno_almoco) {
  if (!entrada || !saida) return 0;
  let total = toMin(saida) - toMin(entrada);
  if (saida_almoco && retorno_almoco) total -= (toMin(retorno_almoco) - toMin(saida_almoco));
  return Math.max(0, total / 60);
}
function calcHorasExtra(entrada_extra, saida_extra) {
  if (!entrada_extra || !saida_extra) return 0;
  return Math.max(0, (toMin(saida_extra) - toMin(entrada_extra)) / 60);
}
function getAdicionalFator(adicional) {
  if (adicional === '50_sab') return 1.5;
  if (adicional === '100_dom' || adicional === '100_fer') return 2.0;
  return 1.0;
}
function formatHoras(h) {
  if (h <= 0) return '--';
  const totalMin = Math.round(h * 60);
  const hh = Math.floor(totalMin / 60);
  const mm = totalMin % 60;
  if (mm === 0) return `${hh}h`;
  return `${hh}h${String(mm).padStart(2, '0')}`;
}

const FIELDS = ['entrada', 'saida_almoco', 'retorno_almoco', 'saida', 'entrada_extra', 'saida_extra'];

const PontoRow = memo(function PontoRow({ day, rec, isAprovada, isAutonomo, onPresenca, onUpdate, jaTemOutraObra, jaTemAtestado, getHorasObraParaDia, valorHoraAtual = 0, horasObraParaDia = 0 }) {
    const isDom = day.isDom;
    const isSab = day.isSab;
    const isLocked = isAprovada || isDom;
    const producaoDia = rec.valor_producao || 0;
    const isConflicted = jaTemOutraObra;

   const hNorm = rec.presente ? calcHorasNormais(rec.entrada, rec.saida, rec.saida_almoco, rec.retorno_almoco) : 0;
   const hExtra = rec.presente ? calcHorasExtra(rec.entrada_extra, rec.saida_extra) : 0;
   const fator = getAdicionalFator(rec.adicional);
   const hNormAj = hNorm * fator;
   const hExtraAj = hExtra * fator;

  return (
    <tr className={`${isDom ? 'bg-red-50' : isSab ? 'bg-orange-50' : 'border-b hover:bg-slate-50/50'} transition-colors`}>
      {/* Data e Status */}
      <td className={`px-3 py-2.5 font-semibold text-sm w-20 ${isDom ? 'text-red-600' : isSab ? 'text-orange-600' : 'text-foreground'}`}>
        <div className="flex items-center gap-1.5">
          <span>{String(day.day).padStart(2, '0')}</span>
          <span className={`text-xs font-normal ${isDom ? 'text-red-400' : isSab ? 'text-orange-400' : 'text-muted-foreground'}`}>{day.dayName}</span>
        </div>
      </td>

      {/* Presença/Status */}
      <td className="px-2 py-2.5 text-center w-12">
        {isDom ? (
          <span className="text-xs font-semibold text-red-500 bg-red-100 px-2 py-1 rounded">DOM</span>
        ) : isConflicted ? (
          <div title="Já lançado em outra obra"><Lock className="w-4 h-4 text-red-500 mx-auto" /></div>
        ) : (
          <Checkbox
            checked={rec.presente || false}
            disabled={isAprovada}
            onCheckedChange={checked => onPresenca(day.date, day.dayOfWeek, checked)}
            className="mx-auto"
          />
        )}
      </td>

      {/* Horários agrupados */}
      <td className="px-2 py-2.5">
        <div className="flex gap-1 items-center" title="Entrada">
          <Clock className="w-3 h-3 text-muted-foreground" />
          <Input
            className="h-7 text-xs w-16 px-1.5"
            type="time"
            placeholder="Ent"
            value={rec.entrada || ''}
            disabled={isLocked || !rec.presente}
            onChange={e => onUpdate(day.date, day.dayOfWeek, 'entrada', e.target.value)}
          />
        </div>
      </td>

      {/* Almoço */}
      <td className="px-2 py-2.5">
        <div className="flex gap-1" title="Saída/Retorno almoço">
          <Input
            className="h-7 text-xs w-14 px-1.5"
            type="time"
            placeholder="Saí"
            value={rec.saida_almoco || ''}
            disabled={isLocked || !rec.presente}
            onChange={e => onUpdate(day.date, day.dayOfWeek, 'saida_almoco', e.target.value)}
          />
          <Input
            className="h-7 text-xs w-14 px-1.5"
            type="time"
            placeholder="Ret"
            value={rec.retorno_almoco || ''}
            disabled={isLocked || !rec.presente}
            onChange={e => onUpdate(day.date, day.dayOfWeek, 'retorno_almoco', e.target.value)}
          />
        </div>
      </td>

      {/* Saída */}
      <td className="px-2 py-2.5">
        <Input
          className="h-7 text-xs w-16 px-1.5"
          type="time"
          placeholder="Saída"
          value={rec.saida || ''}
          disabled={isLocked || !rec.presente}
          onChange={e => onUpdate(day.date, day.dayOfWeek, 'saida', e.target.value)}
        />
      </td>

      {/* Extras (agrupado) */}
      <td className="px-2 py-2.5">
        <div className="flex gap-1 text-xs" title="Hora extra">
          <Input
            className="h-7 text-xs w-14 px-1.5"
            type="time"
            placeholder="Ent"
            value={rec.entrada_extra || ''}
            disabled={isLocked || !rec.presente}
            onChange={e => onUpdate(day.date, day.dayOfWeek, 'entrada_extra', e.target.value)}
          />
          <Input
            className="h-7 text-xs w-14 px-1.5"
            type="time"
            placeholder="Saí"
            value={rec.saida_extra || ''}
            disabled={isLocked || !rec.presente}
            onChange={e => onUpdate(day.date, day.dayOfWeek, 'saida_extra', e.target.value)}
          />
        </div>
      </td>

      {/* Adicional */}
      <td className="px-2 py-2.5 w-24">
        <Select
          value={rec.adicional || 'normal'}
          disabled={isLocked}
          onValueChange={v => onUpdate(day.date, day.dayOfWeek, 'adicional', v)}
        >
          <SelectTrigger className="h-7 text-xs px-1.5">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="normal">Normal</SelectItem>
            <SelectItem value="50_sab">+50%</SelectItem>
            <SelectItem value="100_dom">+100%</SelectItem>
            <SelectItem value="100_fer">Feriado</SelectItem>
          </SelectContent>
        </Select>
      </td>

      {/* Horas Trabalhadas */}
      <td className="px-3 py-2.5 text-center">
        {hNorm > 0 || hExtra > 0 ? (
          <div className="text-sm font-bold text-primary">
            {formatHoras(hNormAj)}
            {hExtra > 0 && <span className="text-orange-600 text-xs ml-1">+{formatHoras(hExtraAj)}</span>}
          </div>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        )}
      </td>

      {/* Horas Pagas */}
      <td className="px-3 py-2.5 text-right w-28">
        {rec.presente ? (
          <div className={`text-sm font-bold ${producaoDia > 0 ? 'text-green-700 bg-green-50 px-2 py-1 rounded' : 'text-blue-600'}`}>
            R$ {(producaoDia > 0 ? producaoDia : (hNorm + hExtra) * fator * (rec.valor_hora_snapshot || valorHoraAtual)).toFixed(2)}
          </div>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        )}
      </td>


    </tr>
  );
});

export default PontoRow;