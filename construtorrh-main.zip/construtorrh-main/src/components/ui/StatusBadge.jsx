import React from 'react';
import { cn } from '@/lib/utils';

const statusStyles = {
  ativo: 'bg-green-100 text-green-700 border-green-200',
  inativo: 'bg-red-100 text-red-700 border-red-200',
  afastado: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  ferias: 'bg-blue-100 text-blue-700 border-blue-200',
  em_andamento: 'bg-green-100 text-green-700 border-green-200',
  concluida: 'bg-blue-100 text-blue-700 border-blue-200',
  paralisada: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  cancelada: 'bg-red-100 text-red-700 border-red-200',
  pendente: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  pago: 'bg-green-100 text-green-700 border-green-200',
  lancado: 'bg-blue-100 text-blue-700 border-blue-200',
  aberto: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  encerrado: 'bg-blue-100 text-blue-700 border-blue-200',
  em_investigacao: 'bg-orange-100 text-orange-700 border-orange-200',
  devolvido: 'bg-blue-100 text-blue-700 border-blue-200',
  vencido: 'bg-red-100 text-red-700 border-red-200',
  aprovado: 'bg-green-100 text-green-700 border-green-200',
  sem_ponto: 'bg-yellow-100 text-yellow-700 border-yellow-200',
};

const statusLabels = {
  ativo: 'Ativo',
  inativo: 'Inativo',
  afastado: 'Afastado',
  ferias: 'Férias',
  em_andamento: 'Em Andamento',
  concluida: 'Concluída',
  paralisada: 'Paralisada',
  cancelada: 'Cancelada',
  pendente: 'Pendente',
  pago: 'Pago',
  lancado: 'Lançado',
  aberto: 'Aberto',
  encerrado: 'Encerrado',
  em_investigacao: 'Em Investigação',
  devolvido: 'Devolvido',
  vencido: 'Vencido',
  aprovado: 'Aprovado',
  sem_ponto: 'Sem ponto',
  com_afastamento: 'Com Afastamento',
  sem_afastamento: 'Sem Afastamento',
};

export default function StatusBadge({ status, className }) {
  const style = statusStyles[status] || 'bg-muted text-muted-foreground';
  const label = statusLabels[status] || status?.replace(/_/g, ' ');
  
  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border",
      style,
      className
    )}>
      {label}
    </span>
  );
}