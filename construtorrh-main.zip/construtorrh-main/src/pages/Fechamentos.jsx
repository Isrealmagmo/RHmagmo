import React, { useState, useMemo, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Search, DollarSign, Info, Trash2, RotateCcw, Lock, Plus, FileText } from 'lucide-react';
import { gerarExtratoPDF } from '@/components/fechamentos/ExtratoPDF';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import { calcTotaisColaborador, calcINSS, formatHoras } from '@/lib/pontoCalc';

const MONTHS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

export default function Fechamentos() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [quinzena, setQuinzena] = useState('1');
  const [search, setSearch] = useState('');
  const [detalheOpen, setDetalheOpen] = useState(null);
  const [confirmExcluir, setConfirmExcluir] = useState(null); // { colab, pagamento }
  const [novoPagamentoOpen, setNovoPagamentoOpen] = useState(false);
  const [editarAdiantamentoOpen, setEditarAdiantamentoOpen] = useState(null); // colaborador_id
  const [novoPagamento, setNovoPagamento] = useState({
    colaborador_id: '',
    tipo: 'adiantamento',
    descricao: '',
    valor: '',
    data_pagamento: '',
    forma_pagamento: 'pix'
  });

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list()
  });
  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list()
  });
  const { data: registros = [] } = useQuery({
    queryKey: ['pontos-fech', month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: month, ano: year })
  });
  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-fech', month, year],
    queryFn: () => base44.entities.Pagamento.filter({ mes: month, ano: year })
  });
  const { data: premiosLista = [] } = useQuery({
    queryKey: ['premios-fech', month, year],
    queryFn: () => base44.entities.Premio.filter({ status: 'pago' })
  });
  const { data: vtLancamentos = [] } = useQuery({
    queryKey: ['vt-lanc-fech', month, year],
    queryFn: () => base44.entities.ValeTransporteLancamento.filter({ mes: month, ano: year })
  });
  const { data: pagamentosVT = [] } = useQuery({
    queryKey: ['pagamentos-vt-fech', month, year],
    queryFn: () => base44.entities.Pagamento.filter({ mes: month, ano: year, tipo: 'vale_transporte' })
  });
  const { data: configs = [] } = useQuery({
    queryKey: ['configs'],
    queryFn: () => base44.entities.ConfiguracaoSistema.list()
  });
  const { data: obras = [] } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list()
  });

  const queryClient = useQueryClient();

  const configClt = useMemo(() => {
    const cfg = configs.find((c) => c.chave === 'descontos_clt');
    return {
      vt_aliquota: cfg?.valor?.vt_aliquota ?? 0.06,
      usar_inss_progressivo: cfg?.valor?.usar_inss_progressivo ?? true,
      inss_aliquota_fixa: cfg?.valor?.inss_aliquota_fixa ?? 0.075,
      ir_aliquota: cfg?.valor?.ir_aliquota ?? 0
    };
  }, [configs]);

  const gerarPagamentoMutation = useMutation({
    mutationFn: async (fechamento) => {
      const referencia = `${MONTHS[month - 1]}/${year} - ${quinzena === '1' ? '1ª Quinzena' : '2ª Quinzena'}`;
      // 1ª quinzena → paga dia 20 mesmo mês; 2ª quinzena → paga dia 05 próximo mês
      let dataPagamento;
      if (quinzena === '1') {
        dataPagamento = `${year}-${String(month).padStart(2, '0')}-20`;
      } else {
        const proxMes = month === 12 ? 1 : month + 1;
        const proxAno = month === 12 ? year + 1 : year;
        dataPagamento = `${proxAno}-${String(proxMes).padStart(2, '0')}-05`;
      }
      const payload = {
        colaborador_id: fechamento.id,
        colaborador_nome: fechamento.nome,
        tipo: 'quinzena',
        referencia,
        mes: month,
        ano: year,
        quinzena: Number(quinzena),
        valor: fechamento.liquido,
        status: 'pendente',
        data_pagamento: dataPagamento
      };
      const existente = pagamentos.find(
        (p) => p.colaborador_id === fechamento.id && p.quinzena === Number(quinzena) && p.mes === month && p.ano === year && p.tipo === 'quinzena'
      );
      if (existente) {
        if (existente.status !== 'cancelado') {
          await base44.entities.Pagamento.update(existente.id, { valor: fechamento.liquido, referencia, data_pagamento: dataPagamento });
        } else {
          await base44.entities.Pagamento.create(payload);
        }
      } else {
        await base44.entities.Pagamento.create(payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
    }
  });

  // Estorna (cancela) E exclui o pagamento da quinzena
  const excluirLancamentoMutation = useMutation({
    mutationFn: async ({ pagamento }) => {
      // Se pagamento tem ID (foi criado), estorna e deleta; se não, ignora
      if (pagamento.id) {
        await base44.entities.Pagamento.update(pagamento.id, { status: 'cancelado' });
        await base44.entities.Pagamento.delete(pagamento.id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
      setConfirmExcluir(null);
    }
  });

  const criarPagamentoMutation = useMutation({
    mutationFn: async () => {
      const colab = colaboradores.find((c) => c.id === novoPagamento.colaborador_id);
      if (!colab || !novoPagamento.valor) return;

      // Prêmios e Bônus NÃO são descontados
      const ehPremio = novoPagamento.tipo === 'premio';

      const payload = {
        colaborador_id: novoPagamento.colaborador_id,
        colaborador_nome: colab.nome,
        tipo: novoPagamento.tipo,
        valor: parseFloat(novoPagamento.valor),
        mes: month,
        ano: year,
        quinzena: Number(quinzena),
        status: 'pendente',
        descricao: novoPagamento.descricao || '',
        data_pagamento: novoPagamento.data_pagamento || '',
        forma_pagamento: novoPagamento.forma_pagamento
      };

      // Todos MENOS prêmios são descontados
      // 1ª quinzena → paga dia 20 do mesmo mês; 2ª quinzena → paga dia 05 do mês seguinte
      if (!ehPremio) {
        payload.descontar = true;
        let dataDesconto;
        if (quinzena === '1') {
          dataDesconto = `${year}-${String(month).padStart(2, '0')}-20`;
        } else {
          const proxMes = month === 12 ? 1 : month + 1;
          const proxAno = month === 12 ? year + 1 : year;
          dataDesconto = `${proxAno}-${String(proxMes).padStart(2, '0')}-05`;
        }
        payload.data_desconto = dataDesconto;
      }

      await base44.entities.Pagamento.create(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
      setNovoPagamentoOpen(false);
      setNovoPagamento({
        colaborador_id: '',
        tipo: 'adiantamento',
        descricao: '',
        valor: '',
        data_pagamento: '',
        forma_pagamento: 'pix'
      });
    }
  });

  const fechamentos = useMemo(() => {
    return colaboradores.
    filter((c) => c.status === 'ativo').
    map((col) => {
      const colRegs = registros.filter((r) => r.colaborador_id === col.id && r.quinzena === Number(quinzena));
      const aprovado = colRegs.every((r) => r.aprovado) && colRegs.length > 0;

      const funcao = funcoes.find((f) => f.id === col.funcao_id);
      const obra = obras.find((o) => o.id === col.obra_id);
      const valorHora = col.tipo_contrato === 'clt' ?
      funcao?.piso_clt || col.salario || 0 :
      funcao?.piso_autonomo || col.salario || 0;

      const totais = calcTotaisColaborador(colRegs, valorHora, col.tipo_contrato, obra);

      // Busca adiantamentos/pagamentos marcados para descontar neste fechamento (apenas desta quinzena)
      const adiantamentos = pagamentos.filter(
        (p) => p.colaborador_id === col.id && p.tipo === 'adiantamento' && p.status !== 'cancelado' && p.descontar && p.mes === month && p.ano === year && p.quinzena === Number(quinzena)
      );
      const totalAdiant = adiantamentos.reduce((s, p) => s + (p.valor || 0), 0);

      let descontoINSS = 0;
      let descontoVT = 0;
      let descontoIR = 0;

      // Desconto de VT: busca o pagamento de VT gerado desta quinzena
      const vtPago = pagamentosVT.find(
        (p) => p.colaborador_id === col.id && p.quinzena === Number(quinzena) && p.status !== 'cancelado'
      );
      if (vtPago) descontoVT = vtPago.valor || 0;

      if (col.tipo_contrato === 'clt') {
        descontoINSS = configClt.usar_inss_progressivo ?
        calcINSS(totais.totalBruto) :
        totais.totalBruto * configClt.inss_aliquota_fixa;
        // VT CLT: desconto máximo de 6% do bruto (se o VT lançado for maior, limita)
        if (descontoVT > 0) {
          descontoVT = Math.min(descontoVT, totais.totalBruto * configClt.vt_aliquota);
        }
        descontoIR = configClt.ir_aliquota > 0 ? totais.totalBruto * configClt.ir_aliquota : 0;
      }

      const liquido = Math.max(0, totais.totalBruto - descontoINSS - descontoVT - descontoIR - totalAdiant);

      // Busca pagamento ativo (não cancelado)
      const pagGerado = pagamentos.find(
        (p) => p.colaborador_id === col.id && p.quinzena === Number(quinzena) &&
        p.mes === month && p.ano === year && p.tipo === 'quinzena' && p.status !== 'cancelado'
      );
      const pagamentoPago = pagGerado?.status === 'pago';

      return { ...col, ...totais, valorHora, aprovado, totalAdiant, descontoINSS, descontoVT, descontoIR, liquido, pagGerado, pagamentoPago };
    }).
    filter((c) => !search || c.nome?.toLowerCase().includes(search.toLowerCase()));
  }, [colaboradores, funcoes, obras, registros, pagamentos, pagamentosVT, configs, search, quinzena, month, year, configClt]);

  const totalLiquido = useMemo(() => fechamentos.reduce((s, c) => s + c.liquido, 0), [fechamentos]);
  const detalhe = detalheOpen ? fechamentos.find((f) => f.id === detalheOpen) : null;

  const handleGerarExtrato = useCallback((c) => {
    const colRegs = registros.filter((r) => r.colaborador_id === c.id && r.quinzena === Number(quinzena));
    const adiantamentos = pagamentos.filter(
      (p) => p.colaborador_id === c.id && p.tipo === 'adiantamento' && p.status !== 'cancelado' && p.descontar && p.mes === month && p.ano === year && p.quinzena === Number(quinzena)
    );
    const premiosColab = premiosLista.filter((p) => p.colaborador_id === c.id);
    const vtLanc = vtLancamentos.find((v) => v.colaborador_id === c.id && v.quinzena === Number(quinzena));
    gerarExtratoPDF({
      colaborador: c,
      registros: colRegs,
      adiantamentos,
      descontoINSS: c.descontoINSS,
      descontoVT: c.descontoVT,
      descontoIR: c.descontoIR,
      liquido: c.liquido,
      totalBruto: c.totalBruto,
      totalHorasNormais: c.totalHorasNormais,
      totalHorasExtra: c.totalHorasExtra,
      totalProducao: c.totalProducao,
      mes: month,
      ano: year,
      quinzena: Number(quinzena),
      premios: premiosColab,
      vtLancamento: vtLanc || null
    });
  }, [registros, pagamentos, premiosLista, vtLancamentos, month, year, quinzena]);

  return (
    <div>
      <PageHeader title="Fechamentos de Ponto" subtitle="Geração de pagamentos por quinzena">
        <div className="flex gap-2">
          <Button
            className="gap-1.5 bg-green-600 hover:bg-green-700"
            onClick={() => fechamentos.filter((f) => f.aprovado && !f.pagGerado).forEach((f) => gerarPagamentoMutation.mutate(f))}
            disabled={gerarPagamentoMutation.isPending}>
            
            <DollarSign className="w-4 h-4" /> Gerar Pendentes (R$ {fechamentos.filter((f) => f.aprovado && !f.pagGerado).reduce((s, c) => s + c.liquido, 0).toFixed(2)})
          </Button>
          <Button
            variant="outline"
            className="gap-1.5"
            onClick={() => setNovoPagamentoOpen(true)}>
            
            <Plus className="w-4 h-4" /> Novo Pagamento Manual
          </Button>
        </div>
      </PageHeader>

      <div className="flex flex-wrap gap-2 mb-4 items-center">
        <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m.slice(0, 3)}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
          <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
          <SelectContent>{[2024, 2025, 2026, 2027].map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={quinzena} onValueChange={setQuinzena}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1ª Quinzena (1–15) · paga dia 20</SelectItem>
            <SelectItem value="2">2ª Quinzena (16–fim) · paga dia 5</SelectItem>
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted">
              <th className="text-left px-4 py-3 font-medium">Colaborador</th>
              <th className="text-right px-4 py-3 font-medium">Bruto</th>
              <th className="text-right px-4 py-3 font-medium">INSS</th>
              <th className="text-right px-4 py-3 font-medium">VT</th>
              <th className="text-right px-4 py-3 font-medium">IR</th>
              <th className="text-right px-4 py-3 font-medium">Adiant.</th>
              <th className="text-right px-4 py-3 font-medium">Líquido</th>
              <th className="text-left px-4 py-3 font-medium">Lançamento</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {fechamentos.length === 0 ?
            <tr><td colSpan={8} className="text-center py-8 text-muted-foreground">Nenhum colaborador com registro neste período</td></tr> :

            fechamentos.map((c) =>
            <tr key={c.id} className={`border-t hover:bg-muted/30 ${!c.aprovado ? 'opacity-60' : ''}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{c.nome}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${c.tipo_contrato === 'clt' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>
                        {c.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo'}
                      </span>
                      {!c.aprovado && <span className="text-[10px] bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">Ponto não aprovado</span>}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right font-medium">R$ {c.totalBruto.toFixed(2)}</td>
                  <td className="px-4 py-3 text-right text-red-600">{c.descontoINSS > 0 ? `- R$ ${c.descontoINSS.toFixed(2)}` : <span className="text-muted-foreground">—</span>}</td>
                  <td className="px-4 py-3 text-right text-red-600">{c.descontoVT > 0 ? `- R$ ${c.descontoVT.toFixed(2)}` : <span className="text-muted-foreground">—</span>}</td>
                  <td className="px-4 py-3 text-right text-red-600">{c.descontoIR > 0 ? `- R$ ${c.descontoIR.toFixed(2)}` : <span className="text-muted-foreground">—</span>}</td>
                  <td className={`px-4 py-3 text-right font-semibold ${c.totalAdiant > 0 ? 'bg-red-50 text-red-700 border border-red-200 rounded' : 'text-muted-foreground'}`}>{c.totalAdiant > 0 ? `- R$ ${c.totalAdiant.toFixed(2)}` : <span className="text-muted-foreground">—</span>}</td>
                  <td className="px-4 py-3 text-right font-bold text-green-700">R$ {c.liquido.toFixed(2)}</td>
                  <td className="px-4 py-3">
                    {c.pagamentoPago ?
                <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium flex items-center gap-1 w-fit">
                        <Lock className="w-3 h-3" /> Pago
                      </span> :
                c.pagGerado ?
                <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Gerado</span> :
                c.aprovado ?
                <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-medium">Pendente</span> :

                <span className="text-xs text-muted-foreground">—</span>
                }
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1 items-center justify-end">
                      
                      

                  
                      {c.totalAdiant > 0 &&
                  <Button
                    size="sm" variant="outline"
                    className="gap-1 text-xs h-7 px-2"
                    onClick={() => setEditarAdiantamentoOpen(c.id)}>
                    
                          Editar Adiant.
                        </Button>
                  }
                      {c.aprovado && !c.pagGerado &&
                  <Button
                    size="sm"
                    className="bg-green-600 hover:bg-green-700 text-xs h-7 px-2"
                    onClick={() => gerarPagamentoMutation.mutate(c)}
                    disabled={gerarPagamentoMutation.isPending}>
                    
                          Gerar
                        </Button>
                  }
                      {c.pagGerado && !c.pagamentoPago &&
                  <Button
                    size="sm" variant="outline"
                    className="gap-1 text-red-600 border-red-200 hover:bg-red-50 text-xs h-7 px-2"
                    onClick={() => setConfirmExcluir({ colab: c, pagamento: c.pagGerado })}>
                    
                          <Trash2 className="w-3 h-3" /> Excluir Lançamento
                        </Button>
                  }
                      {c.pagamentoPago &&
                  <span className="text-xs text-muted-foreground italic">Estorne em Pagamentos</span>
                  }
                    </div>
                  </td>
                </tr>
            )
            }
          </tbody>
          {fechamentos.length > 0 &&
          <tfoot>
              <tr className="border-t bg-muted/60">
                <td className="px-4 py-2 font-semibold">Total</td>
                <td className="px-4 py-2 text-right font-bold">R$ {fechamentos.reduce((s, c) => s + c.totalBruto, 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-right text-red-600">- R$ {fechamentos.reduce((s, c) => s + c.descontoINSS, 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-right text-red-600">- R$ {fechamentos.reduce((s, c) => s + c.descontoVT, 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-right text-red-600">- R$ {fechamentos.reduce((s, c) => s + c.descontoIR, 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-right text-red-600">- R$ {fechamentos.reduce((s, c) => s + c.totalAdiant, 0).toFixed(2)}</td>
                <td className="px-4 py-2 text-right font-bold text-green-700">R$ {totalLiquido.toFixed(2)}</td>
                <td colSpan={2} />
              </tr>
            </tfoot>
          }
        </table>
      </div>

      {/* Modal Detalhamento */}
      <Dialog open={!!detalheOpen} onOpenChange={() => setDetalheOpen(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Detalhamento — {detalhe?.nome}</DialogTitle></DialogHeader>
          {detalhe &&
          <div className="space-y-2 text-sm">
              <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Dias trabalhados</span><span className="font-medium">{detalhe.dias}</span></div>
              <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Horas normais</span><span className="font-medium text-primary">{formatHoras(detalhe.totalHorasNormais)}</span></div>
              {detalhe.totalHorasExtra > 0 && <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Horas extras</span><span className="font-medium text-orange-600">+{formatHoras(detalhe.totalHorasExtra)}</span></div>}
              {detalhe.totalProducao > 0 && <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Produção total</span><span className="font-medium text-green-700">R$ {detalhe.totalProducao.toFixed(2)}</span></div>}
              <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Valor hora</span><span className="font-medium">R$ {detalhe.valorHora.toFixed(2)}/h</span></div>
              <div className="flex justify-between py-1 border-b font-semibold"><span>Bruto</span><span>R$ {detalhe.totalBruto.toFixed(2)}</span></div>
              {detalhe.descontoINSS > 0 && <div className="flex justify-between py-1 border-b text-red-600"><span>(-) INSS</span><span>- R$ {detalhe.descontoINSS.toFixed(2)}</span></div>}
              {detalhe.descontoVT > 0 && <div className="flex justify-between py-1 border-b text-red-600"><span>(-) VT</span><span>- R$ {detalhe.descontoVT.toFixed(2)}</span></div>}
              {detalhe.descontoIR > 0 && <div className="flex justify-between py-1 border-b text-red-600"><span>(-) IR</span><span>- R$ {detalhe.descontoIR.toFixed(2)}</span></div>}
              {detalhe.totalAdiant > 0 && <div className="flex justify-between py-1 border-b text-red-600"><span>(-) Adiantamentos</span><span>- R$ {detalhe.totalAdiant.toFixed(2)}</span></div>}
              <div className="flex justify-between py-2 font-bold text-base border-t-2 text-green-700"><span>Líquido</span><span>R$ {detalhe.liquido.toFixed(2)}</span></div>
              {detalhe.pagGerado && <p className="text-xs text-green-600 text-center pt-1 font-medium">✓ Pagamento gerado — R$ {detalhe.pagGerado.valor?.toFixed(2)}</p>}
            </div>
          }
        </DialogContent>
      </Dialog>

      {/* Confirm Excluir Lançamento */}
      <Dialog open={!!confirmExcluir} onOpenChange={() => setConfirmExcluir(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir Lançamento de Pagamento</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Você irá <strong>estornar e excluir</strong> o pagamento gerado de <strong>{confirmExcluir?.colab?.nome}</strong>:
          </p>
          <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-sm mt-1">
            <span className="text-red-700 font-medium">{confirmExcluir?.pagamento?.referencia}</span>
            <span className="text-red-600 ml-2">— R$ {confirmExcluir?.pagamento?.valor?.toFixed(2)}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            O lançamento será estornado e excluído permanentemente. O ponto ficará disponível para gerar um novo pagamento.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setConfirmExcluir(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              onClick={() => excluirLancamentoMutation.mutate(confirmExcluir)}
              disabled={excluirLancamentoMutation.isPending}>
              
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Estornar e Excluir
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal Editar Adiantamento */}
      {editarAdiantamentoOpen && (() => {
        const colab = fechamentos.find((c) => c.id === editarAdiantamentoOpen);
        const adiantamentos = pagamentos.filter(
          (p) => p.colaborador_id === editarAdiantamentoOpen && p.tipo === 'adiantamento' && p.status !== 'cancelado' && p.mes === month && p.ano === year
        );
        return (
          <Dialog open={!!editarAdiantamentoOpen} onOpenChange={() => setEditarAdiantamentoOpen(null)}>
            <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
              <DialogHeader><DialogTitle>Adiantamentos — {colab?.nome}</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2 max-h-60 overflow-y-auto border rounded-lg p-3">
                  {adiantamentos.length === 0 ?
                  <p className="text-xs text-muted-foreground text-center py-3">Nenhum adiantamento registrado</p> :

                  adiantamentos.map((adiant) =>
                  <div key={adiant.id} className="bg-muted/50 rounded p-2 text-xs flex justify-between items-start">
                        <div className="flex-1">
                          <p className="font-medium">{adiant.descricao || 'Adiantamento'}</p>
                          <p className="text-muted-foreground text-[11px]">{new Date(adiant.data_pagamento).toLocaleDateString('pt-BR')} • {adiant.forma_pagamento}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-red-600">R$ {adiant.valor.toFixed(2)}</p>
                          <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50 h-6 px-1 text-[10px] mt-1"
                        onClick={() => {
                          if (confirm('Excluir este adiantamento?')) {
                            base44.entities.Pagamento.delete(adiant.id).then(() => {
                              queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
                            });
                          }
                        }}>
                        
                            Excluir
                          </Button>
                        </div>
                      </div>
                  )
                  }
                </div>

                <div className="border-t pt-4">
                  <label className="text-sm font-medium mb-1.5 block">Adicionar Novo Adiantamento</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Input type="number" placeholder="Valor (R$)" id="temp-adiant-valor" step="0.01" />
                    <Input type="date" id="temp-adiant-data" defaultValue={new Date().toISOString().split('T')[0]} />
                  </div>
                  <Button
                    className="w-full mt-2 bg-green-600 hover:bg-green-700"
                    size="sm"
                    onClick={() => {
                      const valor = document.getElementById('temp-adiant-valor')?.value;
                      const data = document.getElementById('temp-adiant-data')?.value;
                      if (!valor || !data) return;
                      base44.entities.Pagamento.create({
                        colaborador_id: editarAdiantamentoOpen,
                        colaborador_nome: colab.nome,
                        tipo: 'adiantamento',
                        descricao: 'Adiantamento',
                        valor: parseFloat(valor),
                        data_pagamento: data,
                        forma_pagamento: 'pix',
                        descontar: true,
                        mes: month,
                        ano: year,
                        quinzena: Number(quinzena),
                        status: 'pendente',
                        data_desconto: new Date(`${year}-${String(month).padStart(2, '0')}-${quinzena === '1' ? '05' : '20'}`).toISOString().split('T')[0]
                      }).then(() => {
                        queryClient.invalidateQueries({ queryKey: ['pagamentos-fech'] });
                        document.getElementById('temp-adiant-valor').value = '';
                      });
                    }}>
                    
                    + Adicionar
                  </Button>
                </div>

                <div className="flex justify-end pt-2">
                  <Button variant="outline" onClick={() => setEditarAdiantamentoOpen(null)}>Fechar</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>);

      })()}

      {/* Modal Novo Pagamento Manual */}
      <Dialog open={novoPagamentoOpen} onOpenChange={setNovoPagamentoOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Novo Pagamento Manual</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Colaborador *</label>
              <Select value={novoPagamento.colaborador_id} onValueChange={(v) => setNovoPagamento({ ...novoPagamento, colaborador_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecionar..." />
                </SelectTrigger>
                <SelectContent>
                  {colaboradores.filter((c) => c.status === 'ativo').map((c) =>
                  <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Tipo *</label>
              <Select value={novoPagamento.tipo} onValueChange={(v) => setNovoPagamento({ ...novoPagamento, tipo: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="adiantamento">Adiantamento</SelectItem>
                  <SelectItem value="vale_transporte">Vale Transporte</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                  <SelectItem value="premio">Prêmios e Bônus (Sem desconto)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Descrição *</label>
              <Input
                placeholder="Ex: Adiantamento de férias"
                value={novoPagamento.descricao}
                onChange={(e) => setNovoPagamento({ ...novoPagamento, descricao: e.target.value })} />
              
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Valor (R$) *</label>
                <Input
                  type="number"
                  placeholder="0"
                  value={novoPagamento.valor}
                  onChange={(e) => setNovoPagamento({ ...novoPagamento, valor: e.target.value })}
                  step="0.01" />
                
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Data Pagamento *</label>
                <Input
                  type="date"
                  value={novoPagamento.data_pagamento}
                  onChange={(e) => setNovoPagamento({ ...novoPagamento, data_pagamento: e.target.value })} />
                
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Forma de Pagamento</label>
              <Select value={novoPagamento.forma_pagamento} onValueChange={(v) => setNovoPagamento({ ...novoPagamento, forma_pagamento: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="transferencia">Transferência</SelectItem>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {novoPagamento.tipo !== 'premio' &&
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-2.5 text-xs text-blue-700">
                <strong>ℹ️ Será descontado:</strong> Este lançamento será descontado na {quinzena === '1' ? '1ª' : '2ª'} quinzena (dia {quinzena === '1' ? '05' : '20'}).
              </div>
            }
            {novoPagamento.tipo === 'premio' &&
            <div className="bg-green-50 border border-green-200 rounded-lg p-2.5 text-xs text-green-700">
                <strong>✓ Sem desconto:</strong> Prêmios e Bônus não são descontados do fechamento.
              </div>
            }

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setNovoPagamentoOpen(false)}>Cancelar</Button>
              <Button
                onClick={() => criarPagamentoMutation.mutate()}
                disabled={criarPagamentoMutation.isPending || !novoPagamento.colaborador_id || !novoPagamento.valor || !novoPagamento.descricao || !novoPagamento.data_pagamento}>
                
                Salvar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>);

}