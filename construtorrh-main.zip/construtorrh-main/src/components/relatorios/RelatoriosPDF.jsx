import jsPDF from 'jspdf';
import { calcHorasNormais, calcHorasExtra, getAdicionalFator, formatHoras } from '@/lib/pontoCalc';

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const DIAS_SEMANA = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const TIPO_LABELS = { normal: 'Normal', falta: 'Falta', atestado: 'Atestado', feriado: 'Feriado', folga: 'Folga' };

function fmt(v) { return `R$ ${Number(v || 0).toFixed(2)}`; }
function fmtDate(str) {
  if (!str) return '';
  const d = new Date(str + 'T00:00:00');
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;
}
function newPage(doc, y, min) {
  if (y + min > 272) { doc.addPage(); return 14; }
  return y;
}
function header(doc, W, margin, titulo, subtitulo) {
  doc.setFillColor(15, 40, 100);
  doc.rect(0, 0, W, 30, 'F');
  doc.setFillColor(59, 130, 246);
  doc.rect(0, 0, 4, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text(titulo, margin + 4, 11);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(180, 200, 240);
  doc.text(subtitulo, margin + 4, 18);
  doc.text(`Emitido em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`, W - margin, 18, { align: 'right' });
}
function sectionTitle(doc, label, y, W, margin) {
  doc.setFillColor(30, 58, 138);
  doc.rect(margin, y, W - margin * 2, 6.5, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text(label, margin + 2, y + 4.5);
  return y + 8;
}
function footer(doc, W) {
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFillColor(15, 40, 100);
    doc.rect(0, 285, W, 12, 'F');
    doc.setFillColor(59, 130, 246);
    doc.rect(0, 285, 4, 12, 'F');
    doc.setFontSize(6.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(180, 200, 240);
    doc.text(`Página ${i} de ${pages}`, W / 2, 291, { align: 'center' });
    doc.text('ConstrutorRH — Documento sem valor fiscal', W / 2, 295, { align: 'center' });
  }
}

// ── RELATÓRIO POR COLABORADOR (extrato detalhado) ─────────────────────────────
export function gerarRelatorioColaboradorPDF({
  colaborador, registros, adiantamentos,
  descontoINSS, descontoVT, descontoIR, liquido,
  totalBruto, totalHorasNormais, totalHorasExtra, totalProducao,
  mes, ano, quinzena, premios = [], vtLancamento = null,
}) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = 210, margin = 12;
  let y = 0;

  const periodoLabel = quinzena === 'todas'
    ? `${MONTHS[mes - 1]}/${ano} — Mês Completo`
    : `${MONTHS[mes - 1]}/${ano} — ${quinzena === '1' || quinzena === 1 ? '1ª' : '2ª'} Quinzena`;

  header(doc, W, margin, 'EXTRATO DE PAGAMENTO', periodoLabel);
  y = 34;

  // Dados do colaborador
  doc.setFillColor(241, 245, 253);
  doc.roundedRect(margin, y, W - margin * 2, 26, 2, 2, 'F');
  doc.setDrawColor(200, 215, 240);
  doc.roundedRect(margin, y, W - margin * 2, 26, 2, 2, 'S');
  doc.setTextColor(15, 40, 100);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text((colaborador.nome || '').toUpperCase(), margin + 4, y + 8);
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(80, 100, 140);
  const info1 = [
    colaborador.chapa ? `Chapa: ${colaborador.chapa}` : null,
    colaborador.funcao_nome ? `Função: ${colaborador.funcao_nome}` : null,
    colaborador.tipo_contrato ? `Contrato: ${colaborador.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo'}` : null,
    colaborador.obra_nome ? `Obra: ${colaborador.obra_nome}` : null,
  ].filter(Boolean);
  doc.text(info1.join('   |   '), margin + 4, y + 15);
  const info2 = [
    colaborador.cpf ? `CPF: ${colaborador.cpf}` : null,
    colaborador.data_admissao ? `Admissão: ${fmtDate(colaborador.data_admissao)}` : null,
    colaborador.pis_nit ? `PIS/NIT: ${colaborador.pis_nit}` : null,
  ].filter(Boolean);
  if (info2.length) doc.text(info2.join('   |   '), margin + 4, y + 21);
  y += 30;

  // Resumo financeiro (3 colunas)
  y = newPage(doc, y, 40);
  y = sectionTitle(doc, 'RESUMO FINANCEIRO', y, W, margin);
  const colW = (W - margin * 2) / 3;
  const blocks = [
    { label: 'Horas Normais', value: formatHoras(totalHorasNormais), color: [30, 64, 175] },
    { label: 'Horas Extras', value: formatHoras(totalHorasExtra), color: totalHorasExtra > 0 ? [217, 119, 6] : [160, 170, 190] },
    { label: 'Produção Total', value: fmt(totalProducao), color: [5, 150, 105] },
    { label: 'Prêmios / Bônus', value: fmt(premios.reduce((s,p)=>s+(p.valor||0),0)), color: [124, 58, 237] },
    { label: 'VT Recebido', value: vtLancamento ? fmt(vtLancamento.valor_total) : '—', color: [14, 116, 144] },
    { label: 'TOTAL BRUTO', value: fmt(totalBruto), color: [15, 40, 100], bold: true },
  ];
  blocks.forEach((b, i) => {
    const cx = margin + (i % 3) * colW + colW / 2;
    const cy = y + Math.floor(i / 3) * 17;
    doc.setFontSize(6.5); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 130, 150);
    doc.text(b.label, cx, cy, { align: 'center', maxWidth: colW - 4 });
    doc.setFontSize(b.bold ? 9.5 : 8.5); doc.setFont('helvetica', b.bold ? 'bold' : 'normal');
    doc.setTextColor(...b.color);
    doc.text(b.value, cx, cy + 6.5, { align: 'center', maxWidth: colW - 4 });
  });
  y += 36;

  // Descontos
  const descontos = [
    descontoINSS > 0 ? { label: 'INSS (Previdência Social)', value: descontoINSS } : null,
    descontoVT > 0 ? { label: 'Vale Transporte', value: descontoVT } : null,
    descontoIR > 0 ? { label: 'Imposto de Renda (IR)', value: descontoIR } : null,
    ...(adiantamentos || []).map(a => ({ label: a.descricao || 'Adiantamento', value: a.valor })),
  ].filter(Boolean);

  if (descontos.length > 0) {
    y = newPage(doc, y, descontos.length * 6 + 20);
    y = sectionTitle(doc, 'DESCONTOS', y, W, margin);
    descontos.forEach((d, i) => {
      if (i % 2 === 0) { doc.setFillColor(248, 250, 255); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(60, 70, 100);
      doc.text(d.label, margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(185, 28, 28);
      doc.text(`- ${fmt(d.value)}`, W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });
    const totalDesc = descontos.reduce((s, d) => s + d.value, 0);
    doc.setFillColor(254, 242, 242);
    doc.rect(margin, y, W - margin * 2, 6, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(185, 28, 28);
    doc.text('Total de Descontos', margin + 3, y + 4);
    doc.text(`- ${fmt(totalDesc)}`, W - margin - 3, y + 4, { align: 'right' });
    y += 9;
  }

  // Líquido
  y = newPage(doc, y, 18);
  doc.setFillColor(5, 150, 105);
  doc.roundedRect(margin, y, W - margin * 2, 15, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12); doc.setFont('helvetica', 'bold');
  doc.text('LÍQUIDO A RECEBER', margin + 5, y + 9.5);
  doc.setFontSize(13);
  doc.text(fmt(liquido), W - margin - 5, y + 9.5, { align: 'right' });
  y += 20;

  // VT detalhado
  if (vtLancamento) {
    y = newPage(doc, y, 35);
    y = sectionTitle(doc, 'VALE TRANSPORTE — DETALHAMENTO', y, W, margin);
    const vtRows = [
      ['Tipo de VT', (colaborador.vt_tipo || '').replace(/_/g, ' ')],
      ['Valor por Dia', fmt(vtLancamento.valor_dia)],
      ['Dias Esperados', String(vtLancamento.dias_esperados || '—')],
      ['Dias Trabalhados', String(vtLancamento.dias_trabalhados || '—')],
      ['Valor Total VT', fmt(vtLancamento.valor_total)],
    ];
    if (vtLancamento.observacoes) vtRows.push(['Observação', vtLancamento.observacoes]);
    vtRows.forEach((r, i) => {
      if (i % 2 === 0) { doc.setFillColor(248, 252, 255); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(60, 80, 120);
      doc.text(r[0], margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(14, 116, 144);
      doc.text(String(r[1]), W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });
    y += 3;
  }

  // Prêmios
  if (premios.length > 0) {
    y = newPage(doc, y, premios.length * 6 + 18);
    y = sectionTitle(doc, 'PRÊMIOS E BÔNUS', y, W, margin);
    premios.forEach((p, i) => {
      if (i % 2 === 0) { doc.setFillColor(250, 247, 255); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(80, 60, 130);
      doc.text([p.descricao || 'Prêmio', p.motivo ? `(${p.motivo})` : '', p.data ? fmtDate(p.data) : ''].filter(Boolean).join(' '), margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(124, 58, 237);
      doc.text(fmt(p.valor), W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });
    y += 3;
  }

  // Dados bancários
  if (colaborador.pix_chave || colaborador.banco) {
    y = newPage(doc, y, 20);
    y = sectionTitle(doc, 'DADOS PARA PAGAMENTO', y, W, margin);
    const dados = [
      colaborador.pix_chave ? [`PIX — ${(colaborador.pix_tipo || 'chave').replace(/_/g, ' ')}`, colaborador.pix_chave] : null,
      colaborador.banco ? ['Banco', colaborador.banco] : null,
      colaborador.agencia ? ['Agência / Conta', `${colaborador.agencia} / ${colaborador.conta || '—'} (${colaborador.tipo_conta || 'corrente'})`] : null,
    ].filter(Boolean);
    dados.forEach((r, i) => {
      if (i % 2 === 0) { doc.setFillColor(248, 250, 252); doc.rect(margin, y - 2, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8); doc.setTextColor(60, 80, 100);
      doc.text(r[0], margin + 3, y + 2);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(15, 40, 100);
      doc.text(r[1], W - margin - 3, y + 2, { align: 'right' });
      y += 6;
    });
    y += 3;
  }

  // Registros de ponto
  const regsOrd = [...(registros || [])].sort((a, b) => a.data < b.data ? -1 : 1);
  if (regsOrd.length > 0) {
    y = newPage(doc, y, 30);
    y = sectionTitle(doc, 'REGISTROS DE PONTO', y, W, margin);
    const TH = [
      { l: 'Data', x: margin + 1 }, { l: 'Dia', x: margin + 15 }, { l: 'Entrada', x: margin + 25 },
      { l: 'Alm.Saída', x: margin + 38 }, { l: 'Alm.Ret.', x: margin + 53 }, { l: 'Saída', x: margin + 67 },
      { l: 'H.Norm.', x: margin + 80 }, { l: 'H.Extra', x: margin + 94 }, { l: 'Adicional', x: margin + 107 },
      { l: 'Produção', x: margin + 126 }, { l: 'Vlr.Dia', x: margin + 147 }, { l: 'Tipo', x: margin + 166 },
    ];
    doc.setFillColor(44, 82, 180);
    doc.rect(margin, y, W - margin * 2, 6.5, 'F');
    doc.setTextColor(255, 255, 255); doc.setFontSize(6.5); doc.setFont('helvetica', 'bold');
    TH.forEach(h => doc.text(h.l, h.x, y + 4.5));
    y += 7;

    regsOrd.forEach((reg, idx) => {
      if (y > 270) { doc.addPage(); y = 14; }
      const isEven = idx % 2 === 0;
      doc.setFillColor(isEven ? 248 : 255, isEven ? 250 : 255, isEven ? 255 : 255);
      doc.rect(margin, y - 1, W - margin * 2, 6.5, 'F');
      const d = new Date(reg.data + 'T00:00:00');
      const dow = d.getDay();
      const isWeekend = dow === 0 || dow === 6;
      const hNorm = reg.tipo === 'atestado' ? 0 : calcHorasNormais(reg.entrada, reg.saida, reg.saida_almoco, reg.retorno_almoco);
      const hExtra = calcHorasExtra(reg.entrada_extra, reg.saida_extra);
      const fator = getAdicionalFator(reg.adicional);
      const vh = reg.valor_hora_snapshot || 0;
      const valorDia = reg.valor_producao > 0 ? reg.valor_producao : (hNorm + hExtra) * fator * vh;
      const isAusente = !reg.presente && reg.tipo !== 'atestado';
      const baseColor = isAusente ? [170, 100, 100] : isWeekend ? [80, 80, 180] : [40, 50, 70];
      doc.setTextColor(...baseColor); doc.setFont('helvetica', 'normal'); doc.setFontSize(7);
      const rv = y + 4;
      doc.text(fmtDate(reg.data), TH[0].x, rv);
      doc.text(DIAS_SEMANA[dow], TH[1].x, rv);
      doc.text(reg.entrada || '—', TH[2].x, rv);
      doc.text(reg.saida_almoco || '—', TH[3].x, rv);
      doc.text(reg.retorno_almoco || '—', TH[4].x, rv);
      doc.text(reg.saida || '—', TH[5].x, rv);
      doc.text(hNorm > 0 ? formatHoras(hNorm) : '—', TH[6].x, rv);
      doc.text(hExtra > 0 ? formatHoras(hExtra) : '—', TH[7].x, rv);
      const adicLabel = { '50_sab': 'Sáb +50%', '100_dom': 'Dom +100%', '100_fer': 'Fer +100%' }[reg.adicional];
      if (adicLabel) { doc.setTextColor(217, 119, 6); doc.setFont('helvetica', 'bold'); doc.text(adicLabel, TH[8].x, rv); doc.setFont('helvetica', 'normal'); doc.setTextColor(...baseColor); } else { doc.text('—', TH[8].x, rv); }
      if (reg.valor_producao > 0) { doc.setTextColor(5, 120, 80); doc.setFont('helvetica', 'bold'); doc.text(fmt(reg.valor_producao), TH[9].x, rv); doc.setFont('helvetica', 'normal'); doc.setTextColor(...baseColor); } else { doc.text('—', TH[9].x, rv); }
      doc.text(valorDia > 0 ? fmt(valorDia) : '—', TH[10].x, rv);
      const tipo = reg.tipo || 'normal';
      doc.setTextColor(...({ normal: [22,130,70], falta: [200,30,30], atestado: [217,119,6], feriado: [30,64,175], folga: [100,110,130] }[tipo] || [80,80,80]));
      doc.setFont('helvetica', 'bold'); doc.setFontSize(6.5);
      doc.text(TIPO_LABELS[tipo] || tipo, TH[11].x, rv);
      y += 6.5;
    });

    // Total ponto
    if (y > 265) { doc.addPage(); y = 14; }
    doc.setFillColor(30, 50, 120);
    doc.rect(margin, y, W - margin * 2, 7, 'F');
    doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(7);
    doc.text('TOTAL', TH[0].x, y + 5);
    doc.text(formatHoras(totalHorasNormais), TH[6].x, y + 5);
    doc.text(totalHorasExtra > 0 ? formatHoras(totalHorasExtra) : '—', TH[7].x, y + 5);
    doc.setTextColor(100, 220, 160);
    doc.text(totalProducao > 0 ? fmt(totalProducao) : '—', TH[9].x, y + 5);
    y += 10;
  }

  // Assinatura
  y = newPage(doc, y, 30);
  y += 8;
  doc.setDrawColor(150, 160, 180);
  const midX = W / 2;
  doc.line(margin + 10, y, midX - 8, y);
  doc.line(midX + 8, y, W - margin - 10, y);
  doc.setFontSize(7); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 130, 150);
  doc.text('Assinatura do Colaborador', margin + 10, y + 4);
  doc.text('Responsável pelo Pagamento', midX + 8, y + 4);
  y += 12;
  doc.setFontSize(7); doc.setFont('helvetica', 'italic'); doc.setTextColor(170, 180, 200);
  doc.text(`Recebi a importância de ${fmt(liquido)} referente ao período ${MONTHS[mes - 1]}/${ano} — ${periodoLabel}.`, W / 2, y, { align: 'center' });

  footer(doc, W);

  const nomeArquivo = `extrato_${(colaborador.nome || 'colaborador').replace(/\s+/g, '_').toLowerCase()}_${MONTHS[mes - 1].toLowerCase()}_${ano}.pdf`;
  doc.save(nomeArquivo);
}

// ── RELATÓRIO GERENCIAL (por obra, função ou geral) ───────────────────────────
export function gerarRelatorioGerencialPDF({ tipo, dados, titulo, totaisGerais, mes, ano, quinzena }) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = 210, margin = 12;
  let y = 0;

  const periodoLabel = quinzena === 'todas'
    ? `${MONTHS[mes - 1]}/${ano} — Mês Completo`
    : `${MONTHS[mes - 1]}/${ano} — ${quinzena === '1' || quinzena === 1 ? '1ª' : '2ª'} Quinzena`;

  header(doc, W, margin, titulo, periodoLabel);
  y = 34;

  // ── TOTAIS GERAIS ──────────────────────────────────────────────────────────
  y = sectionTitle(doc, 'TOTAIS GERAIS DO PERÍODO', y, W, margin);
  const totBlocks = [
    { label: 'Colaboradores', value: String(totaisGerais.colaboradores), color: [30, 64, 175] },
    { label: 'Horas Normais', value: formatHoras(totaisGerais.totalHorasNormais), color: [30, 64, 175] },
    { label: 'Horas Extras', value: formatHoras(totaisGerais.totalHorasExtra), color: [217, 119, 6] },
    { label: 'Produção Total', value: fmt(totaisGerais.totalProducao), color: [5, 150, 105] },
    { label: 'Total Bruto', value: fmt(totaisGerais.totalBruto), color: [15, 40, 100] },
    { label: 'Total Líquido', value: fmt(totaisGerais.totalLiquido), color: [5, 120, 80] },
  ];
  const bW = (W - margin * 2) / 3;
  totBlocks.forEach((b, i) => {
    const cx = margin + (i % 3) * bW + bW / 2;
    const cy = y + Math.floor(i / 3) * 17;
    doc.setFontSize(6.5); doc.setFont('helvetica', 'normal'); doc.setTextColor(120, 130, 150);
    doc.text(b.label, cx, cy, { align: 'center', maxWidth: bW - 4 });
    doc.setFontSize(8.5); doc.setFont('helvetica', 'bold'); doc.setTextColor(...b.color);
    doc.text(b.value, cx, cy + 6.5, { align: 'center', maxWidth: bW - 4 });
  });
  y += 36;

  // ── DESCONTOS TOTAIS ───────────────────────────────────────────────────────
  doc.setFillColor(254, 242, 242);
  doc.rect(margin, y, W - margin * 2, 8, 'F');
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(185, 28, 28);
  doc.text(`INSS: - ${fmt(totaisGerais.totalDescontoINSS)}   |   VT: - ${fmt(totaisGerais.totalDescontoVT)}   |   Adiant.: - ${fmt(totaisGerais.totalAdiant)}`, margin + 3, y + 5);
  y += 12;

  // ── LISTAGEM PRINCIPAL ─────────────────────────────────────────────────────
  const isByObra = tipo === 'obra';
  const isByFuncao = tipo === 'funcao';

  if (isByObra || isByFuncao) {
    // Agrupado
    dados.forEach(grupo => {
      y = newPage(doc, y, 30);
      doc.setFillColor(isByObra ? 15 : 55, isByObra ? 40 : 65, isByObra ? 100 : 100);
      doc.rect(margin, y, W - margin * 2, 8, 'F');
      doc.setTextColor(255, 255, 255); doc.setFontSize(9); doc.setFont('helvetica', 'bold');
      doc.text(grupo.nome, margin + 3, y + 5.5);
      doc.setFontSize(7.5); doc.setFont('helvetica', 'normal');
      doc.text(`${grupo.colaboradores?.length || grupo.count || 0} colaboradores`, W - margin - 3, y + 5.5, { align: 'right' });
      y += 10;

      // Cabeçalho da tabela
      const cols = [
        { l: 'Colaborador', x: margin + 1, w: 60 },
        { l: 'Contrato', x: margin + 62 },
        { l: 'Horas', x: margin + 87 },
        { l: 'Produção', x: margin + 113 },
        { l: 'Bruto', x: margin + 145 },
        { l: 'Líquido', x: margin + 168 },
      ];
      doc.setFillColor(200, 215, 240);
      doc.rect(margin, y, W - margin * 2, 5.5, 'F');
      doc.setFontSize(6.5); doc.setFont('helvetica', 'bold'); doc.setTextColor(30, 40, 80);
      cols.forEach(c => doc.text(c.l, c.x, y + 4));
      y += 6;

      let grTotalBruto = 0, grLiquido = 0;
      (grupo.colaboradores || []).forEach((c, i) => {
        if (y > 270) { doc.addPage(); y = 14; }
        if (i % 2 === 0) { doc.setFillColor(248, 250, 255); doc.rect(margin, y - 1, W - margin * 2, 5.5, 'F'); }
        doc.setFont('helvetica', 'normal'); doc.setFontSize(7); doc.setTextColor(40, 50, 70);
        doc.text((c.nome || '').slice(0, 32), cols[0].x, y + 3);
        doc.text(c.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo', cols[1].x, y + 3);
        doc.text(formatHoras(c.totalHorasNormais), cols[2].x, y + 3);
        if (c.totalProducao > 0) { doc.setTextColor(5, 120, 60); doc.setFont('helvetica', 'bold'); doc.text(fmt(c.totalProducao), cols[3].x, y + 3); doc.setFont('helvetica', 'normal'); doc.setTextColor(40, 50, 70); }
        else { doc.text('—', cols[3].x, y + 3); }
        doc.text(fmt(c.totalBruto), cols[4].x, y + 3);
        doc.setFont('helvetica', 'bold'); doc.setTextColor(5, 100, 60); doc.text(fmt(c.liquido), cols[5].x, y + 3);
        grTotalBruto += c.totalBruto; grLiquido += c.liquido;
        y += 5.5;
      });

      // Subtotal do grupo
      if (y > 268) { doc.addPage(); y = 14; }
      doc.setFillColor(200, 235, 215);
      doc.rect(margin, y, W - margin * 2, 6, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(7.5); doc.setTextColor(5, 80, 50);
      doc.text(`Subtotal ${grupo.nome}`, margin + 3, y + 4);
      doc.text(fmt(grTotalBruto), cols[4].x, y + 4);
      doc.text(fmt(grLiquido), cols[5].x, y + 4);
      y += 10;
    });
  } else {
    // Lista geral de colaboradores
    y = sectionTitle(doc, 'RELAÇÃO DE COLABORADORES', y, W, margin);
    const cols = [
      { l: 'Colaborador', x: margin + 1 },
      { l: 'Obra', x: margin + 57 },
      { l: 'Função', x: margin + 97 },
      { l: 'Horas', x: margin + 128 },
      { l: 'Bruto', x: margin + 149 },
      { l: 'Desc.', x: margin + 165 },
      { l: 'Líquido', x: margin + 180 },
    ];
    doc.setFillColor(200, 215, 240);
    doc.rect(margin, y, W - margin * 2, 5.5, 'F');
    doc.setFontSize(6.5); doc.setFont('helvetica', 'bold'); doc.setTextColor(30, 40, 80);
    cols.forEach(c => doc.text(c.l, c.x, y + 4));
    y += 6;

    dados.forEach((c, i) => {
      if (y > 270) { doc.addPage(); y = 14; }
      if (i % 2 === 0) { doc.setFillColor(248, 250, 255); doc.rect(margin, y - 1, W - margin * 2, 5.5, 'F'); }
      doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5); doc.setTextColor(40, 50, 70);
      doc.text((c.nome || '').slice(0, 24), cols[0].x, y + 3);
      doc.text((c.obra_nome || '—').slice(0, 18), cols[1].x, y + 3);
      doc.text((c.funcao_nome || '—').slice(0, 16), cols[2].x, y + 3);
      doc.text(formatHoras(c.totalHorasNormais), cols[3].x, y + 3);
      doc.text(fmt(c.totalBruto), cols[4].x, y + 3);
      const totalDesc = (c.descontoINSS || 0) + (c.descontoVT || 0) + (c.descontoIR || 0) + (c.totalAdiant || 0);
      doc.setTextColor(185, 28, 28); doc.text(totalDesc > 0 ? `- ${fmt(totalDesc)}` : '—', cols[5].x, y + 3);
      doc.setFont('helvetica', 'bold'); doc.setTextColor(5, 100, 60); doc.text(fmt(c.liquido), cols[6].x, y + 3);
      y += 5.5;
    });

    // Total geral
    if (y > 266) { doc.addPage(); y = 14; }
    doc.setFillColor(15, 40, 100);
    doc.rect(margin, y, W - margin * 2, 8, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(255, 255, 255);
    doc.text(`TOTAL GERAL — ${dados.length} colaboradores`, margin + 3, y + 5.5);
    doc.text(fmt(totaisGerais.totalBruto), cols[4].x, y + 5.5);
    doc.setTextColor(255, 180, 180);
    doc.text(`- ${fmt(totaisGerais.totalDescontoINSS + totaisGerais.totalDescontoVT + totaisGerais.totalAdiant)}`, cols[5].x, y + 5.5);
    doc.setTextColor(100, 240, 180);
    doc.text(fmt(totaisGerais.totalLiquido), cols[6].x, y + 5.5);
    y += 12;
  }

  footer(doc, W);

  const nomeArq = `relatorio_${tipo}_${MONTHS[mes - 1].toLowerCase()}_${ano}.pdf`;
  doc.save(nomeArq);
}