import React from 'react';

/**
 * Exibe informações de quinzena com código da obra quando há múltiplos registros
 */
export default function QuinzenaInfo({ quinzena, registros = [], aprovado = false, obras = [] }) {
  // Filtra registros da quinzena atual
  const registrosQuin = registros.filter(r => r.quinzena === quinzena);
  
  if (!registrosQuin.length) {
    return null;
  }

  // Se houver múltiplas obras nesta quinzena, mostra todos os códigos
  const obrasUsadas = [...new Set(registrosQuin.map(r => r.obra_id))];
  const showObras = obrasUsadas.length > 1;

  const obrasNomes = obrasUsadas
    .map(obraId => {
      const obra = obras.find(o => o.id === obraId);
      return obra?.codigo || obra?.nome || 'N/A';
    })
    .join(', ');

  return (
    <div className="text-xs text-muted-foreground mt-1 flex items-center flex-wrap gap-1">
      {showObras && (
        <span className="bg-muted px-2 py-0.5 rounded font-medium">
          {obrasNomes}
        </span>
      )}
    </div>
  );
}