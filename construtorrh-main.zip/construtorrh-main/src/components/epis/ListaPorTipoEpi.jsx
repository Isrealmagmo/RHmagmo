import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ShoppingCart } from 'lucide-react';

const CATEGORIA_LABELS = {
  cabeca: '👷 Proteção da Cabeça',
  olhos_face: '👁️ Proteção dos Olhos e Face',
  audicao: '🔇 Proteção Auditiva',
  respiratorio: '😷 Proteção Respiratória',
  tronco: '🦺 Proteção do Corpo',
  maos_bracos: '🧤 Luvas e Proteção de Mãos',
  pes_pernas: '🥾 Calçados e Proteção de Pernas',
  queda: '🧗 Trabalho em Altura',
  outros: '🔧 Outros',
};

export default function ListaPorTipoEpi({ filtroObra, filtroColaborador }) {
  const { data: epis = [] } = useQuery({ queryKey: ['epis'], queryFn: () => base44.entities.EpiRegistro.list() });
  const { data: catalogo = [] } = useQuery({ queryKey: ['epi_catalogo'], queryFn: () => base44.entities.EpiCatalogo.list() });

  const pendentes = useMemo(() => {
    return epis.filter(e => 
      e.pendente_compra && 
      (filtroObra === 'todas' || e.obra_id === filtroObra) &&
      (filtroColaborador === 'todos' || e.colaborador_id === filtroColaborador)
    );
  }, [epis, filtroObra, filtroColaborador]);

  // Agrupa por categoria do catálogo
  const porCategoria = useMemo(() => {
    const map = {};
    
    pendentes.forEach(e => {
      const epiCat = catalogo.find(c => c.id === e.epi_catalogo_id);
      const categoria = epiCat?.categoria || 'outros';
      
      if (!map[categoria]) {
        map[categoria] = { 
          label: CATEGORIA_LABELS[categoria] || categoria, 
          epis: {},
          total: 0 
        };
      }
      
      // Agrupa por tipo de EPI dentro da categoria
      const key = e.equipamento;
      if (!map[categoria].epis[key]) {
        map[categoria].epis[key] = { 
          equipamento: e.equipamento, 
          ca: e.ca,
          itens: [],
          qtd: 0,
          tamanhos: {} 
        };
      }
      
      map[categoria].epis[key].itens.push({
        colaborador_nome: e.colaborador_nome,
        obra_nome: e.obra_nome,
        tamanho: e.tamanho,
      });
      map[categoria].epis[key].qtd++;
      
      if (e.tamanho) {
        map[categoria].epis[key].tamanhos[e.tamanho] = (map[categoria].epis[key].tamanhos[e.tamanho] || 0) + 1;
      }
      
      map[categoria].total++;
    });
    
    return Object.entries(map).sort((a, b) => a[1].label.localeCompare(b[1].label));
  }, [pendentes, catalogo]);

  if (pendentes.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <ShoppingCart className="w-10 h-10 mx-auto mb-2 opacity-30" />
        <p>Nenhum EPI pendente de compra</p>
        {filtroObra !== 'todas' && <p className="text-xs mt-1">Tente selecionar outra obra</p>}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {porCategoria.length > 0 && porCategoria.map(([categoria, dados]) => (
        <div key={categoria} className="border rounded-xl overflow-hidden">
          {/* Header da categoria */}
          <div className="bg-sidebar text-sidebar-foreground px-4 py-3 flex items-center justify-between">
            <div>
              <p className="font-semibold text-sm">{dados.label}</p>
            </div>
            <span className="bg-sidebar-accent text-sidebar-accent-foreground text-xs px-2 py-1 rounded font-medium">
              {dados.total} item(s)
            </span>
          </div>

          {/* Listagem de EPIs por tipo */}
          <div className="divide-y">
            {Object.entries(dados.epis).map(([key, epiData]) => (
              <div key={key} className="p-4 hover:bg-muted/30 transition">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-sm">{epiData.equipamento}</p>
                    {epiData.ca && <p className="text-xs text-muted-foreground">CA: {epiData.ca}</p>}
                  </div>
                  <span className="bg-blue-100 text-blue-700 text-sm font-bold px-2.5 py-0.5 rounded-full">
                    {epiData.qtd}x
                  </span>
                </div>

                {/* Tamanhos */}
                {Object.keys(epiData.tamanhos).length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {Object.entries(epiData.tamanhos).map(([tamanho, qtd]) => (
                      <span key={tamanho} className="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded">
                        {tamanho} (x{qtd})
                      </span>
                    ))}
                  </div>
                )}

                {/* Colaboradores */}
                <div className="text-xs text-muted-foreground space-y-0.5">
                  {epiData.itens.slice(0, 3).map((item, idx) => (
                    <div key={idx} className="flex items-center gap-1">
                      <span className="font-medium">{item.colaborador_nome}</span>
                      {item.tamanho && <span className="text-blue-600">({item.tamanho})</span>}
                    </div>
                  ))}
                  {epiData.itens.length > 3 && (
                    <div className="text-muted-foreground italic">+{epiData.itens.length - 3} colaborador(es)</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}