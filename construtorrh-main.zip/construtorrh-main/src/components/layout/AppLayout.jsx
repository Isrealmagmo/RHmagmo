import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';

export default function AppLayout() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="lg:ml-[220px] min-h-screen">
        <div className="p-4 md:p-6 lg:p-8 pt-14 lg:pt-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}