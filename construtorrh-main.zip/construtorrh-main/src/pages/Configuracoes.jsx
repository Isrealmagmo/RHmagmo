import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Settings, Save, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import PageHeader from '@/components/ui/PageHeader';
import { cn } from '@/lib/utils';

const INSS_FAIXAS = [
  { faixa: 'Até R$ 1.412,00', aliquota: '7,5%' },
  { faixa: 'De R$ 1.412,01 a R$ 2.666,68', aliquota: '9,0%' },
  { faixa: 'De R$ 2.666,69 a R$ 4.000,03', aliquota: '12,0%' },
  { faixa: 'De R$ 4.000,04 a R$ 7.786,02', aliquota: '14,0%' },
];

export default function Configuracoes() {
  const queryClient = useQueryClient();
  const [expandedSection, setExpandedSection] = useState('descontos');

  const { data: configs = [] } = useQuery({
    queryKey: ['configs'],
    queryFn: () => base44.entities.ConfiguracaoSistema.list(),
  });

  const [vtAliquota, setVtAliquota] = useState(6);
  const [usarInssProgressivo, setUsarInssProgressivo] = useState(true);
  const [inssAliquotaFixa, setInssAliquotaFixa] = useState(7.5);
  const [irAliquota, setIrAliquota] = useState(0);
  const [saved, setSaved] = useState(false);

  // Provisões & Encargos Patronais
  const [prov13Percent, setProv13Percent] = useState(8.33);
  const [provFeriasPercent, setProvFeriasPercent] = useState(8.33);
  const [prov1_3FeriasPercent, setProv1_3FeriasPercent] = useState(2.78);
  const [fgtsPercent, setFgtsPercent] = useState(8);
  const [inssEmpresaPercent, setInssEmpresaPercent] = useState(11);
  const [ratPercent, setRatPercent] = useState(3);
  const [inssColaboradorPercent, setInssColaboradorPercent] = useState(11);

  // Tipos de Documentos
  const [tiposDocumento, setTiposDocumento] = useState(['documento_pessoal', 'contrato', 'certificado', 'comprovante', 'outros']);
  const [novoTipo, setNovoTipo] = useState('');

  useEffect(() => {
    const cfg = configs.find(c => c.chave === 'descontos_clt');
    if (cfg?.valor) {
      setVtAliquota((cfg.valor.vt_aliquota ?? 0.06) * 100);
      setUsarInssProgressivo(cfg.valor.usar_inss_progressivo ?? true);
      setInssAliquotaFixa((cfg.valor.inss_aliquota_fixa ?? 0.075) * 100);
      setIrAliquota((cfg.valor.ir_aliquota ?? 0) * 100);
    }

    const provCfg = configs.find(c => c.chave === 'provisoes_encargos');
    if (provCfg?.valor) {
      setProv13Percent((provCfg.valor.prov_13_percent ?? 8.33) * 100);
      setProvFeriasPercent((provCfg.valor.prov_ferias_percent ?? 8.33) * 100);
      setProv1_3FeriasPercent((provCfg.valor.prov_1_3_ferias_percent ?? 2.78) * 100);
      setFgtsPercent((provCfg.valor.fgts_percent ?? 8) * 100);
      setInssEmpresaPercent((provCfg.valor.inss_empresa_percent ?? 11) * 100);
      setRatPercent((provCfg.valor.rat_percent ?? 3) * 100);
      setInssColaboradorPercent((provCfg.valor.inss_colaborador_percent ?? 11) * 100);
    }

    const docCfg = configs.find(c => c.chave === 'tipos_documentos');
    if (docCfg?.valor?.tipos) {
      setTiposDocumento(docCfg.valor.tipos);
    }
  }, [configs]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const existente = configs.find(c => c.chave === 'descontos_clt');
      const valor = {
        vt_aliquota: vtAliquota / 100,
        usar_inss_progressivo: usarInssProgressivo,
        inss_aliquota_fixa: inssAliquotaFixa / 100,
        ir_aliquota: irAliquota / 100,
      };
      if (existente) {
        await base44.entities.ConfiguracaoSistema.update(existente.id, { valor });
      } else {
        await base44.entities.ConfiguracaoSistema.create({ chave: 'descontos_clt', valor });
      }

      const provExistente = configs.find(c => c.chave === 'provisoes_encargos');
      const provValor = {
        prov_13_percent: prov13Percent / 100,
        prov_ferias_percent: provFeriasPercent / 100,
        prov_1_3_ferias_percent: prov1_3FeriasPercent / 100,
        fgts_percent: fgtsPercent / 100,
        inss_empresa_percent: inssEmpresaPercent / 100,
        rat_percent: ratPercent / 100,
        inss_colaborador_percent: inssColaboradorPercent / 100,
      };
      if (provExistente) {
        await base44.entities.ConfiguracaoSistema.update(provExistente.id, { valor: provValor });
      } else {
        await base44.entities.ConfiguracaoSistema.create({ chave: 'provisoes_encargos', valor: provValor });
      }

      const docExistente = configs.find(c => c.chave === 'tipos_documentos');
      const docValor = { tipos: tiposDocumento };
      if (docExistente) {
        await base44.entities.ConfiguracaoSistema.update(docExistente.id, { valor: docValor });
      } else {
        await base44.entities.ConfiguracaoSistema.create({ chave: 'tipos_documentos', valor: docValor });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['configs'] });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    },
  });

  const ConfigSection = ({ title, id, description, children }) => (
    <div className="border rounded-lg">
      <button
        onClick={() => setExpandedSection(expandedSection === id ? null : id)}
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-muted/30 transition"
      >
        <div className="flex-1 text-left">
          <h2 className="font-semibold">{title}</h2>
          {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
        </div>
        <ChevronDown className={cn("w-4 h-4 text-muted-foreground transition-transform", expandedSection === id && "rotate-180")} />
      </button>
      {expandedSection === id && (
        <div className="px-5 py-4 border-t bg-muted/20 space-y-4">
          {children}
        </div>
      )}
    </div>
  );

  return (
    <div>
      <PageHeader title="Configurações" subtitle="Configurações gerais do sistema" icon={Settings} />

      <div className="max-w-2xl space-y-3">
        <ConfigSection 
          title="Descontos CLT" 
          id="descontos"
          description="Configurações de desconto aplicadas automaticamente em Fechamentos para colaboradores CLT."
        >
          <div className="space-y-1.5">
            <Label>Desconto Vale Transporte (% sobre o salário bruto)</Label>
            <div className="flex items-center gap-3">
              <Input type="number" min={0} max={6} step={0.1} className="w-28" value={vtAliquota} onChange={e => setVtAliquota(Number(e.target.value))} />
              <span className="text-sm text-muted-foreground">% (máximo legal: 6%)</span>
            </div>
            <p className="text-xs text-muted-foreground">
              O desconto é limitado ao custo real do VT do colaborador quando o valor diário estiver configurado no cadastro.
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <Label>Usar tabela INSS progressiva (2024)</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Calcula cada faixa separadamente</p>
              </div>
              <Switch checked={usarInssProgressivo} onCheckedChange={setUsarInssProgressivo} />
            </div>

            {usarInssProgressivo ? (
              <div className="rounded-lg border overflow-hidden">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-muted">
                      <th className="text-left px-3 py-2 font-medium">Faixa Salarial</th>
                      <th className="text-right px-3 py-2 font-medium">Alíquota</th>
                    </tr>
                  </thead>
                  <tbody>
                    {INSS_FAIXAS.map((f, i) => (
                      <tr key={i} className="border-t">
                        <td className="px-3 py-2 text-muted-foreground">{f.faixa}</td>
                        <td className="px-3 py-2 text-right font-medium">{f.aliquota}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="space-y-1.5">
                <Label>Alíquota INSS fixa (%)</Label>
                <div className="flex items-center gap-3">
                  <Input type="number" min={0} max={14} step={0.5} className="w-28" value={inssAliquotaFixa} onChange={e => setInssAliquotaFixa(Number(e.target.value))} />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>Imposto de Renda (% sobre o salário bruto)</Label>
            <div className="flex items-center gap-3">
              <Input type="number" min={0} max={27.5} step={0.1} className="w-28" value={irAliquota} onChange={e => setIrAliquota(Number(e.target.value))} />
              <span className="text-sm text-muted-foreground">% (deixe 0 para desativar)</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Desconto aplicado apenas a colaboradores CLT com salário bruto acima da faixa de isenção.
            </p>
          </div>

          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-2 w-full">
            <Save className="w-4 h-4" />
            {saved ? 'Salvo!' : 'Salvar'}
          </Button>
        </ConfigSection>

        <ConfigSection 
          title="Provisões & Encargos Patronais" 
          id="provisoes"
          description="Percentuais para provisões de rescisão e encargos patronais."
        >
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Prov. 13º Salário (%)</Label>
              <Input type="number" min={0} max={100} step={0.01} className="w-full" value={prov13Percent} onChange={e => setProv13Percent(Number(e.target.value))} />
              <p className="text-xs text-muted-foreground">Padrão: 8.33% (1/12)</p>
            </div>
            <div className="space-y-1.5">
              <Label>Prov. Férias (%)</Label>
              <Input type="number" min={0} max={100} step={0.01} className="w-full" value={provFeriasPercent} onChange={e => setProvFeriasPercent(Number(e.target.value))} />
              <p className="text-xs text-muted-foreground">Padrão: 8.33% (1/12)</p>
            </div>
            <div className="space-y-1.5">
              <Label>Prov. 1/3 Férias (%)</Label>
              <Input type="number" min={0} max={100} step={0.01} className="w-full" value={prov1_3FeriasPercent} onChange={e => setProv1_3FeriasPercent(Number(e.target.value))} />
              <p className="text-xs text-muted-foreground">Padrão: 2.78% (1/3 de férias)</p>
            </div>
            <div className="space-y-1.5">
              <Label>FGTS (%)</Label>
              <Input type="number" min={0} max={100} step={0.01} className="w-full" value={fgtsPercent} onChange={e => setFgtsPercent(Number(e.target.value))} />
              <p className="text-xs text-muted-foreground">Padrão: 8%</p>
            </div>
          </div>

          <div className="border-t pt-4 space-y-4">
            <h3 className="font-medium">Encargos Patronais</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>INSS Empresa (%)</Label>
                <Input type="number" min={0} max={100} step={0.01} className="w-full" value={inssEmpresaPercent} onChange={e => setInssEmpresaPercent(Number(e.target.value))} />
                <p className="text-xs text-muted-foreground">Padrão: 11%</p>
              </div>
              <div className="space-y-1.5">
                <Label>RAT - Risco Acidente Trabalho (%)</Label>
                <Input type="number" min={0} max={100} step={0.01} className="w-full" value={ratPercent} onChange={e => setRatPercent(Number(e.target.value))} />
                <p className="text-xs text-muted-foreground">Padrão: 3%</p>
              </div>
              <div className="space-y-1.5">
                <Label>INSS Colaborador (%)</Label>
                <Input type="number" min={0} max={100} step={0.01} className="w-full" value={inssColaboradorPercent} onChange={e => setInssColaboradorPercent(Number(e.target.value))} />
                <p className="text-xs text-muted-foreground">Desconto do colaborador (folha)</p>
              </div>
            </div>
          </div>

          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-2 w-full">
            <Save className="w-4 h-4" />
            {saved ? 'Salvo!' : 'Salvar'}
          </Button>
        </ConfigSection>

        <ConfigSection 
          title="Tipos de Documentos" 
          id="documentos"
          description="Configure tipos de documentos disponíveis para colaboradores."
        >
          <div className="space-y-3">
            {tiposDocumento.map((tipo, idx) => (
              <div key={idx} className="flex items-center justify-between bg-muted/30 p-3 rounded border">
                <span className="font-medium capitalize">{tipo.replace(/_/g, ' ')}</span>
                <button
                  onClick={() => setTiposDocumento(tiposDocumento.filter((_, i) => i !== idx))}
                  className="text-destructive hover:text-destructive/80 text-sm font-medium"
                >
                  Remover
                </button>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Input
              placeholder="Ex: diploma, certidão"
              value={novoTipo}
              onChange={e => setNovoTipo(e.target.value)}
              className="flex-1"
            />
            <Button
              onClick={() => {
                if (novoTipo.trim() && !tiposDocumento.includes(novoTipo.toLowerCase())) {
                  setTiposDocumento([...tiposDocumento, novoTipo.toLowerCase()]);
                  setNovoTipo('');
                }
              }}
              variant="outline"
            >
              Adicionar
            </Button>
          </div>

          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-2 w-full">
            <Save className="w-4 h-4" />
            {saved ? 'Salvo!' : 'Salvar'}
          </Button>
        </ConfigSection>
      </div>
    </div>
  );
}