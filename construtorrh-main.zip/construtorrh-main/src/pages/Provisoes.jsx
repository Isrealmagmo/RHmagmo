import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { DollarSign, Download, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';

function SummaryCard({ label, value, sublabel, color }) {
  const colors = { red: 'bg-red-500', green: 'bg-green-500', yellow: 'bg-yellow-500', blue: 'bg-blue-500', orange: 'bg-orange-500' };
  return (
    <Card className={`${colors[color] || 'bg-primary'} text-white`}>
      <CardContent className="p-4">
        <p className="text-xs font-medium opacity-80 uppercase">{label}</p>
        <p className="text-xl font-bold mt-1">R$ {value}</p>
        <p className="text-xs opacity-70 mt-0.5">{sublabel}</p>
      </CardContent>
    </Card>
  );
}

export default function Provisoes() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState('provisoes');
  const [selectedColab, setSelectedColab] = useState(null);

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-fechamento', month, year],
    queryFn: () => base44.entities.Pagamento.filter({ mes: month, ano: year, tipo: 'quinzena' }),
  });

  const cltColabs = useMemo(() => colaboradores.filter(c => c.tipo_contrato === 'clt'), [colaboradores]);

  const salarioBrutoByColab = useMemo(() => {
    const map = {};
    pagamentos.forEach(p => {
      if (!map[p.colaborador_id]) {
        map[p.colaborador_id] = { nome: p.colaborador_nome, total: 0, q1: 0, q2: 0 };
      }
      map[p.colaborador_id].total += p.valor || 0;
      if (p.quinzena === 1) map[p.colaborador_id].q1 += p.valor || 0;
      if (p.quinzena === 2) map[p.colaborador_id].q2 += p.valor || 0;
    });
    return map;
  }, [pagamentos]);

  // Cálculo de provisões de rescisão (13º, férias, 1/3, FGTS, multa FGTS)
  const calcularProvisoes = (salarioBruto) => {
    const prov13 = salarioBruto / 12;
    const provFerias = salarioBruto / 12;
    const prov1_3Ferias = provFerias / 3;
    const fgts = salarioBruto * 0.08;
    const multaFgts40 = fgts * 0.4;
    return { prov13, provFerias, prov1_3Ferias, fgts, multaFgts40 };
  };

  // Encargos patronais (INSS empresa 11% + RAT 3%)
  const calcularEncargosPatronais = (salarioBruto) => {
    const insssEmpresa = salarioBruto * 0.11;
    const rat = salarioBruto * 0.03;
    const totalEncargos = insssEmpresa + rat;
    return { insssEmpresa, rat, totalEncargos };
  };

  const filtered = useMemo(() => {
    if (!search.trim()) return cltColabs;
    const s = search.toLowerCase();
    return cltColabs.filter(c => c.nome?.toLowerCase().includes(s) || c.chapa?.toLowerCase().includes(s));
  }, [cltColabs, search]);

  const totais = useMemo(() => {
    let totalSalarioBruto = 0, totalProv13 = 0, totalFgts = 0, totalProvFerias = 0, totalProv1_3Ferias = 0, totalMultaFgts = 0;
    let totalInsssEmpresa = 0, totalRat = 0, totalInssColaborador = 0;
    
    filtered.forEach(c => {
      const salBruto = salarioBrutoByColab[c.id]?.total || 0;
      const { prov13, provFerias, prov1_3Ferias, fgts, multaFgts40 } = calcularProvisoes(salBruto);
      const { insssEmpresa, rat } = calcularEncargosPatronais(salBruto);
      const inssColab = salBruto * 0.11; // 11% do colaborador
      
      totalSalarioBruto += salBruto;
      totalProv13 += prov13;
      totalFgts += fgts;
      totalProvFerias += provFerias;
      totalProv1_3Ferias += prov1_3Ferias;
      totalMultaFgts += multaFgts40;
      totalInsssEmpresa += insssEmpresa;
      totalRat += rat;
      totalInssColaborador += inssColab;
    });

    const totalEncargos = totalInsssEmpresa + totalRat;
    const totalProvisoes = totalProv13 + totalFgts + totalProvFerias + totalProv1_3Ferias + totalMultaFgts;

    return {
      salarioBruto: totalSalarioBruto,
      prov13: totalProv13,
      fgts: totalFgts,
      provFerias: totalProvFerias,
      prov1_3Ferias: totalProv1_3Ferias,
      multaFgts: totalMultaFgts,
      provisoes: totalProvisoes,
      insssEmpresa: totalInsssEmpresa,
      rat: totalRat,
      encargos: totalEncargos,
      inssColaborador: totalInssColaborador,
    };
  }, [filtered, salarioBrutoByColab]);

  const fmt = (n) => n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div>
      <PageHeader title="Provisões & Rescisão" subtitle="Apuração de encargos patronais e provisões de rescisão para colaboradores CLT" />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="resumo">Resumo Geral</TabsTrigger>
          <TabsTrigger value="provisoes">Provisões de Rescisão</TabsTrigger>
          <TabsTrigger value="encargos">Encargos Patronais</TabsTrigger>
        </TabsList>

        {/* ABA 0: RESUMO GERAL */}
        <TabsContent value="resumo" className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <SummaryCard label="SALÁRIO BRUTO TOTAL" value={fmt(totais.salarioBruto)} sublabel={`${filtered.length} colaboradores`} color="red" />
            <SummaryCard label="TOTAL PROVISÕES" value={fmt(totais.provisoes)} sublabel="13º + FGTS + Férias" color="green" />
            <SummaryCard label="ENCARGOS PATRONAIS" value={fmt(totais.encargos)} sublabel="INSS + RAT (14%)" color="blue" />
            <SummaryCard label="INSS COLABORADOR" value={fmt(totais.inssColaborador || 0)} sublabel="Desconto folha" color="orange" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Coluna 1: Provisões */}
            <div className="border rounded-lg p-4 bg-gradient-to-br from-green-50 to-transparent">
              <h3 className="font-bold text-lg mb-3 text-green-900">Provisões de Rescisão</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span>13º Salário:</span><span className="font-semibold">R$ {fmt(totais.prov13)}</span></div>
                <div className="flex justify-between"><span>Férias:</span><span className="font-semibold">R$ {fmt(totais.provFerias)}</span></div>
                <div className="flex justify-between"><span>1/3 Férias:</span><span className="font-semibold">R$ {fmt(totais.prov1_3Ferias)}</span></div>
                <div className="flex justify-between"><span>FGTS 8%:</span><span className="font-semibold">R$ {fmt(totais.fgts)}</span></div>
                <div className="flex justify-between"><span>Multa FGTS 40%:</span><span className="font-semibold">R$ {fmt(totais.multaFgts)}</span></div>
                <div className="border-t pt-2 mt-2 flex justify-between font-bold text-green-900 bg-green-100 p-2 rounded">
                  <span>TOTAL PROVISÕES:</span><span>R$ {fmt(totais.provisoes)}</span>
                </div>
              </div>
            </div>

            {/* Coluna 2: Encargos */}
            <div className="border rounded-lg p-4 bg-gradient-to-br from-blue-50 to-transparent">
              <h3 className="font-bold text-lg mb-3 text-blue-900">Encargos Patronais + INSS Colaborador</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span>Salário Bruto:</span><span className="font-semibold">R$ {fmt(totais.salarioBruto)}</span></div>
                <div className="flex justify-between"><span>INSS Empresa (11%):</span><span className="font-semibold">R$ {fmt(totais.insssEmpresa)}</span></div>
                <div className="flex justify-between"><span>RAT (3%):</span><span className="font-semibold">R$ {fmt(totais.rat)}</span></div>
                <div className="flex justify-between"><span>INSS Colaborador (11%):</span><span className="font-semibold">R$ {fmt(totais.inssColaborador || 0)}</span></div>
                <div className="border-t pt-2 mt-2 flex justify-between font-bold text-blue-900 bg-blue-100 p-2 rounded">
                  <span>TOTAL ENCARGOS:</span><span>R$ {fmt(totais.encargos + (totais.inssColaborador || 0))}</span>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* ABA 1: PROVISÕES DE RESCISÃO */}
        <TabsContent value="provisoes" className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <SummaryCard label="SALÁRIO BRUTO" value={fmt(totais.salarioBruto)} sublabel={`${filtered.length} colaboradores`} color="red" />
            <SummaryCard label="PROV. 13º SALÁRIO" value={fmt(totais.prov13)} sublabel="1/12 do salário" color="yellow" />
            <SummaryCard label="PROV. FÉRIAS + 1/3" value={fmt(totais.provFerias + totais.prov1_3Ferias)} sublabel="Férias acrescidas" color="blue" />
            <SummaryCard label="FGTS + MULTA 40%" value={fmt(totais.fgts + totais.multaFgts)} sublabel="8% + multa rescisória" color="orange" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-3 bg-muted/30 p-4 rounded-lg">
            <div><p className="text-xs text-muted-foreground uppercase">Prov. 13º</p><p className="text-lg font-bold">R$ {fmt(totais.prov13)}</p></div>
            <div><p className="text-xs text-muted-foreground uppercase">FGTS 8%</p><p className="text-lg font-bold">R$ {fmt(totais.fgts)}</p></div>
            <div><p className="text-xs text-muted-foreground uppercase">Multa FGTS 40%</p><p className="text-lg font-bold">R$ {fmt(totais.multaFgts)}</p></div>
            <div><p className="text-xs text-muted-foreground uppercase">Férias</p><p className="text-lg font-bold">R$ {fmt(totais.provFerias)}</p></div>
            <div><p className="text-xs text-muted-foreground uppercase">1/3 Férias</p><p className="text-lg font-bold">R$ {fmt(totais.prov1_3Ferias)}</p></div>
          </div>

          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div>
                <p className="text-sm font-medium">Período</p>
                <select value={month} onChange={e => setMonth(Number(e.target.value))} className="mt-1 px-2 py-1 border rounded text-sm">
                  {['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'].map((m, i) => <option key={i} value={i+1}>{m}</option>)}
                </select>
              </div>
              <div>
                <p className="text-sm font-medium">Ano</p>
                <select value={year} onChange={e => setYear(Number(e.target.value))} className="mt-1 px-2 py-1 border rounded text-sm">
                  {[2024,2025,2026,2027].map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium">Buscar Colaborador</p>
              <Input placeholder="Nome, chapa..." className="mt-1 w-72" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>

          <div className="border rounded-lg overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted">
                  <th className="px-3 py-3 text-left">Colaborador</th>
                  <th className="px-3 py-3 text-right">Acumulado</th>
                  <th className="px-3 py-3 text-right">13º</th>
                  <th className="px-3 py-3 text-right">FGTS</th>
                  <th className="px-3 py-3 text-right">Multa 40%</th>
                  <th className="px-3 py-3 text-right">Férias</th>
                  <th className="px-3 py-3 text-right">1/3 Férias</th>
                  <th className="px-3 py-3 text-right">Total</th>
                  <th className="px-3 py-3 text-center">Ação</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan={9} className="text-center py-8 text-muted-foreground">Nenhum colaborador encontrado</td></tr>
                ) : (
                  <>
                    {filtered.map(c => {
                      const salBruto = salarioBrutoByColab[c.id]?.total || 0;
                      const { prov13, provFerias, prov1_3Ferias, fgts, multaFgts40 } = calcularProvisoes(salBruto);
                      const totalProv = prov13 + fgts + multaFgts40 + provFerias + prov1_3Ferias;
                      return (
                        <tr key={c.id} className="border-t hover:bg-muted/30">
                          <td className="px-3 py-3">
                            <p className="font-medium">{c.nome}</p>
                            <p className="text-xs text-muted-foreground">{c.chapa} · {c.funcao_nome}</p>
                          </td>
                          <td className="px-3 py-3 text-right font-semibold">R$ {fmt(salBruto)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(prov13)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(fgts)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(multaFgts40)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(provFerias)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(prov1_3Ferias)}</td>
                          <td className="px-3 py-3 text-right font-bold">R$ {fmt(totalProv)}</td>
                          <td className="px-3 py-3 text-center">
                            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setSelectedColab(c)}>
                              <Eye className="w-3.5 h-3.5" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="border-t bg-muted/50 font-semibold text-sm">
                      <td colSpan={1} className="px-3 py-3">TOTAL</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.salarioBruto)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.prov13)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.fgts)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.multaFgts)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.provFerias)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.prov1_3Ferias)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.provisoes)}</td>
                      <td></td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* ABA 2: ENCARGOS PATRONAIS */}
        <TabsContent value="encargos" className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <SummaryCard label="SALÁRIO BRUTO" value={fmt(totais.salarioBruto)} sublabel={`${filtered.length} colaboradores`} color="red" />
            <SummaryCard label="INSS EMPRESA (11%)" value={fmt(totais.insssEmpresa)} sublabel="Desconto da folha" color="blue" />
            <SummaryCard label="RAT (3%)" value={fmt(totais.rat)} sublabel="Risco de acidente" color="yellow" />
            <SummaryCard label="TOTAL ENCARGOS" value={fmt(totais.encargos)} sublabel="Custo empresa" color="orange" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 bg-blue-50 border border-blue-200 p-4 rounded-lg">
            <div>
              <p className="text-sm font-medium text-blue-900 uppercase">INSS Empresa</p>
              <p className="text-2xl font-bold text-blue-700 mt-1">R$ {fmt(totais.insssEmpresa)}</p>
              <p className="text-xs text-blue-600 mt-1">11% do salário bruto</p>
            </div>
            <div>
              <p className="text-sm font-medium text-blue-900 uppercase">RAT</p>
              <p className="text-2xl font-bold text-blue-700 mt-1">R$ {fmt(totais.rat)}</p>
              <p className="text-xs text-blue-600 mt-1">3% de risco de acidente</p>
            </div>
            <div>
              <p className="text-sm font-medium text-blue-900 uppercase">Total Encargos</p>
              <p className="text-2xl font-bold text-blue-700 mt-1">R$ {fmt(totais.encargos)}</p>
              <p className="text-xs text-blue-600 mt-1">14% do salário bruto</p>
            </div>
          </div>

          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div>
                <p className="text-sm font-medium">Período</p>
                <select value={month} onChange={e => setMonth(Number(e.target.value))} className="mt-1 px-2 py-1 border rounded text-sm">
                  {['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'].map((m, i) => <option key={i} value={i+1}>{m}</option>)}
                </select>
              </div>
              <div>
                <p className="text-sm font-medium">Ano</p>
                <select value={year} onChange={e => setYear(Number(e.target.value))} className="mt-1 px-2 py-1 border rounded text-sm">
                  {[2024,2025,2026,2027].map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium">Buscar Colaborador</p>
              <Input placeholder="Nome, chapa..." className="mt-1 w-72" value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>

          <div className="border rounded-lg overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-muted">
                  <th className="px-3 py-3 text-left">Colaborador</th>
                  <th className="px-3 py-3 text-right">Salário Bruto</th>
                  <th className="px-3 py-3 text-right">INSS Empresa (11%)</th>
                  <th className="px-3 py-3 text-right">RAT (3%)</th>
                  <th className="px-3 py-3 text-right">Total Encargos</th>
                  <th className="px-3 py-3 text-center">Ação</th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">Nenhum colaborador encontrado</td></tr>
                ) : (
                  <>
                    {filtered.map(c => {
                      const salBruto = salarioBrutoByColab[c.id]?.total || 0;
                      const { insssEmpresa, rat, totalEncargos } = calcularEncargosPatronais(salBruto);
                      return (
                        <tr key={c.id} className="border-t hover:bg-muted/30">
                          <td className="px-3 py-3">
                            <p className="font-medium">{c.nome}</p>
                            <p className="text-xs text-muted-foreground">{c.chapa} · {c.funcao_nome}</p>
                          </td>
                          <td className="px-3 py-3 text-right font-semibold">R$ {fmt(salBruto)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(insssEmpresa)}</td>
                          <td className="px-3 py-3 text-right">R$ {fmt(rat)}</td>
                          <td className="px-3 py-3 text-right font-bold">R$ {fmt(totalEncargos)}</td>
                          <td className="px-3 py-3 text-center">
                            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setSelectedColab(c)}>
                              <Eye className="w-3.5 h-3.5" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="border-t bg-muted/50 font-semibold text-sm">
                      <td colSpan={1} className="px-3 py-3">TOTAL</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.salarioBruto)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.insssEmpresa)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.rat)}</td>
                      <td className="px-3 py-3 text-right">R$ {fmt(totais.encargos)}</td>
                      <td></td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>

      {/* Modal de detalhes */}
      {selectedColab && (
        <Dialog open={!!selectedColab} onOpenChange={() => setSelectedColab(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{selectedColab.nome}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-sm">
                  <p className="text-muted-foreground">Chapa</p>
                  <p className="font-semibold">{selectedColab.chapa}</p>
                </div>
                <div className="text-sm">
                  <p className="text-muted-foreground">Função</p>
                  <p className="font-semibold">{selectedColab.funcao_nome}</p>
                </div>
              </div>

              {activeTab === 'provisoes' && (
                <>
                  <div className="border-t pt-4">
                    <h3 className="font-semibold mb-3">Provisões de Rescisão</h3>
                    <div className="space-y-2 text-sm">
                      {(() => {
                        const salBruto = salarioBrutoByColab[selectedColab.id]?.total || 0;
                        const { prov13, provFerias, prov1_3Ferias, fgts, multaFgts40 } = calcularProvisoes(salBruto);
                        const totalProv = prov13 + fgts + multaFgts40 + provFerias + prov1_3Ferias;
                        return (
                          <>
                            <div className="flex justify-between"><span>Salário Bruto:</span><span className="font-semibold">R$ {fmt(salBruto)}</span></div>
                            <div className="flex justify-between"><span>Prov. 13º (1/12):</span><span className="font-semibold">R$ {fmt(prov13)}</span></div>
                            <div className="flex justify-between"><span>FGTS 8%:</span><span className="font-semibold">R$ {fmt(fgts)}</span></div>
                            <div className="flex justify-between"><span>Multa FGTS 40%:</span><span className="font-semibold">R$ {fmt(multaFgts40)}</span></div>
                            <div className="flex justify-between"><span>Prov. Férias (1/12):</span><span className="font-semibold">R$ {fmt(provFerias)}</span></div>
                            <div className="flex justify-between"><span>1/3 Férias:</span><span className="font-semibold">R$ {fmt(prov1_3Ferias)}</span></div>
                            <div className="border-t pt-2 mt-2 flex justify-between bg-muted/30 p-2 rounded font-bold">
                              <span>TOTAL PROVISÕES:</span><span>R$ {fmt(totalProv)}</span>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'encargos' && (
                <>
                  <div className="border-t pt-4">
                    <h3 className="font-semibold mb-3">Encargos Patronais</h3>
                    <div className="space-y-2 text-sm">
                      {(() => {
                        const salBruto = salarioBrutoByColab[selectedColab.id]?.total || 0;
                        const { insssEmpresa, rat, totalEncargos } = calcularEncargosPatronais(salBruto);
                        return (
                          <>
                            <div className="flex justify-between"><span>Salário Bruto:</span><span className="font-semibold">R$ {fmt(salBruto)}</span></div>
                            <div className="flex justify-between"><span>INSS Empresa (11%):</span><span className="font-semibold">R$ {fmt(insssEmpresa)}</span></div>
                            <div className="flex justify-between"><span>RAT (3%):</span><span className="font-semibold">R$ {fmt(rat)}</span></div>
                            <div className="border-t pt-2 mt-2 flex justify-between bg-muted/30 p-2 rounded font-bold">
                              <span>TOTAL ENCARGOS:</span><span>R$ {fmt(totalEncargos)}</span>
                            </div>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}