import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Building2, Plus, Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';

const emptyObra = {
  nome: '', codigo: '', cnpj: '', cliente: '', endereco: '',
  responsavel: '', data_inicio: '', data_previsao: '', status: 'em_andamento',
  horario_seg_qui_entrada: '07:00', horario_seg_qui_saida_almoco: '12:00',
  horario_seg_qui_retorno_almoco: '13:00', horario_seg_qui_saida: '17:00',
  horario_sex_entrada: '07:00', horario_sex_saida_almoco: '12:00',
  horario_sex_retorno_almoco: '13:00', horario_sex_saida: '16:00',
  horario_sab_entrada: '07:00', horario_sab_saida: '14:00',
};

export default function Obras() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingObra, setEditingObra] = useState(null);
  const [form, setForm] = useState(emptyObra);
  const queryClient = useQueryClient();

  const { data: obras = [], isLoading } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list(),
  });

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editingObra
      ? base44.entities.Obra.update(editingObra.id, data)
      : base44.entities.Obra.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['obras'] });
      setDialogOpen(false);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Obra.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['obras'] }),
  });

  const resetForm = () => { setForm(emptyObra); setEditingObra(null); };

  const openNew = () => { resetForm(); setDialogOpen(true); };

  const openEdit = (obra) => {
    setEditingObra(obra);
    setForm({
      nome: obra.nome || '', codigo: obra.codigo || '', cnpj: obra.cnpj || '',
      cliente: obra.cliente || '', endereco: obra.endereco || '', responsavel: obra.responsavel || '',
      data_inicio: obra.data_inicio || '', data_previsao: obra.data_previsao || '', status: obra.status || 'em_andamento',
      horario_seg_qui_entrada: obra.horario_seg_qui_entrada || '07:00',
      horario_seg_qui_saida_almoco: obra.horario_seg_qui_saida_almoco || '12:00',
      horario_seg_qui_retorno_almoco: obra.horario_seg_qui_retorno_almoco || '13:00',
      horario_seg_qui_saida: obra.horario_seg_qui_saida || '17:00',
      horario_sex_entrada: obra.horario_sex_entrada || '07:00',
      horario_sex_saida_almoco: obra.horario_sex_saida_almoco || '12:00',
      horario_sex_retorno_almoco: obra.horario_sex_retorno_almoco || '13:00',
      horario_sex_saida: obra.horario_sex_saida || '16:00',
      horario_sab_entrada: obra.horario_sab_entrada || '07:00',
      horario_sab_saida: obra.horario_sab_saida || '14:00',
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!form.nome) return;
    saveMutation.mutate(form);
  };

  const colabCount = (obraId) => colaboradores.filter(c => c.obra_id === obraId).length;

  return (
    <div>
      <PageHeader title="Obras" subtitle={`${obras.length} obra(s) cadastrada(s)`}>
        <Button onClick={openNew} className="gap-1.5">
          <Plus className="w-4 h-4" /> Nova Obra
        </Button>
      </PageHeader>

      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">Carregando...</div>
        ) : obras.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">Nenhuma obra cadastrada</div>
        ) : (
          obras.map(obra => (
            <div key={obra.id} className="bg-card rounded-xl border p-4 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-muted rounded-xl flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{obra.nome}</p>
                  <p className="text-xs text-muted-foreground">
                    {[obra.codigo, obra.endereco].filter(Boolean).join(' · ')}
                    {colabCount(obra.id) > 0 && ` · ${colabCount(obra.id)} colaborador(es)`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={obra.status} />
                <Button variant="ghost" size="icon" onClick={() => openEdit(obra)}>
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMutation.mutate(obra.id)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingObra ? 'Editar Obra' : 'Nova Obra'}</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="dados">
            <TabsList className="w-full">
              <TabsTrigger value="dados" className="flex-1">Dados da Obra</TabsTrigger>
              <TabsTrigger value="horarios" className="flex-1">⏰ Horários Padrão</TabsTrigger>
            </TabsList>

            <TabsContent value="dados" className="space-y-4 mt-4">
              <div>
                <Label>Nome da obra *</Label>
                <Input value={form.nome} onChange={e => setForm({...form, nome: e.target.value})} placeholder="Nome da obra" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Código</Label><Input value={form.codigo} onChange={e => setForm({...form, codigo: e.target.value})} placeholder="Ex: 7007-8" /></div>
                <div><Label>CNPJ</Label><Input value={form.cnpj} onChange={e => setForm({...form, cnpj: e.target.value})} placeholder="CNPJ" /></div>
              </div>
              <div><Label>Cliente</Label><Input value={form.cliente} onChange={e => setForm({...form, cliente: e.target.value})} /></div>
              <div><Label>Endereço</Label><Input value={form.endereco} onChange={e => setForm({...form, endereco: e.target.value})} /></div>
              <div><Label>Responsável</Label><Input value={form.responsavel} onChange={e => setForm({...form, responsavel: e.target.value})} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Início</Label><Input type="date" value={form.data_inicio} onChange={e => setForm({...form, data_inicio: e.target.value})} /></div>
                <div><Label>Previsão</Label><Input type="date" value={form.data_previsao} onChange={e => setForm({...form, data_previsao: e.target.value})} /></div>
              </div>
              <Select value={form.status} onValueChange={v => setForm({...form, status: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  <SelectItem value="concluida">Concluída</SelectItem>
                  <SelectItem value="paralisada">Paralisada</SelectItem>
                  <SelectItem value="cancelada">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </TabsContent>

            <TabsContent value="horarios" className="space-y-4 mt-4">
              <p className="text-xs text-muted-foreground bg-blue-50 text-blue-700 px-3 py-2 rounded-lg">
                Esses horários serão preenchidos automaticamente ao marcar presença no ponto.
              </p>

              <div className="border rounded-lg p-3 space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Segunda a Quinta</p>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="text-xs">Entrada</Label><Input type="time" value={form.horario_seg_qui_entrada} onChange={e => setForm({...form, horario_seg_qui_entrada: e.target.value})} /></div>
                  <div><Label className="text-xs">Saída</Label><Input type="time" value={form.horario_seg_qui_saida} onChange={e => setForm({...form, horario_seg_qui_saida: e.target.value})} /></div>
                  <div><Label className="text-xs">Saída Almoço</Label><Input type="time" value={form.horario_seg_qui_saida_almoco} onChange={e => setForm({...form, horario_seg_qui_saida_almoco: e.target.value})} /></div>
                  <div><Label className="text-xs">Retorno Almoço</Label><Input type="time" value={form.horario_seg_qui_retorno_almoco} onChange={e => setForm({...form, horario_seg_qui_retorno_almoco: e.target.value})} /></div>
                </div>
              </div>

              <div className="border rounded-lg p-3 space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sexta-feira</p>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="text-xs">Entrada</Label><Input type="time" value={form.horario_sex_entrada} onChange={e => setForm({...form, horario_sex_entrada: e.target.value})} /></div>
                  <div><Label className="text-xs">Saída</Label><Input type="time" value={form.horario_sex_saida} onChange={e => setForm({...form, horario_sex_saida: e.target.value})} /></div>
                  <div><Label className="text-xs">Saída Almoço</Label><Input type="time" value={form.horario_sex_saida_almoco} onChange={e => setForm({...form, horario_sex_saida_almoco: e.target.value})} /></div>
                  <div><Label className="text-xs">Retorno Almoço</Label><Input type="time" value={form.horario_sex_retorno_almoco} onChange={e => setForm({...form, horario_sex_retorno_almoco: e.target.value})} /></div>
                </div>
              </div>

              <div className="border rounded-lg p-3 space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sábado (sem almoço)</p>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="text-xs">Entrada</Label><Input type="time" value={form.horario_sab_entrada} onChange={e => setForm({...form, horario_sab_entrada: e.target.value})} /></div>
                  <div><Label className="text-xs">Saída</Label><Input type="time" value={form.horario_sab_saida} onChange={e => setForm({...form, horario_sab_saida: e.target.value})} /></div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending}>Salvar</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}