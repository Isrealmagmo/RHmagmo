import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function VTTrechoModal({ open, onOpenChange, trecho, onSave }) {
  const [form, setForm] = useState(trecho || { tipo: 'onibus', valor: 0, linha: '', nome_linha: '' });

  useEffect(() => {
    if (trecho) setForm(trecho);
  }, [trecho, open]);

  const handleSave = () => {
    if (!form.linha || !form.nome_linha) {
      alert('Preencha linha e nome da linha');
      return;
    }
    onSave(form);
    onOpenChange(false);
  };

  const tipoEmoji = { onibus: '🚌', metro: '🚇', trem: '🚂', van: '🚐' };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Editar Trecho de Transporte</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div>
            <Label>Tipo de Transporte</Label>
            <Select value={form.tipo} onValueChange={v => setForm(prev => ({ ...prev, tipo: v }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="onibus">🚌 Ônibus</SelectItem>
                <SelectItem value="metro">🚇 Metrô</SelectItem>
                <SelectItem value="trem">🚂 Trem</SelectItem>
                <SelectItem value="van">🚐 Van</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Número da Linha</Label>
              <Input
                placeholder="Ex: 2050"
                value={form.linha}
                onChange={e => setForm(prev => ({ ...prev, linha: e.target.value }))}
              />
            </div>
            <div>
              <Label>Nome da Linha</Label>
              <Input
                placeholder="Ex: Metrô A-Vermelha"
                value={form.nome_linha}
                onChange={e => setForm(prev => ({ ...prev, nome_linha: e.target.value }))}
              />
            </div>
          </div>

          <div>
            <Label>Valor (R$)</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={form.valor}
              onChange={e => setForm(prev => ({ ...prev, valor: parseFloat(e.target.value) || 0 }))}
            />
          </div>

          <div className="bg-muted/30 p-3 rounded border">
            <p className="text-xs text-muted-foreground mb-1">Prévia:</p>
            <div className="flex items-center gap-2">
              <span className="text-lg">{tipoEmoji[form.tipo] || '🚌'}</span>
              <span className="font-medium text-sm">{form.nome_linha || 'Linha N/A'}</span>
              <span className="ml-auto font-bold text-primary">
                R$ {Number(form.valor || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter className="mt-6">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSave}>Salvar Trecho</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}