import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { EPI_CATEGORIES } from '@/utils/epiCatalogData';

export default function LoadDefaultEpiCatalogo() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const queryClient = useQueryClient();

  const handleLoadDefault = async () => {
    setLoading(true);
    setMessage(null);
    try {
      let loaded = 0;
      for (const category of EPI_CATEGORIES) {
        for (const epi of category.epis) {
          // Verificar se já existe
          const existing = await base44.entities.EpiCatalogo.filter({
            nome: epi.nome,
          });
          
          if (existing.length === 0) {
            await base44.entities.EpiCatalogo.create({
              nome: epi.nome,
              requer_tamanho: epi.requer_tamanho || false,
              validade_meses: epi.validade_meses || 12,
              categoria: epi.categoria || 'outros',
              descricao: `${category.category} - ${epi.nome}`,
            });
            loaded++;
          }
        }
      }
      setMessage({ type: 'success', text: `✓ Catálogo padrão carregado! ${loaded} EPIs adicionados.` });
      queryClient.invalidateQueries({ queryKey: ['epi_catalogo'] });
    } catch (error) {
      setMessage({ type: 'error', text: `✗ Erro ao carregar: ${error.message}` });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="border rounded-lg p-4 bg-muted/30 mb-4">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-semibold text-sm mb-1">Catálogo Padrão de EPIs</h3>
          <p className="text-xs text-muted-foreground">Carregue a lista completa com 10 categorias e mais de 70 EPIs</p>
        </div>
        <Button
          onClick={handleLoadDefault}
          disabled={loading}
          className="gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Carregando...
            </>
          ) : (
            'Carregar Catálogo Padrão'
          )}
        </Button>
      </div>
      {message && (
        <div className={`mt-3 p-2 rounded text-xs flex gap-2 ${
          message.type === 'success' 
            ? 'bg-green-100 text-green-700' 
            : 'bg-red-100 text-red-700'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          )}
          <span>{message.text}</span>
        </div>
      )}
    </div>
  );
}