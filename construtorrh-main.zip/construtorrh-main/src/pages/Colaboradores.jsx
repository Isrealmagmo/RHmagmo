import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Users, Plus, Pencil, Trash2, Search, Settings2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';
import ColaboradorForm from '@/components/colaboradores/ColaboradorForm';
import FuncoesDialog from '@/components/colaboradores/FuncoesDialog';

export default function Colaboradores() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [funcoesOpen, setFuncoesOpen] = useState(false);
  const [editingColab, setEditingColab] = useState(null);
  const [search, setSearch] = useState('');
  const [deactivateOpen, setDeactivateOpen] = useState(false);
  const [deactivateColab, setDeactivateColab] = useState(null);
  const [deactivateStatus, setDeactivateStatus] = useState('inativo');
  const queryClient = useQueryClient();

  const { data: colaboradores = [], isLoading } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });

  const { data: registrosPonto = [] } = useQuery({
    queryKey: ['registros-ponto'],
    queryFn: () => base44.entities.RegistroPonto.list(),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editingColab
      ? base44.entities.Colaborador.update(editingColab.id, data)
      : base44.entities.Colaborador.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['colaboradores'] });
      setDialogOpen(false);
      setEditingColab(null);
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: (colabId) => base44.entities.Colaborador.update(colabId, { status: deactivateStatus }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['colaboradores'] });
      setDeactivateOpen(false);
      setDeactivateColab(null);
      setDeactivateStatus('inativo');
    },
  });

  const temPonto = (colabId) => registrosPonto.some(r => r.colaborador_id === colabId);

  const handleDeleteClick = (colab) => {
    if (temPonto(colab.id)) {
      setDeactivateColab(colab);
      setDeactivateOpen(true);
    }
  };

  const filtered = useMemo(() => {
    if (!search) return colaboradores;
    const s = search.toLowerCase();
    return colaboradores.filter(c =>
      c.nome?.toLowerCase().includes(s) ||
      c.chapa?.toLowerCase().includes(s) ||
      c.funcao_nome?.toLowerCase().includes(s)
    );
  }, [colaboradores, search]);

  const openNew = () => { setEditingColab(null); setDialogOpen(true); };
  const openEdit = (c) => { setEditingColab(c); setDialogOpen(true); };

  const ativos = colaboradores.filter(c => c.status === 'ativo').length;
  const colorMap = { 'S': 'border-l-blue-500', 'G': 'border-l-green-500', 'I': 'border-l-yellow-500' };

  return (
    <div>
      <PageHeader title="Colaboradores" subtitle={`${ativos} ativo(s) · ${colaboradores.length} total`}>
        <Button variant="outline" onClick={() => setFuncoesOpen(true)} className="gap-1.5">
          <Settings2 className="w-4 h-4" /> Funções
        </Button>
        <Button onClick={openNew} className="gap-1.5">
          <Plus className="w-4 h-4" /> Novo Colaborador
        </Button>
      </PageHeader>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Buscar por nome, chapa ou função..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">Carregando...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">Nenhum colaborador encontrado</div>
        ) : (
          filtered.map(col => (
            <div key={col.id} className="bg-card rounded-xl border border-l-4 border-l-blue-500 p-4 flex items-center justify-between hover:shadow-sm transition-shadow">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-muted rounded-full flex items-center justify-center text-sm font-bold text-muted-foreground">
                  {col.nome?.charAt(0)?.toUpperCase()}
                </div>
                <div>
                  <p className="font-semibold text-sm">{col.nome}</p>
                  <p className="text-xs text-muted-foreground">
                    {[
                      col.chapa,
                      col.funcao_nome,
                      col.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo',
                      col.salario && `R$${col.salario.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                      col.obra_nome,
                    ].filter(Boolean).join(' · ')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <StatusBadge status={col.status} />
                <Button variant="ghost" size="icon" onClick={() => openEdit(col)}>
                   <Pencil className="w-4 h-4" />
                 </Button>
                 <Button 
                   variant="ghost" 
                   size="icon" 
                   className="text-destructive"
                   onClick={() => handleDeleteClick(col)}
                   title={temPonto(col.id) ? 'Com ponto lançado: desativar em vez de deletar' : 'Deletar colaborador'}
                 >
                   <Trash2 className="w-4 h-4" />
                 </Button>
              </div>
            </div>
          ))
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingColab ? 'Editar Colaborador' : 'Novo Colaborador'}</DialogTitle>
          </DialogHeader>
          <ColaboradorForm
            colaborador={editingColab}
            onSave={(data) => saveMutation.mutate(data)}
            onCancel={() => setDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <FuncoesDialog open={funcoesOpen} onOpenChange={setFuncoesOpen} />

      <Dialog open={deactivateOpen} onOpenChange={setDeactivateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Desativar Colaborador</DialogTitle>
            <DialogDescription>
              {deactivateColab?.nome} tem registros de ponto lançados. Escolha o novo status para preservar o histórico.
            </DialogDescription>
          </DialogHeader>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 flex gap-2">
            <AlertCircle className="w-4 h-4 text-yellow-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-yellow-700">Este colaborador não pode ser deletado para preservar o histórico de ponto. Escolha o motivo da desativação.</p>
          </div>

          <div>
            <label className="text-sm font-medium block mb-2">Novo Status</label>
            <Select value={deactivateStatus} onValueChange={setDeactivateStatus}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="inativo">Inativo</SelectItem>
                <SelectItem value="afastado">Afastado</SelectItem>
                <SelectItem value="ferias">Férias</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setDeactivateOpen(false)}>Cancelar</Button>
            <Button 
              onClick={() => deactivateMutation.mutate(deactivateColab?.id)}
              disabled={deactivateMutation.isPending}
              className="gap-1.5"
            >
              Desativar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}