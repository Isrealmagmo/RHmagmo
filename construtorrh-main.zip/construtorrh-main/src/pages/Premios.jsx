import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Award, Plus, Trash2, Lock, Pencil, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';

const emptyForm = { colaborador_id: '', colaborador_nome: '', descricao: '', valor: 0, data: '', motivo: '', status: 'pendente' };

export default function Premios() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const queryClient = useQueryClient();

  const { data: premios = [] } = useQuery({ queryKey: ['premios'], queryFn: () => base44.entities.Premio.list() });
  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });
  const { data: pagamentos = [] } = useQuery({ queryKey: ['pagamentos'], queryFn: () => base44.entities.Pagamento.list() });

  const saveMutation = useMutation({
    mutationFn: (data) => editingId
      ? base44.entities.Premio.update(editingId, data)
      : base44.entities.Premio.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['premios'] });
      setDialogOpen(false);
      setEditingId(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Premio.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['premios'] }); setConfirmDelete(null); },
  });

  const lancarPagamentoMutation = useMutation({
    mutationFn: async (premio) => {
      await base44.entities.Pagamento.create({
        colaborador_id: premio.colaborador_id,
        colaborador_nome: premio.colaborador_nome,
        tipo: 'premio',
        referencia: `Prêmio — ${premio.descricao || premio.motivo || ''}`,
        mes: new Date(premio.data || Date.now()).getMonth() + 1,
        ano: new Date(premio.data || Date.now()).getFullYear(),
        valor: premio.valor,
        status: 'pendente',
        descricao: premio.descricao || premio.motivo || 'Prêmio/Bônus',
      });
      await base44.entities.Premio.update(premio.id, { ...premio, status: 'pago' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['premios'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
    },
  });

  const openNew = () => {
    setForm(emptyForm);
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEdit = (premio) => {
    setForm({
      colaborador_id: premio.colaborador_id,
      colaborador_nome: premio.colaborador_nome,
      descricao: premio.descricao || '',
      valor: premio.valor || 0,
      data: premio.data || '',
      motivo: premio.motivo || '',
      status: premio.status || 'pendente',
    });
    setEditingId(premio.id);
    setDialogOpen(true);
  };

  const handleColabChange = (id) => {
    const col = colaboradores.find(c => c.id === id);
    setForm(prev => ({ ...prev, colaborador_id: id, colaborador_nome: col?.nome || '' }));
  };

  const temPagamento = (premio) => {
    return pagamentos.some(
      p => p.colaborador_id === premio.colaborador_id &&
           p.tipo === 'premio' &&
           p.status !== 'cancelado' &&
           p.referencia?.includes(premio.descricao)
    );
  };

  return (
    <div>
      <PageHeader title="Prêmios e Bônus" subtitle={`${premios.length} prêmio(s) registrado(s)`} icon={Award}>
        <Button onClick={openNew} className="gap-1.5"><Plus className="w-4 h-4" /> Novo Prêmio</Button>
      </PageHeader>

      {premios.length === 0 ? (
        <div className="text-center py-16">
          <Award className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground">Nenhum prêmio registrado</p>
        </div>
      ) : (
        <div className="space-y-2">
          {premios.map(p => {
            const pago = temPagamento(p);
            const isPago = p.status === 'pago';
            return (
              <div key={p.id} className="bg-card border rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{p.colaborador_nome}</p>
                  <p className="text-xs text-muted-foreground">{p.descricao} · R$ {p.valor?.toFixed(2)} · {p.data}</p>
                  {p.motivo && <p className="text-xs text-muted-foreground mt-0.5 italic">{p.motivo}</p>}
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={p.status} />
                  {isPago ? (
                    <span className="flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2 py-1 rounded-lg">
                      <Lock className="w-3 h-3" /> Pago — edite em Pagamentos
                    </span>
                  ) : (
                    <>
                      {!pago && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1 text-green-700 border-green-300 hover:bg-green-50"
                          onClick={() => lancarPagamentoMutation.mutate(p)}
                          disabled={lancarPagamentoMutation.isPending}
                        >
                          <CreditCard className="w-3.5 h-3.5" /> Lançar Pgto
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" onClick={() => openEdit(p)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setConfirmDelete(p)} className="text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Dialog Novo / Editar Prêmio */}
      <Dialog open={dialogOpen} onOpenChange={(v) => { setDialogOpen(v); if (!v) setEditingId(null); }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingId ? 'Editar Prêmio' : 'Novo Prêmio'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={form.colaborador_id} onValueChange={handleColabChange}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{colaboradores.filter(c => c.status === 'ativo').map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Descrição</Label><Input value={form.descricao} onChange={e => setForm({...form, descricao: e.target.value})} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Valor (R$)</Label><Input type="number" value={form.valor} onChange={e => setForm({...form, valor: Number(e.target.value)})} /></div>
              <div><Label>Data</Label><Input type="date" value={form.data} onChange={e => setForm({...form, data: e.target.value})} /></div>
            </div>
            <div><Label>Motivo</Label><Textarea value={form.motivo} onChange={e => setForm({...form, motivo: e.target.value})} /></div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setDialogOpen(false); setEditingId(null); }}>Cancelar</Button>
              <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending}>
                {editingId ? 'Salvar Alterações' : 'Salvar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirm Delete */}
      <Dialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir Prêmio</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Tem certeza que deseja excluir o prêmio de <strong>{confirmDelete?.colaborador_nome}</strong> — R$ {confirmDelete?.valor?.toFixed(2)}?
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setConfirmDelete(null)}>Cancelar</Button>
            <Button variant="destructive" onClick={() => deleteMutation.mutate(confirmDelete.id)} disabled={deleteMutation.isPending}>
              <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Excluir
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}