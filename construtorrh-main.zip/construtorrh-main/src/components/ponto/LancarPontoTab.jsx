import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Search, UserX, Plus, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import PontoSheet from './PontoSheet';

const MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

export default function LancarPontoTab() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [search, setSearch] = useState('');
  const [selectedColab, setSelectedColab] = useState(null);
  const [obraDialog, setObraDialog] = useState(null); // { colab, quinzena }
  const queryClient = useQueryClient();

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['colaboradores'],
    queryFn: () => base44.entities.Colaborador.list(),
  });
  const { data: funcoes = [] } = useQuery({
    queryKey: ['funcoes'],
    queryFn: () => base44.entities.Funcao.list(),
  });
  const { data: obras = [] } = useQuery({
    queryKey: ['obras'],
    queryFn: () => base44.entities.Obra.list(),
  });
  const { data: registros = [] } = useQuery({
    queryKey: ['pontos-lancamento', month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: month, ano: year }),
  });
  const { data: inativos = [] } = useQuery({
    queryKey: ['colaboradores-inativos', month, year],
    queryFn: () => base44.entities.ColaboradorInativo.filter({ mes: month, ano: year }),
  });

  const inativarMutation = useMutation({
    mutationFn: (col) => base44.entities.ColaboradorInativo.create({
      colaborador_id: col.id,
      colaborador_nome: col.nome,
      mes: month,
      ano: year,
      motivo: 'Inativado no período'
    }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['colaboradores-inativos', month, year] }),
  });

  // Helpers baseados nos registros já carregados
  const getRegsColab = (colabId, quinzena) =>
    registros.filter(r => r.colaborador_id === colabId && r.quinzena === Number(quinzena));

  const getObrasLancadas = (colabId, quinzena) => {
    const regs = getRegsColab(colabId, quinzena);
    return [...new Set(regs.map(r => r.obra_id).filter(Boolean))];
  };

  const isObraAprovada = (colabId, obraId, quinzena) => {
    const regs = registros.filter(r =>
      r.colaborador_id === colabId && r.obra_id === obraId && r.quinzena === Number(quinzena)
    );
    return regs.length > 0 && regs.every(r => r.aprovado);
  };

  const obraTemRegistro = (colabId, obraId, quinzena) =>
    registros.some(r =>
      r.colaborador_id === colabId && r.obra_id === obraId && r.quinzena === Number(quinzena)
    );

  const isQuinzenaAprovada = (colabId, quinzena) => {
    const obrasLancadas = getObrasLancadas(colabId, quinzena);
    if (obrasLancadas.length === 0) return false;
    return obrasLancadas.every(oId => isObraAprovada(colabId, oId, quinzena));
  };

  const getValorHora = (col) => {
    const funcao = funcoes.find(f => f.id === col.funcao_id);
    if (!funcao) return col.salario || 0;
    return col.tipo_contrato === 'clt'
      ? (funcao.piso_clt || col.salario || 0)
      : (funcao.piso_autonomo || col.salario || 0);
  };

  const filtered = useMemo(() => {
    const idsInativos = new Set(inativos.map(i => i.colaborador_id));
    const ativos = colaboradores.filter(c => c.status === 'ativo' && !idsInativos.has(c.id));
    if (!search.trim()) return ativos;
    const s = search.toLowerCase();
    return ativos.filter(c => c.nome?.toLowerCase().includes(s) || c.chapa?.toLowerCase().includes(s));
  }, [colaboradores, inativos, search]);

  const handleOpenSheet = (colab, quinzena, obraId) => {
    setSelectedColab({ colab, quinzena, obraId });
    setObraDialog(null);
  };

  const handleCloseSheet = () => {
    setSelectedColab(null);
    queryClient.invalidateQueries({ queryKey: ['pontos-lancamento', month, year] });
    queryClient.invalidateQueries({ queryKey: ['colaboradores-inativos', month, year] });
  };

  // Componente de badges de obras por colaborador/quinzena
  const ObrasBadges = ({ col, quinzena }) => {
    const obrasLancadas = getObrasLancadas(col.id, quinzena);
    // Sempre mostrar obra principal + obras com registro
    const todasObras = col.obra_id
      ? [col.obra_id, ...obrasLancadas.filter(id => id !== col.obra_id)]
      : obrasLancadas;

    return todasObras.map(obraId => {
      const codigo = obras.find(o => o.id === obraId)?.codigo || obraId;
      const temReg = obraTemRegistro(col.id, obraId, quinzena);
      const aprovada = isObraAprovada(col.id, obraId, quinzena);
      return (
        <span key={obraId} className="inline-flex items-center gap-0.5">
          <button
            onClick={() => handleOpenSheet(col, quinzena, obraId)}
            className="text-xs px-2 py-1 bg-primary/10 text-primary hover:bg-primary/20 rounded border border-primary/30 font-semibold transition-all"
          >
            {codigo}
          </button>
          {aprovada
            ? <CheckCircle2 className="w-3.5 h-3.5 text-green-600" title="Aprovada" />
            : temReg
              ? <Clock className="w-3.5 h-3.5 text-yellow-500" title="Lançado — aguardando aprovação" />
              : <AlertCircle className="w-3.5 h-3.5 text-red-400" title="Sem registro" />
          }
        </span>
      );
    });
  };

  const ColabRow = ({ col, quinzena }) => {
    const aprovada = isQuinzenaAprovada(col.id, quinzena);
    const valorHora = getValorHora(col);
    const temAprovado = registros.some(r => r.colaborador_id === col.id && r.aprovado);

    return (
      <div className="bg-card border rounded-xl p-4 hover:shadow-sm transition-shadow">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="w-9 h-9 bg-muted rounded-full flex items-center justify-center text-sm font-bold text-muted-foreground shrink-0">
            {col.nome?.charAt(0)?.toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="font-semibold text-sm">{col.nome}</p>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                aprovada ? 'bg-green-50 text-green-700 border-green-200' : 'bg-yellow-50 text-yellow-700 border-yellow-200'
              }`}>
                {aprovada ? 'Aprovada' : 'Pendente'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              {[col.funcao_nome, col.chapa, col.tipo_contrato === 'clt' ? 'CLT' : 'Autônomo', col.obra_nome, valorHora > 0 && `R$ ${valorHora.toFixed(2)}/h`].filter(Boolean).join(' · ')}
            </p>
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <ObrasBadges col={col} quinzena={quinzena} />
            <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => setObraDialog({ colab: col, quinzena })}>
              <Plus className="w-3 h-3" /> Obra
            </Button>
            {temAprovado ? (
              <span title="Colaborador com ponto aprovado não pode ser inativado" className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs border border-muted bg-muted text-muted-foreground cursor-not-allowed opacity-50">
                <UserX className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Inativar</span>
              </span>
            ) : (
              <button
                onClick={() => { if (window.confirm(`Deseja inativar ${col.nome} neste período?`)) inativarMutation.mutate(col); }}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 transition-all"
              >
                <UserX className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Inativar</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="mt-4 space-y-4">
      <Tabs defaultValue="q1" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="q1" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white font-semibold">
            1ª Quinzena (1–15)
          </TabsTrigger>
          <TabsTrigger value="q2" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white font-semibold">
            2ª Quinzena (16–fim)
          </TabsTrigger>
        </TabsList>

        {[1, 2].map(quinzena => (
          <TabsContent key={quinzena} value={`q${quinzena}`} className="space-y-3 mt-3">
            {/* Filtros */}
            <div className="flex gap-2 flex-wrap items-center">
              <Select value={String(month)} onValueChange={v => setMonth(Number(v))}>
                <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={String(year)} onValueChange={v => setYear(Number(v))}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent>{[2024,2025,2026,2027].map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
              </Select>
              <div className="relative flex-1 min-w-[180px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>

            {/* Lista */}
            <div className="space-y-2">
              {filtered.length === 0 && (
                <div className="text-center py-10 text-muted-foreground text-sm">Nenhum colaborador ativo encontrado.</div>
              )}
              {filtered.map(col => <ColabRow key={col.id} col={col} quinzena={quinzena} />)}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Sheet de lançamento */}
      {selectedColab && (
        <PontoSheet
          colaborador={selectedColab.colab}
          funcoes={funcoes}
          defaultQuinzena={selectedColab.quinzena}
          defaultMonth={month}
          defaultYear={year}
          defaultObraId={selectedColab.obraId}
          onClose={handleCloseSheet}
          onApprove={handleCloseSheet}
        />
      )}

      {/* Dialog: selecionar obra */}
      <Dialog open={!!obraDialog} onOpenChange={() => setObraDialog(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Selecionar Obra</DialogTitle>
            <DialogDescription>Escolha uma obra para {obraDialog?.colab?.nome}</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {obras.filter(o => o.status === 'em_andamento' || !o.status).map(obra => {
              const jaLancada = obraDialog
                ? obraTemRegistro(obraDialog.colab.id, obra.id, obraDialog.quinzena)
                : false;
              const isPrincipal = obra.id === obraDialog?.colab?.obra_id;
              return (
                <button
                  key={obra.id}
                  onClick={() => handleOpenSheet(obraDialog.colab, obraDialog.quinzena, obra.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg border transition-all flex items-center justify-between ${
                    jaLancada ? 'bg-green-50 border-green-200 hover:bg-green-100' : 'bg-card border-border hover:bg-accent'
                  }`}
                >
                  <span className="font-medium text-sm">
                    {obra.codigo || obra.nome}
                    {isPrincipal && <span className="ml-2 text-xs text-muted-foreground">(principal)</span>}
                  </span>
                  {jaLancada ? (
                    <span className="flex items-center gap-1 text-xs text-green-700 font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Lançado — editar
                    </span>
                  ) : (
                    <span className="text-xs text-muted-foreground">Novo lançamento</span>
                  )}
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}