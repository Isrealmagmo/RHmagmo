import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { X, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PontoSheetObra from './PontoSheetObra';

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const DAYS = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];

function getDaysInMonth(month, year) {
  const days = [];
  const count = new Date(year, month, 0).getDate();
  for (let d = 1; d <= count; d++) {
    const date = new Date(year, month - 1, d);
    const dow = date.getDay();
    days.push({ day: d, dayOfWeek: dow, dayName: DAYS[dow], isDom: dow === 0, isSab: dow === 6, date: date.toISOString().split('T')[0] });
  }
  return days;
}

export default function PontoSheet({ colaborador, funcoes = [], defaultQuinzena = 1, defaultMonth, defaultYear, defaultObraId, onClose, onApprove }) {
  const now = new Date();
  const [month] = useState(defaultMonth || now.getMonth() + 1);
  const [year] = useState(defaultYear || now.getFullYear());
  const [quinzena] = useState(defaultQuinzena);
  const obraId = defaultObraId || colaborador.obra_id;

  const { data: obras = [] } = useQuery({ queryKey: ['obras'], queryFn: () => base44.entities.Obra.list() });
  const { data: playbook = [] } = useQuery({ queryKey: ['playbook'], queryFn: () => base44.entities.PlaybookServico.list() });

  const funcao = funcoes.find(f => f.id === colaborador.funcao_id);
  const valorHoraAtual = colaborador.tipo_contrato === 'clt'
    ? (funcao?.piso_clt || colaborador.salario || 0)
    : (funcao?.piso_autonomo || colaborador.salario || 0);
  const isClt = colaborador.tipo_contrato === 'clt';

  const allDays = useMemo(() => getDaysInMonth(month, year), [month, year]);
  const days = useMemo(() => quinzena === 1 ? allDays.filter(d => d.day <= 15) : allDays.filter(d => d.day >= 16), [allDays, quinzena]);
  const obra = obras.find(o => o.id === obraId);

  return (
    <div className="fixed inset-0 bg-background z-50 overflow-auto">
      <div className="p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="font-bold text-lg">{colaborador.nome}</span>
            {colaborador.chapa && <span className="text-xs bg-muted px-2 py-1 rounded">{colaborador.chapa}</span>}
            <span className="text-xs text-muted-foreground">{colaborador.funcao_nome}</span>
            <span className="text-xs font-medium px-2 py-0.5 rounded border">{isClt ? 'CLT' : 'Autônomo'}</span>
            <span className="text-xs text-muted-foreground font-medium">R$ {valorHoraAtual?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0,00'}/h</span>
            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded font-medium">
              {MONTHS[month - 1]} {year} — {quinzena === 1 ? '1ª Quinzena (1–15)' : `2ª Quinzena (16–${allDays.length})`}
            </span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
        </div>

        {obraId ? (
          <div>
            <div className="flex items-center gap-2 mb-4 border-b pb-2">
              <span className="text-xs font-mono bg-primary/10 text-primary px-3 py-1.5 rounded-lg border border-primary/30 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                {obra ? `${obra.nome} (${obra.codigo})` : obraId}
              </span>
            </div>
            <PontoSheetObra
              colaborador={colaborador}
              funcoes={funcoes}
              obras={obras}
              playbook={playbook}
              obraId={obraId}
              quinzena={quinzena}
              month={month}
              year={year}
              days={days}
              onApprove={onApprove}
            />
          </div>
        ) : (
          <div className="text-center py-10 text-muted-foreground">
            <p>Nenhuma obra atribuída a este colaborador.</p>
          </div>
        )}
      </div>
    </div>
  );
}