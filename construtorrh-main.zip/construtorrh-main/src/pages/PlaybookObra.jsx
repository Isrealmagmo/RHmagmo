import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, BookOpen, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import jsPDF from 'jspdf';
import 'jspdf/dist/jspdf.umd.min.js';

const UNIDADES = ['m²', 'm', 'm³', 'un', 'kg', 'pç', 'vb', 'hr', 'sc', 'l'];

const emptyForm = { obra_id: '', obra_nome: '', nome: '', unidade: 'm²', valor_unitario: '', descricao: '', ativo: true };

export default function PlaybookObra() {
  const [selectedObraId, setSelectedObraId] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const queryClient = useQueryClient();

  const { data: obras = [] } = useQuery({ queryKey: ['obras'], queryFn: () => base44.entities.Obra.list() });
  const { data: servicos = [] } = useQuery({ queryKey: ['playbook'], queryFn: () => base44.entities.PlaybookServico.list() });

  const servicosDaObra = useMemo(() => {
    if (!selectedObraId) return [];
    return servicos.filter(s => s.obra_id === selectedObraId).sort((a, b) => a.nome.localeCompare(b.nome));
  }, [servicos, selectedObraId]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (editingItem) {
        return base44.entities.PlaybookServico.update(editingItem.id, data);
      }
      return base44.entities.PlaybookServico.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['playbook'] });
      setDialogOpen(false);
      setEditingItem(null);
      setForm(emptyForm);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PlaybookServico.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['playbook'] }),
  });

  const openNew = () => {
    const obra = obras.find(o => o.id === selectedObraId);
    setEditingItem(null);
    setForm({ ...emptyForm, obra_id: selectedObraId, obra_nome: obra?.nome || '' });
    setDialogOpen(true);
  };

  const openEdit = (item) => {
    setEditingItem(item);
    setForm({ ...item });
    setDialogOpen(true);
  };

  const handleSave = () => {
    const obra = obras.find(o => o.id === form.obra_id);
    saveMutation.mutate({ ...form, obra_nome: obra?.nome || form.obra_nome, valor_unitario: Number(form.valor_unitario) });
  };

  const gerarPDF = () => {
    const obra = obras.find(o => o.id === selectedObraId);
    if (!obra || servicosDaObra.length === 0) return;

    const doc = new jsPDF();
    const margin = 15;
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    let yPos = margin;

    // Cabeçalho
    doc.setFontSize(18);
    doc.text('PLAYBOOK DE SERVIÇOS', margin, yPos);
    yPos += 8;

    doc.setFontSize(11);
    doc.setTextColor(80, 80, 80);
    doc.text(`Obra: ${obra.nome}`, margin, yPos);
    yPos += 6;
    doc.text(`Código: ${obra.codigo || '—'}`, margin, yPos);
    yPos += 6;
    doc.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, margin, yPos);
    yPos += 12;

    // Tabela
    doc.setFontSize(10);
    const colWidths = [60, 50, 25, 30];
    const headers = ['Serviço', 'Descrição', 'Un.', 'Valor Unit.'];
    const data = servicosDaObra.map(s => [
      s.nome,
      s.descricao || '—',
      s.unidade,
      `R$ ${Number(s.valor_unitario || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
    ]);

    // Desenha cabeçalho da tabela
    doc.setFillColor(30, 30, 30);
    doc.setTextColor(255, 255, 255);
    doc.setFont(undefined, 'bold');
    let xPos = margin;
    headers.forEach((h, i) => {
      doc.text(h, xPos, yPos, { maxWidth: colWidths[i] - 2, align: i === 3 ? 'right' : 'left' });
      xPos += colWidths[i];
    });
    yPos += 8;

    // Desenha linhas
    doc.setTextColor(0, 0, 0);
    doc.setFont(undefined, 'normal');
    data.forEach((row, idx) => {
      if (yPos > pageHeight - 20) {
        doc.addPage();
        yPos = margin;
      }
      const rowHeight = 8;
      const bgColor = idx % 2 === 0 ? [245, 245, 245] : [255, 255, 255];
      doc.setFillColor(...bgColor);
      doc.rect(margin, yPos - 2, pageWidth - 2 * margin, rowHeight, 'F');
      
      xPos = margin;
      row.forEach((cell, i) => {
        doc.text(cell, xPos + 1, yPos + 3, { maxWidth: colWidths[i] - 2, align: i === 3 ? 'right' : 'left' });
        xPos += colWidths[i];
      });
      yPos += rowHeight;
    });

    // Rodapé
    yPos += 10;
    doc.setFontSize(9);
    doc.setTextColor(120, 120, 120);
    doc.text(`Total de Serviços: ${servicosDaObra.length}`, margin, yPos);
    doc.text(`Gerado em: ${new Date().toLocaleString('pt-BR')}`, pageWidth - margin - 50, yPos);

    doc.save(`playbook-${obra.nome.replace(/\s+/g, '-')}.pdf`);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader title="Playbook de Serviços" subtitle="Tabela de serviços e valores por obra" icon={BookOpen}>
        <div className="flex gap-2">
          <Button onClick={gerarPDF} disabled={!selectedObraId || servicosDaObra.length === 0} variant="outline" className="gap-2">
            <FileText className="w-4 h-4" /> Gerar PDF
          </Button>
          <Button onClick={openNew} disabled={!selectedObraId} className="gap-2">
            <Plus className="w-4 h-4" /> Novo Serviço
          </Button>
        </div>
      </PageHeader>

      {/* Seletor de Obra */}
      <div className="mb-6">
        <label className="text-sm font-medium text-muted-foreground mb-1.5 block">Selecione a Obra</label>
        <Select value={selectedObraId} onValueChange={setSelectedObraId}>
          <SelectTrigger className="w-full max-w-md">
            <SelectValue placeholder="Escolha uma obra para ver / editar o playbook..." />
          </SelectTrigger>
          <SelectContent>
            {obras.map(o => <SelectItem key={o.id} value={o.id}>{o.nome}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {!selectedObraId ? (
        <div className="text-center py-16 text-muted-foreground">
          <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p>Selecione uma obra acima para visualizar seu playbook de serviços.</p>
        </div>
      ) : servicosDaObra.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground border-2 border-dashed rounded-xl">
          <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="font-medium">Nenhum serviço cadastrado ainda.</p>
          <p className="text-sm mt-1">Clique em "Novo Serviço" para começar.</p>
        </div>
      ) : (
        <div className="border rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-sidebar text-sidebar-foreground">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Serviço</th>
                <th className="px-4 py-3 text-left font-medium">Descrição</th>
                <th className="px-4 py-3 text-center font-medium">Unidade</th>
                <th className="px-4 py-3 text-right font-medium">Valor Unit.</th>
                <th className="px-4 py-3 text-center font-medium">Status</th>
                <th className="px-4 py-3 text-center font-medium w-20">Ações</th>
              </tr>
            </thead>
            <tbody>
              {servicosDaObra.map((s, i) => (
                <tr key={s.id} className={i % 2 === 0 ? 'bg-card' : 'bg-muted/30'}>
                  <td className="px-4 py-3 font-medium">{s.nome}</td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">{s.descricao || '—'}</td>
                  <td className="px-4 py-3 text-center">
                    <span className="bg-primary/10 text-primary px-2 py-0.5 rounded text-xs font-medium">{s.unidade}</span>
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-green-700">
                    R$ {Number(s.valor_unitario || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.ativo !== false ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
                      {s.ativo !== false ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(s)}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => deleteMutation.mutate(s.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingItem ? 'Editar Serviço' : 'Novo Serviço'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-sm font-medium">Nome do Serviço *</label>
              <Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))} placeholder="Ex: Reboco, Azulejo, Piso..." />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium">Unidade *</label>
                <Select value={form.unidade} onValueChange={v => setForm(f => ({ ...f, unidade: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{UNIDADES.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Valor Unitário (R$) *</label>
                <Input type="number" step="0.01" value={form.valor_unitario} onChange={e => setForm(f => ({ ...f, valor_unitario: e.target.value }))} placeholder="0,00" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">Descrição / Observações</label>
              <Input value={form.descricao} onChange={e => setForm(f => ({ ...f, descricao: e.target.value }))} placeholder="Opcional..." />
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="ativo" checked={form.ativo !== false} onChange={e => setForm(f => ({ ...f, ativo: e.target.checked }))} className="w-4 h-4" />
              <label htmlFor="ativo" className="text-sm">Serviço ativo</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={!form.nome || !form.unidade || saveMutation.isPending}>
              {saveMutation.isPending ? 'Salvando...' : 'Salvar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}