import React, { useState } from 'react';
import { Clock, AlertTriangle, FileHeart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import PageHeader from '@/components/ui/PageHeader';
import LancarPontoTab from '@/components/ponto/LancarPontoTab';
import ResumoTab from '@/components/ponto/ResumoTab';

export default function ControlePonto() {
  return (
    <div>
      <PageHeader title="Controle de Ponto" subtitle="Espelho de Ponto — Lançamento por quinzena" icon={Clock}>
        <div className="flex gap-2">
          <Link to="/atestados">
            <Button variant="outline" size="sm" className="gap-2">
              <FileHeart className="w-4 h-4" />
              Atestados
            </Button>
          </Link>
          <Link to="/acidentes">
            <Button variant="outline" size="sm" className="gap-2">
              <AlertTriangle className="w-4 h-4" />
              Acidentes
            </Button>
          </Link>
        </div>
      </PageHeader>
      <Tabs defaultValue="lancar">
        <TabsList>
          <TabsTrigger value="lancar">📋 Lançar Ponto</TabsTrigger>
          <TabsTrigger value="resumo">📊 Resumo</TabsTrigger>
        </TabsList>
        <TabsContent value="lancar"><LancarPontoTab /></TabsContent>
        <TabsContent value="resumo"><ResumoTab /></TabsContent>
      </Tabs>
    </div>
  );
}