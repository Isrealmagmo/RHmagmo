import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, Edit2 } from 'lucide-react';
import { toast } from 'sonner';

export default function HistoricoChapasTab({ colaboradorId }) {
  const queryClient = useQueryClient();
  const [editingId, setEditingId] = useState(null);
  const [editObs, setEditObs] = useState('');
  const [editDataSaida, setEditDataSaida] = useState('');

  const { data: historico = [] } = useQuery({
    queryKey: ['historicoChapas', colaboradorId],
    queryFn: () => base44.entities.HistoricoChapa.filter({ colaborador_id: colaboradorId }),
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.HistoricoChapa.update(editingId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['historicoChapas', colaboradorId] });
      setEditingId(null);
      toast.success('Histórico atualizado');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.HistoricoChapa.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['historicoChapas', colaboradorId] });
      toast.success('Registro removido');
    },
  });

  const handleSaveEdit = () => {
    updateMutation.mutate({
      data_saida: editDataSaida,
      ativa: !editDataSaida,
      observacoes: editObs,
    });
  };

  const handleEditClick = (item) => {
    setEditingId(item.id);
    setEditObs(item.observacoes || '');
    setEditDataSaida(item.data_saida || '');
  };

  return (
    <div className="space-y-4">
      {historico.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">Nenhum histórico de chapas registrado.</p>
      ) : (
        <div className="space-y-2">
          {historico.map((item) => (
            <div
              key={item.id}
              className={`border rounded-lg p-4 ${item.ativa ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-mono font-bold text-primary">{item.chapa}</span>
                    <span className="text-xs bg-muted px-2 py-0.5 rounded">{item.funcao_nome}</span>
                    {item.ativa ? (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded">Ativa</span>
                    ) : (
                      <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded">Inativa</span>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-2">
                    <div>Início: {new Date(item.data_inicio).toLocaleDateString('pt-BR')}</div>
                    {item.data_saida && <div>Saída: {new Date(item.data_saida).toLocaleDateString('pt-BR')}</div>}
                  </div>
                  {item.observacoes && <p className="text-xs text-muted-foreground italic">{item.observacoes}</p>}
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleEditClick(item)}
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive"
                    onClick={() => deleteMutation.mutate(item.id)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!editingId} onOpenChange={() => setEditingId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Registro de Chapa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Data de Saída</Label>
              <Input
                type="date"
                value={editDataSaida}
                onChange={(e) => setEditDataSaida(e.target.value)}
              />
            </div>
            <div>
              <Label>Observações</Label>
              <Input
                value={editObs}
                onChange={(e) => setEditObs(e.target.value)}
                placeholder="Motivo da mudança, etc."
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setEditingId(null)}>Cancelar</Button>
              <Button onClick={handleSaveEdit}>Salvar</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}