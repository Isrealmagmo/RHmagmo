import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { FolderOpen, Plus, Search, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import { toast } from 'sonner';

export default function Documentos() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ colaborador_id: '', tipo: 'documento_pessoal', nome: '', data: '', validade: '', arquivo_url: '', observacoes: '' });
  const [isUploading, setIsUploading] = useState(false);
  const queryClient = useQueryClient();

  const { data: documentos = [] } = useQuery({ queryKey: ['documentos'], queryFn: () => base44.entities.Documento.list() });
  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });
  const { data: configs = [] } = useQuery({ queryKey: ['configs'], queryFn: () => base44.entities.ConfiguracaoSistema.list() });

  const tiposDocumento = configs.find(c => c.chave === 'tipos_documentos')?.valor?.tipos || ['documento_pessoal', 'contrato', 'certificado', 'comprovante', 'outros'];

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      toast.error('Arquivo muito grande. Máximo 10MB.');
      return;
    }

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      toast.error('Apenas imagens (JPG, PNG, WebP) e PDF são permitidos.');
      return;
    }

    setIsUploading(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setForm(prev => ({ ...prev, arquivo_url: result.file_url }));
      toast.success('Arquivo enviado com sucesso!');
    } catch (error) {
      toast.error('Erro ao enviar arquivo');
    } finally {
      setIsUploading(false);
    }
  };

  const saveMutation = useMutation({
    mutationFn: (data) => {
      const col = colaboradores.find(c => c.id === data.colaborador_id);
      return base44.entities.Documento.create({ ...data, colaborador_nome: col?.nome || '' });
    },
    onSuccess: () => { 
      queryClient.invalidateQueries({ queryKey: ['documentos'] }); 
      setDialogOpen(false);
      setForm({ colaborador_id: '', tipo: 'documento_pessoal', nome: '', data: '', validade: '', arquivo_url: '', observacoes: '' });
      toast.success('Documento salvo com sucesso!');
    },
  });

  const filtered = documentos.filter(d => !search || d.colaborador_nome?.toLowerCase().includes(search.toLowerCase()) || d.nome?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <PageHeader title="Documentos" subtitle={`${documentos.length} documento(s)`} icon={FolderOpen}>
        <Button onClick={() => setDialogOpen(true)} className="gap-1.5"><Plus className="w-4 h-4" /> Novo Documento</Button>
      </PageHeader>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input className="pl-9" placeholder="Buscar..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="bg-muted">
            <th className="text-left px-4 py-3 font-medium">Colaborador</th>
            <th className="text-left px-4 py-3 font-medium">Documento</th>
            <th className="text-left px-4 py-3 font-medium">Tipo</th>
            <th className="text-left px-4 py-3 font-medium">Data</th>
            <th className="text-left px-4 py-3 font-medium">Validade</th>
          </tr></thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={5} className="text-center py-8 text-muted-foreground">Nenhum documento encontrado</td></tr>
            ) : (
              filtered.map(d => (
                <tr key={d.id} className="border-t hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{d.colaborador_nome}</td>
                  <td className="px-4 py-3">{d.nome}</td>
                  <td className="px-4 py-3 capitalize">{d.tipo?.replace(/_/g, ' ')}</td>
                  <td className="px-4 py-3">{d.data || '-'}</td>
                  <td className="px-4 py-3">{d.validade || '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Novo Documento</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={form.colaborador_id} onValueChange={v => setForm({...form, colaborador_id: v})}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{colaboradores.map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Tipo de Documento</Label>
              <Select value={form.tipo} onValueChange={v => setForm({...form, tipo: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {tiposDocumento.map(tipo => (
                    <SelectItem key={tipo} value={tipo}>
                      {tipo.charAt(0).toUpperCase() + tipo.slice(1).replace(/_/g, ' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div><Label>Nome do documento *</Label><Input value={form.nome} onChange={e => setForm({...form, nome: e.target.value})} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Data</Label><Input type="date" value={form.data} onChange={e => setForm({...form, data: e.target.value})} /></div>
              <div><Label>Validade</Label><Input type="date" value={form.validade} onChange={e => setForm({...form, validade: e.target.value})} /></div>
            </div>
            <div className="space-y-2">
              <Label>Arquivo (Imagem ou PDF)</Label>
              <div className="flex gap-2">
                <label className="flex-1 relative">
                  <div className={`border-2 border-dashed rounded-lg p-3 text-center cursor-pointer hover:bg-muted transition ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}>
                    <Upload className="w-4 h-4 mx-auto mb-1" />
                    <p className="text-xs text-muted-foreground">{isUploading ? 'Enviando...' : 'Clique para upload'}</p>
                  </div>
                  <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={handleFileUpload} disabled={isUploading} className="hidden" />
                </label>
              </div>
              {form.arquivo_url && (
                <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded p-2">
                  <span className="text-xs text-green-700">✓ Arquivo enviado</span>
                  <button onClick={() => setForm(prev => ({...prev, arquivo_url: ''}))} className="text-xs text-destructive hover:text-destructive/80">
                    Remover
                  </button>
                </div>
              )}
            </div>
            <div><Label>Observações</Label><Textarea value={form.observacoes} onChange={e => setForm({...form, observacoes: e.target.value})} /></div>
            <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button><Button onClick={() => saveMutation.mutate(form)}>Salvar</Button></div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}