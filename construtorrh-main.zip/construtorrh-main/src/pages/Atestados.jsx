import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { FileHeart, Plus, Search, Pencil, Trash2, CheckCircle2, Link } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/ui/PageHeader';
import StatusBadge from '@/components/ui/StatusBadge';

const emptyForm = {
  colaborador_id: '', tipo: 'atestado_medico', data_inicio: '', data_fim: '',
  dias: 0, cid: '', medico: '', observacoes: '', status: 'ativo', acidente_id: ''
};

function calcDias(inicio, fim) {
  if (!inicio || !fim) return 0;
  return Math.ceil((new Date(fim) - new Date(inicio)) / (1000 * 60 * 60 * 24)) + 1;
}

// Gera todas as datas entre início e fim (inclusive)
function getDatesInRange(inicio, fim) {
  const dates = [];
  const cur = new Date(inicio);
  const end = new Date(fim);
  while (cur <= end) {
    dates.push(cur.toISOString().split('T')[0]);
    cur.setDate(cur.getDate() + 1);
  }
  return dates;
}

export default function Atestados() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(emptyForm);
  const queryClient = useQueryClient();

  const { data: atestados = [] } = useQuery({ queryKey: ['atestados'], queryFn: () => base44.entities.Atestado.list() });
  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });
  const { data: acidentes = [] } = useQuery({ queryKey: ['acidentes'], queryFn: () => base44.entities.Acidente.list() });

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const col = colaboradores.find(c => c.id === data.colaborador_id);
      const payload = { ...data, colaborador_nome: col?.nome || '' };

      let atestado;
      if (editing) {
        atestado = await base44.entities.Atestado.update(editing.id, payload);
      } else {
        atestado = await base44.entities.Atestado.create(payload);
      }

      // Lançar dias no ponto somente se ainda não foram lançados (novo atestado ou datas mudaram)
      const isNovo = !editing;
      const datasChanged = editing && (editing.data_inicio !== data.data_inicio || editing.data_fim !== data.data_fim);

      if ((isNovo || datasChanged) && data.data_inicio && col) {
        const dates = getDatesInRange(data.data_inicio, data.data_fim || data.data_inicio);

        // Se datas mudaram, remover registros antigos desse atestado
        if (datasChanged && editing?.ponto_lancado) {
          const oldDates = getDatesInRange(editing.data_inicio, editing.data_fim || editing.data_inicio);
          const pontosExistentes = await base44.entities.RegistroPonto.filter({
            colaborador_id: col.id,
            tipo: 'atestado'
          });
          for (const oldDate of oldDates) {
            const reg = pontosExistentes.find(r => r.data === oldDate);
            if (reg) await base44.entities.RegistroPonto.delete(reg.id);
          }
        }

        // Criar registros no ponto para cada dia do atestado
        for (const dateStr of dates) {
          const d = new Date(dateStr);
          const mes = d.getMonth() + 1;
          const ano = d.getFullYear();
          const quinzena = d.getDate() <= 15 ? 1 : 2;

          // Verificar se já existe registro para esse dia
          const existe = await base44.entities.RegistroPonto.filter({
            colaborador_id: col.id,
            data: dateStr
          });

          const pontoPayload = {
            colaborador_id: col.id,
            colaborador_nome: col.nome,
            obra_id: col.obra_id || '',
            obra_nome: col.obra_nome || '',
            data: dateStr,
            mes,
            ano,
            quinzena,
            tipo: 'atestado',
            presente: false,
            aprovado: false,
            atestado_id: atestado.id || editing?.id,
          };

          if (existe.length > 0) {
            await base44.entities.RegistroPonto.update(existe[0].id, pontoPayload);
          } else {
            await base44.entities.RegistroPonto.create(pontoPayload);
          }
        }

        // Marcar que o ponto foi lançado
        await base44.entities.Atestado.update(atestado.id || editing?.id, { ponto_lancado: true });
      }

      // Vincular ao acidente se selecionado
      if (data.acidente_id) {
        await base44.entities.Acidente.update(data.acidente_id, { atestado_id: atestado.id || editing?.id });
      }

      return atestado;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['atestados'] });
      queryClient.invalidateQueries({ queryKey: ['pontos'] });
      queryClient.invalidateQueries({ queryKey: ['pontos-aprovacao'] });
      queryClient.invalidateQueries({ queryKey: ['acidentes'] });
      setDialogOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (atestado) => {
      // Remover registros de ponto vinculados ao atestado
      if (atestado.ponto_lancado && atestado.data_inicio) {
        const dates = getDatesInRange(atestado.data_inicio, atestado.data_fim || atestado.data_inicio);
        const pontosExistentes = await base44.entities.RegistroPonto.filter({
          colaborador_id: atestado.colaborador_id,
          tipo: 'atestado'
        });
        for (const dateStr of dates) {
          const reg = pontosExistentes.find(r => r.data === dateStr);
          if (reg) await base44.entities.RegistroPonto.delete(reg.id);
        }
      }
      return base44.entities.Atestado.delete(atestado.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['atestados'] });
      queryClient.invalidateQueries({ queryKey: ['pontos'] });
      queryClient.invalidateQueries({ queryKey: ['pontos-aprovacao'] });
    },
  });

  const openNew = () => { setEditing(null); setForm(emptyForm); setDialogOpen(true); };

  const openEdit = (a) => {
    setEditing(a);
    setForm({ ...a, acidente_id: a.acidente_id || '' });
    setDialogOpen(true);
  };

  // Filtrar acidentes do colaborador selecionado para vincular
  const acidentsDoColab = acidentes.filter(ac => ac.colaborador_id === form.colaborador_id);

  const ativos = atestados.filter(a => a.status === 'ativo').length;
  const filtered = atestados.filter(a => !search || a.colaborador_nome?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <PageHeader title="Atestados" subtitle={`${ativos} ativo(s) · ${atestados.length} total`} icon={FileHeart}>
        <Button onClick={openNew} className="gap-1.5"><Plus className="w-4 h-4" /> Novo Atestado</Button>
      </PageHeader>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input className="pl-9" placeholder="Buscar colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">Nenhum atestado registrado</div>
        ) : (
          filtered.map(a => {
            const acidenteVinculado = acidentes.find(ac => ac.id === a.acidente_id);
            return (
              <div key={a.id} className="bg-card border rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-muted rounded-full flex items-center justify-center text-sm font-bold text-muted-foreground">
                    {a.colaborador_nome?.charAt(0)?.toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-sm">{a.colaborador_nome}</p>
                      {a.ponto_lancado && (
                        <span className="flex items-center gap-1 text-xs text-green-600 font-medium">
                          <CheckCircle2 className="w-3 h-3" /> Ponto lançado
                        </span>
                      )}
                      {acidenteVinculado && (
                        <span className="flex items-center gap-1 text-xs text-orange-600 font-medium">
                          <Link className="w-3 h-3" /> Acidente vinculado
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {a.tipo?.replace(/_/g, ' ')} · {a.data_inicio}{a.data_fim && ` até ${a.data_fim}`} · {a.dias || calcDias(a.data_inicio, a.data_fim)} dia(s)
                      {a.cid && ` · CID: ${a.cid}`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={a.status} />
                  <Button variant="ghost" size="icon" onClick={() => openEdit(a)}><Pencil className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteMutation.mutate(a)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            );
          })
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Editar Atestado' : 'Novo Atestado'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={form.colaborador_id} onValueChange={v => setForm({...form, colaborador_id: v, acidente_id: ''})}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{colaboradores.map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div>
              <Label>Tipo</Label>
              <Select value={form.tipo} onValueChange={v => setForm({...form, tipo: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="atestado_medico">Atestado Médico</SelectItem>
                  <SelectItem value="atestado_comparecimento">Atestado de Comparecimento</SelectItem>
                  <SelectItem value="declaracao">Declaração</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Data Início *</Label>
                <Input type="date" value={form.data_inicio} onChange={e => { const d = e.target.value; setForm(prev => ({...prev, data_inicio: d, dias: calcDias(d, prev.data_fim)})); }} />
              </div>
              <div>
                <Label>Data Fim</Label>
                <Input type="date" value={form.data_fim} onChange={e => { const d = e.target.value; setForm(prev => ({...prev, data_fim: d, dias: calcDias(prev.data_inicio, d)})); }} />
              </div>
            </div>

            {form.dias > 0 && (
              <div className="bg-blue-50 text-blue-700 text-xs px-3 py-2 rounded-lg">
                📋 {form.dias} dia(s) serão lançados automaticamente no ponto como <strong>atestado</strong> e não poderão ser alterados.
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div><Label>CID</Label><Input value={form.cid} onChange={e => setForm({...form, cid: e.target.value})} /></div>
              <div><Label>Médico responsável</Label><Input value={form.medico} onChange={e => setForm({...form, medico: e.target.value})} /></div>
            </div>

            <div><Label>Observações</Label><Textarea value={form.observacoes} onChange={e => setForm({...form, observacoes: e.target.value})} /></div>

            {/* Vincular ao acidente */}
            {form.colaborador_id && acidentsDoColab.length > 0 && (
              <div>
                <Label>Vincular a acidente de trabalho</Label>
                <Select value={form.acidente_id || 'none'} onValueChange={v => setForm({...form, acidente_id: v === 'none' ? '' : v})}>
                  <SelectTrigger><SelectValue placeholder="Nenhum" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum</SelectItem>
                    {acidentsDoColab.map(ac => (
                      <SelectItem key={ac.id} value={ac.id}>
                        {ac.data} — {ac.tipo_acidente?.replace(/_/g, ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm({...form, status: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="encerrado">Encerrado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending}>
                {saveMutation.isPending ? 'Salvando...' : 'Salvar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}