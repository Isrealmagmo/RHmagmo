import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import PontoRow from './PontoRow';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Save, Check, Lock, Award, Trash2, Edit, Factory, Plus, Minus, FileBarChart2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

function toMin(t) {
  if (!t) return 0;
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}
function calcHorasNormais(entrada, saida, saida_almoco, retorno_almoco) {
  if (!entrada || !saida) return 0;
  let total = toMin(saida) - toMin(entrada);
  if (saida_almoco && retorno_almoco) total -= (toMin(retorno_almoco) - toMin(saida_almoco));
  return Math.max(0, total / 60);
}
function calcHorasExtra(entrada_extra, saida_extra) {
  if (!entrada_extra || !saida_extra) return 0;
  return Math.max(0, (toMin(saida_extra) - toMin(entrada_extra)) / 60);
}
function getAdicionalFator(adicional) {
  if (adicional === '50_sab') return 1.5;
  if (adicional === '100_dom' || adicional === '100_fer') return 2.0;
  return 1.0;
}
function formatHoras(h) {
  if (h <= 0) return '--';
  const totalMin = Math.round(h * 60);
  const hh = Math.floor(totalMin / 60);
  const mm = totalMin % 60;
  return mm === 0 ? `${hh}h` : `${hh}h${String(mm).padStart(2, '0')}`;
}

function getHorariosObra(obra) {
  if (!obra) return {
    seg_qui: { entrada: '07:00', saida_almoco: '12:00', retorno_almoco: '13:00', saida: '17:00' },
    sex:     { entrada: '07:00', saida_almoco: '12:00', retorno_almoco: '13:00', saida: '16:00' },
    sab:     { entrada: '07:00', saida_almoco: null, retorno_almoco: null, saida: '14:00' },
  };
  return {
    seg_qui: { entrada: obra.horario_seg_qui_entrada || '07:00', saida_almoco: obra.horario_seg_qui_saida_almoco || '12:00', retorno_almoco: obra.horario_seg_qui_retorno_almoco || '13:00', saida: obra.horario_seg_qui_saida || '17:00' },
    sex:     { entrada: obra.horario_sex_entrada || '07:00', saida_almoco: obra.horario_sex_saida_almoco || '12:00', retorno_almoco: obra.horario_sex_retorno_almoco || '13:00', saida: obra.horario_sex_saida || '16:00' },
    sab:     { entrada: obra.horario_sab_entrada || '07:00', saida_almoco: null, retorno_almoco: null, saida: obra.horario_sab_saida || '14:00' },
  };
}

function getDefaultHorario(dayOfWeek, horarios) {
  if (dayOfWeek >= 1 && dayOfWeek <= 4) return horarios.seg_qui;
  if (dayOfWeek === 5) return horarios.sex;
  if (dayOfWeek === 6) return horarios.sab;
  return null;
}

export default function PontoSheetObra({
  colaborador, funcoes = [], obras = [], playbook = [],
  obraId, quinzena, month, year, days, onApprove,
}) {
  const queryClient = useQueryClient();

  const funcao = funcoes.find(f => f.id === colaborador.funcao_id);
  const valorHoraAtual = colaborador.tipo_contrato === 'clt'
    ? (funcao?.piso_clt || colaborador.salario || 0)
    : (funcao?.piso_autonomo || colaborador.salario || 0);
  const isClt = colaborador.tipo_contrato === 'clt';

  const obra = useMemo(() => obras.find(o => o.id === obraId), [obras, obraId]);
  const horarios = useMemo(() => getHorariosObra(obra), [obra]);
  const horariosRef = useRef(horarios);
  horariosRef.current = horarios;

  // Pagamento pago = trava total
  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-ponto', colaborador.id, month, year, quinzena],
    queryFn: () => base44.entities.Pagamento.filter({ colaborador_id: colaborador.id, mes: month, ano: year, quinzena }),
  });
  const pagamentoPago = pagamentos.some(p => p.quinzena === quinzena && p.status === 'pago');

  // Registros de TODOS os meses/obras do colaborador (para conflito entre obras)
  const { data: allRegistros = [], refetch: refetchAll } = useQuery({
    queryKey: ['pontos-all', colaborador.id, month, year],
    queryFn: () => base44.entities.RegistroPonto.filter({ colaborador_id: colaborador.id, mes: month, ano: year }),
  });

  // Registros apenas desta obra
  const registros = useMemo(() => allRegistros.filter(r => r.obra_id === obraId), [allRegistros, obraId]);

  // Aprovação: todos os registros desta obra+quinzena estão aprovados?
  const isObraAprovada = useMemo(() => {
    const regs = registros.filter(r => r.quinzena === quinzena);
    return regs.length > 0 && regs.every(r => r.aprovado);
  }, [registros, quinzena]);

  const locked = isObraAprovada || pagamentoPago;

  // Estado local dos pontos
  const [pontoData, setPontoData] = useState({});
  const [producaoOpen, setProducaoOpen] = useState(false);
  const [producaoDiasSelecionados, setProducaoDiasSelecionados] = useState({});
  const [itensProducao, setItensProducao] = useState([{ servicoId: '', metragem: '', valorUnitarioManual: '' }]);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [relatorioOpen, setRelatorioOpen] = useState(false);

  // Sincronizar estado local com registros do banco
  useEffect(() => {
    const map = {};
    registros.forEach(r => { map[r.data] = { ...r }; });
    setPontoData(map);
  }, [registros]);

  const handlePresenca = useCallback((date, dayOfWeek, checked) => {
    // Impede marcar presença em dia já lançado em outra obra
    if (checked) {
      const conflito = allRegistros.some(r => r.data === date && r.colaborador_id === colaborador.id && r.obra_id !== obraId && r.presente);
      if (conflito) return;
    }
    setPontoData(prev => {
      const existing = prev[date] || { data: date };
      if (!checked) {
        return { ...prev, [date]: { ...existing, presente: false, entrada: '', saida_almoco: '', retorno_almoco: '', saida: '', adicional: 'normal' } };
      }
      const h = getDefaultHorario(dayOfWeek, horariosRef.current);
      const adicional = dayOfWeek === 0 ? '100_dom' : dayOfWeek === 6 ? '50_sab' : 'normal';
      return { ...prev, [date]: { ...existing, presente: true, entrada: h?.entrada || '', saida_almoco: h?.saida_almoco || '', retorno_almoco: h?.retorno_almoco || '', saida: h?.saida || '', adicional } };
    });
  }, [obraId, allRegistros, colaborador.id]);

  const updateDay = useCallback((date, _dow, field, value) => {
    if (field === 'valor_producao') return;
    setPontoData(prev => ({
      ...prev,
      [date]: {
        ...(prev[date] || {
          data: date, colaborador_id: colaborador.id, colaborador_nome: colaborador.nome,
          mes: month, ano: year, quinzena,
          tipo_contrato_snapshot: colaborador.tipo_contrato, valor_hora_snapshot: valorHoraAtual,
        }),
        [field]: value,
      },
    }));
  }, [colaborador, month, year, quinzena, valorHoraAtual]);

  // Salvar (upsert) registros desta obra/quinzena
  const saveRegistros = async (extraFields = {}) => {
    const toSave = Object.values(pontoData).filter(p => p.data && days.some(d => d.date === p.data));
    for (const p of toSave) {
      const payload = {
        ...p, ...extraFields,
        colaborador_id: colaborador.id,
        colaborador_nome: colaborador.nome,
        obra_id: obraId,
        obra_nome: obra?.nome || '',
        mes: month, ano: year, quinzena,
        tipo_contrato_snapshot: p.tipo_contrato_snapshot || colaborador.tipo_contrato,
        valor_hora_snapshot: p.valor_hora_snapshot || valorHoraAtual,
      };
      const existing = registros.find(r => r.data === p.data);
      if (existing) await base44.entities.RegistroPonto.update(existing.id, payload);
      else await base44.entities.RegistroPonto.create(payload);
    }
  };

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ['pontos-all', colaborador.id, month, year] });
    queryClient.invalidateQueries({ queryKey: ['pontos-lancamento', month, year] });
  };

  const saveMutation = useMutation({
    mutationFn: () => saveRegistros(),
    onSuccess: invalidateAll,
  });

  const aprovarMutation = useMutation({
    mutationFn: async () => {
      // Salva tudo com aprovado=true
      await saveRegistros({ aprovado: true });
      // Aprova registros já no banco que não estavam no estado local
      const savedDates = new Set(Object.values(pontoData).filter(p => days.some(d => d.date === p.data)).map(p => p.data));
      const pendentes = registros.filter(r => r.quinzena === quinzena && !savedDates.has(r.data) && !r.aprovado);
      for (const r of pendentes) await base44.entities.RegistroPonto.update(r.id, { ...r, aprovado: true });
    },
    onSuccess: () => { invalidateAll(); onApprove?.(); },
  });

  const desaprovarMutation = useMutation({
    mutationFn: async () => {
      const regs = registros.filter(r => r.quinzena === quinzena);
      for (const r of regs) await base44.entities.RegistroPonto.update(r.id, { ...r, aprovado: false });
    },
    onSuccess: invalidateAll,
  });

  const excluirMutation = useMutation({
    mutationFn: async () => {
      // Buscar direto do banco para garantir que apaga tudo, não só o cache
      const regsNoBanco = await base44.entities.RegistroPonto.filter({
        colaborador_id: colaborador.id,
        mes: month,
        ano: year,
        quinzena,
        obra_id: obraId,
      });
      for (const r of regsNoBanco) await base44.entities.RegistroPonto.delete(r.id);
    },
    onSuccess: () => {
      setPontoData({});
      setConfirmDeleteOpen(false);
      invalidateAll();
    },
  });

  // Produção
  const servicosDaObra = useMemo(() => playbook.filter(s => s.obra_id === obraId && s.ativo !== false), [playbook, obraId]);
  const diasComPresenca = useMemo(() => days.filter(d => pontoData[d.date]?.presente), [days, pontoData]);
  const diasSelecionadosParaProducao = useMemo(() => diasComPresenca.filter(d => producaoDiasSelecionados[d.date]), [diasComPresenca, producaoDiasSelecionados]);

  const totalItensProducao = useMemo(() => itensProducao.reduce((sum, item) => {
    const s = playbook.find(x => x.id === item.servicoId);
    const vu = s ? Number(s.valor_unitario || 0) : Number(item.valorUnitarioManual || 0);
    return sum + vu * Number(item.metragem || 0);
  }, 0), [itensProducao, playbook]);

  const openProducao = () => {
    const sel = {};
    diasComPresenca.forEach(d => { sel[d.date] = true; });
    setProducaoDiasSelecionados(sel);
    setItensProducao([{ servicoId: '', metragem: '', valorUnitarioManual: '' }]);
    setProducaoOpen(true);
  };

  const aplicarProducao = () => {
    if (!diasSelecionadosParaProducao.length || totalItensProducao <= 0) return;
    const valorPorDia = totalItensProducao / diasSelecionadosParaProducao.length;
    const itensResumo = itensProducao.filter(item => Number(item.metragem || 0) > 0).map(item => {
      const s = playbook.find(x => x.id === item.servicoId);
      const vu = s ? Number(s.valor_unitario || 0) : Number(item.valorUnitarioManual || 0);
      return { nome: s?.nome || 'Serviço manual', unidade: s?.unidade || 'un', metragem: Number(item.metragem), valor_unitario: vu, total: vu * Number(item.metragem) };
    });
    setPontoData(prev => {
      const updated = { ...prev };
      diasSelecionadosParaProducao.forEach(d => { updated[d.date] = { ...updated[d.date], valor_producao: valorPorDia, itens_producao: itensResumo }; });
      return updated;
    });
    setProducaoOpen(false);
  };

  const excluirProducao = () => {
    setPontoData(prev => {
      const updated = { ...prev };
      days.forEach(d => { if (updated[d.date]) updated[d.date] = { ...updated[d.date], valor_producao: 0, itens_producao: [] }; });
      return updated;
    });
  };

  // Totais
  const totais = useMemo(() => {
    let dias = 0, horasNormais = 0, horasExtra = 0, producao = 0, diarias = 0;
    days.forEach(d => {
      const rec = pontoData[d.date];
      if (!rec?.presente) return;
      dias++;
      const hN = calcHorasNormais(rec.entrada, rec.saida, rec.saida_almoco, rec.retorno_almoco);
      const hE = calcHorasExtra(rec.entrada_extra, rec.saida_extra);
      const fator = getAdicionalFator(rec.adicional);
      const vh = rec.valor_hora_snapshot ?? valorHoraAtual;
      horasNormais += hN;
      horasExtra += hE;
      producao += rec.valor_producao || 0;
      diarias += (hN + hE) * fator * vh;
    });
    const premioClt = isClt ? Math.max(0, producao - diarias) : 0;
    let bruto;
    if (isClt) {
      bruto = diarias + premioClt;
    } else {
      bruto = days.reduce((sum, d) => {
        const rec = pontoData[d.date];
        if (!rec?.presente) return sum;
        const vh = rec.valor_hora_snapshot ?? valorHoraAtual;
        if (rec.valor_producao > 0) return sum + rec.valor_producao;
        const hN = calcHorasNormais(rec.entrada, rec.saida, rec.saida_almoco, rec.retorno_almoco);
        const hE = calcHorasExtra(rec.entrada_extra, rec.saida_extra);
        return sum + (hN + hE) * getAdicionalFator(rec.adicional) * vh;
      }, 0);
    }
    return { dias, horasNormais, horasExtra, producao, diarias, premioClt, bruto };
  }, [days, pontoData, valorHoraAtual, isClt]);

  // Horas padrão da obra por dia da semana
  const getHorasObraParaDia = useCallback((dayOfWeek) => {
    const h = getDefaultHorario(dayOfWeek, horarios);
    if (!h) return 0;
    return calcHorasNormais(h.entrada, h.saida, h.saida_almoco, h.retorno_almoco);
  }, [horarios]);

  return (
    <div className="space-y-3">
      {obra && (
        <div className="text-xs text-muted-foreground bg-muted px-3 py-1.5 rounded-lg inline-block">
          ⏰ Padrão: Seg–Qui {obra.horario_seg_qui_entrada||'07:00'}–{obra.horario_seg_qui_saida||'17:00'} · Sex {obra.horario_sex_saida||'16:00'} · Sáb {obra.horario_sab_saida||'14:00'}
        </div>
      )}

      {/* Botões de ação */}
      <div className="flex flex-wrap gap-2 items-center">
        {!locked ? (
          <>
            <Button variant="outline" size="sm" onClick={openProducao} className="gap-1.5">
              <Factory className="w-3.5 h-3.5" /> Lançar Produção
            </Button>
            {totais.producao > 0 && (
              <Button variant="outline" size="sm" onClick={excluirProducao} className="gap-1.5 text-red-600 border-red-200 hover:bg-red-50">
                <Trash2 className="w-3.5 h-3.5" /> Excluir Produção
              </Button>
            )}
            <Button size="sm" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="gap-1.5">
              <Save className="w-3.5 h-3.5" /> Salvar
            </Button>
            <Button variant="outline" size="sm" onClick={() => setRelatorioOpen(true)} className="gap-1.5">
              <FileBarChart2 className="w-3.5 h-3.5" /> Relatório
            </Button>
            <Button size="sm" className="bg-green-600 hover:bg-green-700 gap-1.5" onClick={() => aprovarMutation.mutate()} disabled={aprovarMutation.isPending}>
              <Check className="w-3.5 h-3.5" /> Aprovar {quinzena === 1 ? '1ª' : '2ª'} Quinzena
            </Button>
          </>
        ) : (
          <>
            {pagamentoPago ? (
              <div className="flex items-center gap-1.5 text-xs text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-lg font-medium">
                <Lock className="w-3 h-3" /> Pagamento quitado — estorne em Pagamentos para editar.
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-green-700 bg-green-50 border border-green-200 px-2.5 py-1 rounded-lg">
                <Lock className="w-3 h-3" /> Aprovado
              </div>
            )}
            <Button variant="outline" size="sm" onClick={() => setRelatorioOpen(true)} className="gap-1.5">
              <FileBarChart2 className="w-3.5 h-3.5" /> Relatório
            </Button>
            {!pagamentoPago && (
              <>
                <Button variant="outline" size="sm" onClick={() => desaprovarMutation.mutate()} disabled={desaprovarMutation.isPending} className="gap-1.5">
                  <Edit className="w-3.5 h-3.5" /> Editar (Desaprovar)
                </Button>
                <Button variant="outline" size="sm" onClick={() => setConfirmDeleteOpen(true)} className="gap-1.5 text-red-600 border-red-200 hover:bg-red-50">
                  <Trash2 className="w-3.5 h-3.5" /> Excluir Ponto
                </Button>
              </>
            )}
          </>
        )}
      </div>

      {/* Resumo */}
      <div className="flex flex-wrap gap-4 text-xs bg-muted/50 rounded-lg px-4 py-2.5">
        <div><span className="text-muted-foreground">Dias:</span> <span className="font-bold ml-1">{totais.dias}</span></div>
        <div><span className="text-muted-foreground">Valor/h:</span> <span className="font-bold text-blue-600 ml-1">R$ {valorHoraAtual.toFixed(2)}</span></div>
        <div>
          <span className="text-muted-foreground">Horas:</span>
          <span className="font-bold text-primary ml-1">{formatHoras(totais.horasNormais)}</span>
          {totais.horasExtra > 0 && <span className="text-orange-600 font-bold ml-1">+{formatHoras(totais.horasExtra)} extra</span>}
        </div>
        <div><span className="text-muted-foreground">Valor Horas:</span> <span className="font-bold text-blue-600 ml-1">R$ {totais.diarias.toFixed(2)}</span></div>
        <div><span className="text-muted-foreground">Produção:</span> <span className="font-bold text-green-600 ml-1">R$ {totais.producao.toFixed(2)}</span></div>
        {isClt && totais.producao > 0 && (
          <div className="flex items-center gap-1">
            <Award className="w-3 h-3 text-yellow-600" />
            <span className="text-muted-foreground">Prêmio CLT:</span>
            <span className={`font-bold ml-1 ${totais.premioClt > 0 ? 'text-yellow-600' : 'text-muted-foreground'}`}>R$ {totais.premioClt.toFixed(2)}</span>
          </div>
        )}
        <div><span className="text-muted-foreground">Total:</span> <span className="font-bold text-foreground ml-1">R$ {totais.bruto.toFixed(2)}</span></div>
      </div>

      {/* Tabela de ponto */}
      <div className="overflow-x-auto border rounded-lg bg-white">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-slate-900 text-white border-b">
              <th className="px-3 py-3 text-left font-semibold w-20">Data</th>
              <th className="px-2 py-3 text-center font-semibold w-12">Status</th>
              <th className="px-2 py-3 text-left font-semibold">Entrada</th>
              <th className="px-2 py-3 text-left font-semibold">Almoço</th>
              <th className="px-2 py-3 text-left font-semibold">Saída</th>
              <th className="px-2 py-3 text-left font-semibold">Extra</th>
              <th className="px-2 py-3 text-left font-semibold w-24">Adic.</th>
              <th className="px-3 py-3 text-center font-semibold">Horas</th>
              <th className="px-3 py-3 text-right font-semibold w-28">Valor a Receber</th>
            </tr>
          </thead>
          <tbody>
            {days.map(day => {
              const jaTemOutraObra = allRegistros.some(r => r.data === day.date && r.colaborador_id === colaborador.id && r.obra_id !== obraId && r.presente);
              const horasObraParaDia = getHorasObraParaDia(day.dayOfWeek);
              return (
                <PontoRow
                  key={day.date}
                  day={day}
                  rec={pontoData[day.date] || {}}
                  isAprovada={locked}
                  isAutonomo={!isClt}
                  onPresenca={handlePresenca}
                  onUpdate={updateDay}
                  jaTemOutraObra={jaTemOutraObra}
                  valorHoraAtual={valorHoraAtual}
                  horasObraParaDia={horasObraParaDia}
                />
              );
            })}
          </tbody>
        </table>
      </div>

      {isClt && totais.premioClt > 0 && (
        <div className="flex justify-end">
          <div className="text-sm flex items-center gap-1.5 text-yellow-700 bg-yellow-50 border border-yellow-200 px-3 py-1.5 rounded-lg">
            <Award className="w-3.5 h-3.5" />
            <span>Prêmio/Bônus CLT: <span className="font-bold">R$ {totais.premioClt.toFixed(2)}</span></span>
          </div>
        </div>
      )}

      {/* Modal Produção */}
      <Dialog open={producaoOpen} onOpenChange={setProducaoOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Lançar Produção — {obra?.nome}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold">Serviços Executados</label>
                <Button size="sm" variant="outline" onClick={() => setItensProducao(p => [...p, { servicoId: '', metragem: '', valorUnitarioManual: '' }])} className="gap-1 h-7 text-xs">
                  <Plus className="w-3 h-3" /> Adicionar
                </Button>
              </div>
              <div className="space-y-2">
                <div className="grid grid-cols-12 gap-2 text-xs text-muted-foreground font-medium px-1">
                  <div className="col-span-5">Serviço</div>
                  <div className="col-span-2 text-right">Qtd</div>
                  <div className="col-span-2 text-right">R$/un</div>
                  <div className="col-span-2 text-right">Total</div>
                  <div className="col-span-1" />
                </div>
                {itensProducao.map((item, idx) => {
                  const s = playbook.find(x => x.id === item.servicoId);
                  const vu = s ? Number(s.valor_unitario || 0) : Number(item.valorUnitarioManual || 0);
                  const subtotal = vu * Number(item.metragem || 0);
                  return (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-muted/30 rounded-lg px-2 py-1.5">
                      <div className="col-span-5">
                        <Select value={item.servicoId} onValueChange={v => setItensProducao(p => p.map((x, i) => i === idx ? { ...x, servicoId: v } : x))}>
                          <SelectTrigger className="h-7 text-xs"><SelectValue placeholder={servicosDaObra.length ? 'Selecionar...' : 'Sem playbook'} /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value={null}>— Manual —</SelectItem>
                            {servicosDaObra.map(s => <SelectItem key={s.id} value={s.id}>{s.nome} ({s.unidade})</SelectItem>)}
                          </SelectContent>
                        </Select>
                        {!item.servicoId && <Input className="h-6 text-xs mt-1" placeholder="Nome do serviço..." value={item.nomeManual || ''} onChange={e => setItensProducao(p => p.map((x, i) => i === idx ? { ...x, nomeManual: e.target.value } : x))} />}
                      </div>
                      <div className="col-span-2">
                        <Input type="number" className="h-7 text-xs text-right" placeholder={s?.unidade || 'qtd'} value={item.metragem} onChange={e => setItensProducao(p => p.map((x, i) => i === idx ? { ...x, metragem: e.target.value } : x))} />
                      </div>
                      <div className="col-span-2">
                        {s ? <span className="text-xs text-right block font-medium text-muted-foreground">R$ {vu.toFixed(2)}</span>
                          : <Input type="number" className="h-7 text-xs text-right" placeholder="R$/un" value={item.valorUnitarioManual} onChange={e => setItensProducao(p => p.map((x, i) => i === idx ? { ...x, valorUnitarioManual: e.target.value } : x))} />}
                      </div>
                      <div className="col-span-2 text-right">
                        <span className={`text-xs font-bold ${subtotal > 0 ? 'text-green-700' : 'text-muted-foreground'}`}>{subtotal > 0 ? `R$ ${subtotal.toFixed(2)}` : '—'}</span>
                      </div>
                      <div className="col-span-1 flex justify-end">
                        <button onClick={() => setItensProducao(p => p.filter((_, i) => i !== idx))} disabled={itensProducao.length === 1} className="text-red-400 hover:text-red-600 disabled:opacity-30">
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
                <div className="flex justify-end items-center gap-2 border-t pt-2">
                  <span className="text-sm text-muted-foreground">Total:</span>
                  <span className="text-base font-bold text-green-700">R$ {totalItensProducao.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold">Dias para rateio</label>
                <div className="flex gap-2 text-xs">
                  <button className="text-primary underline" onClick={() => { const s = {}; diasComPresenca.forEach(d => { s[d.date] = true; }); setProducaoDiasSelecionados(s); }}>Todos</button>
                  <button className="text-muted-foreground underline" onClick={() => setProducaoDiasSelecionados({})}>Nenhum</button>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-1.5 max-h-40 overflow-y-auto border rounded-lg p-2">
                {diasComPresenca.length === 0 && <p className="col-span-4 text-xs text-muted-foreground text-center py-2">Nenhum dia com presença.</p>}
                {diasComPresenca.map(d => (
                  <label key={d.date} className={`flex items-center gap-1.5 text-xs cursor-pointer p-1.5 rounded hover:bg-muted/50 ${producaoDiasSelecionados[d.date] ? 'bg-primary/10 text-primary font-medium' : ''}`}>
                    <Checkbox checked={!!producaoDiasSelecionados[d.date]} onCheckedChange={c => setProducaoDiasSelecionados(p => ({ ...p, [d.date]: !!c }))} />
                    {String(d.day).padStart(2, '0')} {d.dayName}
                  </label>
                ))}
              </div>
              {diasSelecionadosParaProducao.length > 0 && totalItensProducao > 0 && (
                <p className="text-xs text-muted-foreground mt-1.5 bg-green-50 border border-green-100 px-2 py-1 rounded">
                  R$ {(totalItensProducao / diasSelecionadosParaProducao.length).toFixed(2)}/dia × {diasSelecionadosParaProducao.length} dia(s) = <strong>R$ {totalItensProducao.toFixed(2)}</strong>
                </p>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setProducaoOpen(false)}>Cancelar</Button>
              <Button onClick={aplicarProducao} disabled={totalItensProducao <= 0 || diasSelecionadosParaProducao.length === 0}>Aplicar Produção</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Relatório de produção */}
      <Dialog open={relatorioOpen} onOpenChange={setRelatorioOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Relatório de Produção — {obra?.nome}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {days.filter(d => pontoData[d.date]?.valor_producao > 0).length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">Nenhuma produção lançada.</p>
            ) : (
              <table className="w-full text-sm border rounded-lg overflow-hidden">
                <thead>
                  <tr className="bg-muted text-xs">
                    <th className="text-left px-3 py-2">Data</th>
                    <th className="text-left px-3 py-2">Serviço</th>
                    <th className="text-right px-3 py-2">Qtd</th>
                    <th className="text-right px-3 py-2">R$/un</th>
                    <th className="text-right px-3 py-2">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {days.map(d => {
                    const rec = pontoData[d.date];
                    if (!rec?.valor_producao && !rec?.itens_producao?.length) return null;
                    if (rec.itens_producao?.length > 0) {
                      return rec.itens_producao.map((it, i) => (
                        <tr key={`${d.date}-${i}`} className="border-t hover:bg-muted/20">
                          {i === 0 && <td className="px-3 py-2 font-medium" rowSpan={rec.itens_producao.length}>{String(d.day).padStart(2, '0')} {d.dayName}</td>}
                          <td className="px-3 py-2">{it.nome}</td>
                          <td className="px-3 py-2 text-right">{it.metragem} {it.unidade}</td>
                          <td className="px-3 py-2 text-right">R$ {Number(it.valor_unitario || 0).toFixed(2)}</td>
                          <td className="px-3 py-2 text-right font-medium text-green-700">R$ {Number(it.total || 0).toFixed(2)}</td>
                        </tr>
                      ));
                    }
                    return (
                      <tr key={d.date} className="border-t hover:bg-muted/20">
                        <td className="px-3 py-2 font-medium">{String(d.day).padStart(2, '0')} {d.dayName}</td>
                        <td className="px-3 py-2 text-muted-foreground italic">Manual</td>
                        <td colSpan={2} className="px-3 py-2 text-right">—</td>
                        <td className="px-3 py-2 text-right font-medium text-green-700">R$ {Number(rec.valor_producao).toFixed(2)}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t bg-muted/50">
                    <td colSpan={4} className="px-3 py-2 font-semibold text-right">Total Produção:</td>
                    <td className="px-3 py-2 font-bold text-green-700">R$ {totais.producao.toFixed(2)}</td>
                  </tr>
                </tfoot>
              </table>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirmar exclusão */}
      <Dialog open={confirmDeleteOpen} onOpenChange={setConfirmDeleteOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir Ponto da Quinzena</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Excluirá <strong>todos os {registros.filter(r => r.quinzena === quinzena).length} registros</strong> de <strong>{colaborador.nome}</strong> na obra <strong>{obra?.nome}</strong>. Esta ação não pode ser desfeita.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setConfirmDeleteOpen(false)}>Cancelar</Button>
            <Button variant="destructive" onClick={() => excluirMutation.mutate()} disabled={excluirMutation.isPending}>
              <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Excluir Tudo
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}