import { createClientFromRequest } from 'npm:@base44/sdk@0.8.21';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { colaborador_id, mes, ano, quinzena } = await req.json();

    if (!colaborador_id || !mes || !ano || !quinzena) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Buscar dados do colaborador
    const colaborador = await base44.asServiceRole.entities.Colaborador.get(colaborador_id);
    if (!colaborador || colaborador.status !== 'ativo') {
      return Response.json({ error: 'Inactive or non-existent colaborador' }, { status: 404 });
    }

    if (!colaborador.vt_tipo || colaborador.vt_tipo === 'sem_vt') {
      return Response.json({ error: 'Colaborador has no VT type' }, { status: 400 });
    }

    // Calcular dias úteis da quinzena
    const diasQuinzena = quinzena === 1 ? [1, 15] : [16, new Date(ano, mes, 0).getDate()];
    const diasUteis = calcularDiasUteis(mes, ano, diasQuinzena[0], diasQuinzena[1]);

    // Buscar registros de ponto da quinzena
    const registros = await base44.asServiceRole.entities.RegistroPonto.filter({
      colaborador_id,
      mes,
      ano,
      quinzena
    });

    // Contar dias trabalhados
    const diasTrabalhados = registros.filter(r => r.presente || r.tipo === 'normal').length;

    // Calcular VT
    const valorDiario = colaborador.vt_valor_diario || 0;
    const valorVT = diasTrabalhados * valorDiario;

    // Se faltou dias, criar desconto para próximo pagamento
    const diasFaltantes = diasUteis - diasTrabalhados;
    if (diasFaltantes > 0) {
      const valorDesconto = diasFaltantes * valorDiario;
      
      // Criar pagamento de desconto na próxima quinzena
      const proximaQuinzena = quinzena === 1 ? 2 : 1;
      const proximoMes = proximaQuinzena === 1 ? mes + 1 : mes;
      const proximoAno = proximoMes > 12 ? ano + 1 : ano;

      await base44.asServiceRole.entities.Pagamento.create({
        colaborador_id,
        colaborador_nome: colaborador.nome,
        tipo: 'outros',
        descricao: `Desconto VT - ${diasFaltantes} dias ausentes`,
        referencia: `${proximoMes < 10 ? '0' : ''}${proximoMes}/${proximoAno} - ${proximaQuinzena === 1 ? '1ª' : '2ª'} Quinzena`,
        mes: proximoMes > 12 ? 1 : proximoMes,
        ano: proximoAno,
        quinzena: proximaQuinzena,
        valor: -valorDesconto,
        descontar: true,
        data_desconto: proximaQuinzena === 1 ? `${proximoAno}-${String(proximoMes).padStart(2, '0')}-05` : `${proximoAno}-${String(proximoMes).padStart(2, '0')}-20`,
        status: 'pendente'
      });
    }

    // Criar ou atualizar lançamento de VT
    const lancamentoExistente = await base44.asServiceRole.entities.ValeTransporteLancamento.filter({
      colaborador_id,
      mes,
      ano
    }).then(l => l[0]);

    if (lancamentoExistente) {
      await base44.asServiceRole.entities.ValeTransporteLancamento.update(lancamentoExistente.id, {
        valor_total: valorVT,
        dias_trabalhados: diasTrabalhados,
        status: 'lancado'
      });
    } else {
      await base44.asServiceRole.entities.ValeTransporteLancamento.create({
        colaborador_id,
        colaborador_nome: colaborador.nome,
        mes,
        ano,
        valor_dia: valorDiario,
        dias_esperados: diasUteis,
        dias_trabalhados: diasTrabalhados,
        valor_total: valorVT,
        status: 'lancado'
      });
    }

    return Response.json({ success: true, valorVT, diasTrabalhados, diasFaltantes });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function calcularDiasUteis(mes, ano, diaInicio, diaFim) {
  let dias = 0;
  for (let d = diaInicio; d <= diaFim; d++) {
    const date = new Date(ano, mes - 1, d);
    const dow = date.getDay();
    // Conta seg-sex
    if (dow !== 0 && dow !== 6) dias++;
  }
  return dias;
}