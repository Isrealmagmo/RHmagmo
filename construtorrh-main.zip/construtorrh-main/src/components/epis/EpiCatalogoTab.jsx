import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Plus, Trash2, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const CATEGORIAS = [
  'cabeca', 'olhos_face', 'audicao', 'respiratorio',
  'tronco', 'maos_bracos', 'pes_pernas', 'queda', 'outros'
];

const CATEGORIA_CORES = {
  'cabeca': { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
  'olhos_face': { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200' },
  'audicao': { bg: 'bg-pink-50', text: 'text-pink-700', border: 'border-pink-200' },
  'respiratorio': { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200' },
  'tronco': { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' },
  'maos_bracos': { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
  'pes_pernas': { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  'queda': { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200' },
  'outros': { bg: 'bg-slate-50', text: 'text-slate-700', border: 'border-slate-200' }
};

export default function EpiCatalogoTab() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editando, setEditando] = useState(null);
  const [filtroCategoria, setFiltroCategoria] = useState('todas');
  const [formData, setFormData] = useState({
    nome: '',
    ca: '',
    descricao: '',
    requer_tamanho: false,
    validade_meses: 12,
    categoria: 'outros',
  });

  const { data: epis = [] } = useQuery({
    queryKey: ['epi-catalogo'],
    queryFn: () => base44.entities.EpiCatalogo.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.EpiCatalogo.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['epi-catalogo'] });
      setDialogOpen(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.EpiCatalogo.update(editando.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['epi-catalogo'] });
      setDialogOpen(false);
      setEditando(null);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EpiCatalogo.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['epi-catalogo'] }),
  });

  const resetForm = () => {
    setFormData({
      nome: '',
      ca: '',
      descricao: '',
      requer_tamanho: false,
      validade_meses: 12,
      categoria: 'outros',
    });
  };

  const handleSave = () => {
    if (!formData.nome) return;
    if (editando) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (epi) => {
    setEditando(epi);
    setFormData(epi);
    setDialogOpen(true);
  };

  // Agrupar por categoria e filtrar
  const agrupado = useMemo(() => {
    const filtered = filtroCategoria === 'todas' 
      ? epis 
      : epis.filter(e => (e.categoria || 'outros') === filtroCategoria);
    
    const map = {};
    filtered.forEach(epi => {
      const cat = epi.categoria || 'outros';
      if (!map[cat]) map[cat] = [];
      map[cat].push(epi);
    });
    return map;
  }, [epis, filtroCategoria]);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <label className="text-sm font-medium">Filtro:</label>
          <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as categorias</SelectItem>
              {CATEGORIAS.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat.replace(/_/g, ' ')}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => { resetForm(); setEditando(null); setDialogOpen(true); }} className="gap-1.5">
          <Plus className="w-4 h-4" /> Novo EPI
        </Button>
      </div>

      <div className="space-y-6">
        {epis.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Nenhum EPI cadastrado no catálogo.</p>
        ) : (
          Object.entries(agrupado).map(([categoria, items]) => {
            const cores = CATEGORIA_CORES[categoria] || CATEGORIA_CORES['outros'];
            return (
              <div key={categoria}>
                <h3 className={`text-sm font-semibold mb-3 px-3 py-2 rounded-md ${cores.bg} ${cores.text}`}>
                  {categoria.replace(/_/g, ' ').toUpperCase()}
                </h3>
                <div className="grid gap-3">
                  {items.map((epi) => (
                    <div key={epi.id} className={`border rounded-lg p-4 space-y-2 ${cores.bg} ${cores.border}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className={`font-semibold ${cores.text}`}>{epi.nome}</h4>
                          {epi.ca && <p className={`text-xs ${cores.text} opacity-70`}>CA: {epi.ca}</p>}
                          {epi.descricao && <p className={`text-sm ${cores.text} opacity-70 mt-1`}>{epi.descricao}</p>}
                        </div>
                        <div className="flex gap-2">
                          <Button size="icon" variant="ghost" onClick={() => handleEdit(epi)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="text-red-600 hover:bg-red-100"
                            onClick={() => {
                              if (window.confirm(`Remover ${epi.nome}?`)) {
                                deleteMutation.mutate(epi.id);
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <div className={`flex gap-4 text-xs ${cores.text} opacity-70`}>
                        {epi.requer_tamanho && <span>✓ Requer tamanho</span>}
                        {epi.validade_meses && <span>Validade: {epi.validade_meses}m</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editando ? 'Editar EPI' : 'Novo EPI'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Nome *</label>
              <Input
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="Ex: Capacete de Segurança"
              />
            </div>
            <div>
              <label className="text-sm font-medium">CA</label>
              <Input
                value={formData.ca}
                onChange={(e) => setFormData({ ...formData, ca: e.target.value })}
                placeholder="Número do CA"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Descrição</label>
              <Input
                value={formData.descricao}
                onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                placeholder="Descrição do EPI"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Categoria</label>
              <Select value={formData.categoria} onValueChange={(v) => setFormData({ ...formData, categoria: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIAS.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat.replace('_', ' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Validade (meses)</label>
              <Input
                type="number"
                value={formData.validade_meses}
                onChange={(e) => setFormData({ ...formData, validade_meses: parseInt(e.target.value) || 0 })}
              />
            </div>
            <label className="flex items-center gap-2 text-sm font-medium">
              <input
                type="checkbox"
                checked={formData.requer_tamanho}
                onChange={(e) => setFormData({ ...formData, requer_tamanho: e.target.checked })}
              />
              Requer tamanho
            </label>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
                Salvar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}