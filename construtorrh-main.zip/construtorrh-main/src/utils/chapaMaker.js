// Gera chapa automática: FUNCNOMEABREV + MÊS + ANO + SEQUENCIAL
// Exemplo: PED0326-001 (Pedreiro, 03/2026, sequencial 001)
// Garante unicidade verificando contra todas as chapas existentes

export const generateChapa = (funcaoNome, todosOsColaboradores = [], dataAdmissao = '') => {
  if (!funcaoNome || funcaoNome.trim() === '') return '';

  // Pega primeiras 3 letras em maiúscula
  const abrev = funcaoNome.slice(0, 3).toUpperCase();
  
  // Extrai mês e ano da data de admissão ou usa data atual
  let mes, ano;
  if (dataAdmissao) {
    const date = new Date(dataAdmissao);
    mes = String(date.getMonth() + 1).padStart(2, '0');
    ano = date.getFullYear().toString().slice(-2);
  } else {
    const now = new Date();
    mes = String(now.getMonth() + 1).padStart(2, '0');
    ano = now.getFullYear().toString().slice(-2);
  }
  
  // Extrai todas as chapas já usadas com este prefixo (abrev+mes+ano)
  const prefix = `${abrev}${mes}${ano}`;
  const chapasPrefixoAtual = todosOsColaboradores
    .filter(c => c.chapa && c.chapa.startsWith(prefix))
    .map(c => {
      const match = c.chapa.match(/\d{3}$/);
      return match ? parseInt(match[0], 10) : 0;
    })
    .sort((a, b) => b - a);

  // Encontra o próximo sequencial disponível
  let proximoSequencial = 1;
  if (chapasPrefixoAtual.length > 0) {
    proximoSequencial = chapasPrefixoAtual[0] + 1;
  }

  const sequencial = String(proximoSequencial).padStart(3, '0');
  return `${abrev}${mes}${ano}-${sequencial}`;
};