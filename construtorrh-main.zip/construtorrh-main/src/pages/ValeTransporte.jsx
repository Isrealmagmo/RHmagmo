import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Bus, Plus, CreditCard, Search, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import PageHeader from '@/components/ui/PageHeader';
import { Checkbox } from '@/components/ui/checkbox';

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const vtTypeLabels = { bilhete_unico: '🎫 Bilhete Único', cartao_transporte: '💳 Cartão Transporte', dinheiro: '💵 Dinheiro', sem_vt: '— Sem VT' };

// Quinzenas fixas:
// 1ª quinzena (paga dia 05): cobre 06 → 20 do mesmo mês
// 2ª quinzena (paga dia 20): cobre 21 → 05 do próximo mês
function getRangeQuinzena(ano, mes, quinzena) {
  if (quinzena === 1) {
    return { inicio: new Date(ano, mes - 1, 6), fim: new Date(ano, mes - 1, 20) };
  } else {
    // 2ª quinzena: 21 do mês atual até 5 do próximo mês
    const proximoMes = mes === 12 ? 1 : mes + 1;
    const proximoAno = mes === 12 ? ano + 1 : ano;
    return { inicio: new Date(ano, mes - 1, 21), fim: new Date(proximoAno, proximoMes - 1, 5) };
  }
}

// Conta dias úteis (seg-sex) entre dois objetos Date (inclusive)
function contarDiasUteisRange(inicio, fim) {
  let count = 0;
  const cur = new Date(inicio);
  while (cur <= fim) {
    const dow = cur.getDay();
    if (dow >= 1 && dow <= 5) count++;
    cur.setDate(cur.getDate() + 1);
  }
  return count;
}

// Dias úteis da quinzena, respeitando data_admissao do colaborador
function diasUteisQuinzenaColab(ano, mes, quinzena, dataAdmissao) {
  const { inicio, fim } = getRangeQuinzena(ano, mes, quinzena);
  // Se admissão existe e é depois do início da quinzena, começa da admissão
  const admDate = dataAdmissao ? new Date(dataAdmissao + 'T00:00:00') : null;
  const inicioReal = admDate && admDate > inicio ? admDate : inicio;
  if (inicioReal > fim) return 0;
  return contarDiasUteisRange(inicioReal, fim);
}

// Dias úteis totais da quinzena (sem considerar admissão)
function diasUteisQuinzena(ano, mes, quinzena) {
  const { inicio, fim } = getRangeQuinzena(ano, mes, quinzena);
  return contarDiasUteisRange(inicio, fim);
}

// Quinzena anterior
function getQuinzenaAnterior(ano, mes, quinzena) {
  if (quinzena === 2) return { ano, mes, quinzena: 1 };
  if (mes === 1) return { ano: ano - 1, mes: 12, quinzena: 2 };
  return { ano, mes: mes - 1, quinzena: 2 };
}

// String formatada do range
function labelRangeQuinzena(ano, mes, quinzena) {
  const { inicio, fim } = getRangeQuinzena(ano, mes, quinzena);
  const fmt = (d) => `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`;
  return `${fmt(inicio)} a ${fmt(fim)}`;
}

export default function ValeTransporte() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [quinzena, setQuinzena] = useState(now.getDate() <= 15 ? 1 : 2);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(new Set());
  const [avulsoOpen, setAvulsoOpen] = useState(false);
  const [avulsoForm, setAvulsoForm] = useState({ colaborador_id: '', valor_dia: '', dias: '', observacoes: '' });

  const handleAvulsoColabChange = (id) => {
    const colab = colaboradores.find(c => c.id === id);
    setAvulsoForm(prev => ({ ...prev, colaborador_id: id, valor_dia: colab?.vt_valor_diario || '' }));
  };
  const [detalheOpen, setDetalheOpen] = useState(null);
  const queryClient = useQueryClient();

  const qAnterior = getQuinzenaAnterior(year, month, quinzena);

  const { data: colaboradores = [] } = useQuery({ queryKey: ['colaboradores'], queryFn: () => base44.entities.Colaborador.list() });

  // Pontos da quinzena atual e anterior para calcular faltas
  const { data: pontosAtual = [] } = useQuery({
    queryKey: ['pontos-vt', month, year, quinzena],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: month, ano: year, quinzena }),
  });
  const { data: pontosAnterior = [] } = useQuery({
    queryKey: ['pontos-vt', qAnterior.mes, qAnterior.ano, qAnterior.quinzena],
    queryFn: () => base44.entities.RegistroPonto.filter({ mes: qAnterior.mes, ano: qAnterior.ano, quinzena: qAnterior.quinzena }),
  });

  // Lançamentos de VT desta quinzena
  const { data: lancamentos = [] } = useQuery({
    queryKey: ['vt-lanc', month, year, quinzena],
    queryFn: () => base44.entities.ValeTransporteLancamento.filter({ mes: month, ano: year }),
  });

  // Pagamentos de VT desta quinzena para verificar se já foram pagos
  const { data: pagamentosVT = [] } = useQuery({
    queryKey: ['pagamentos-vt', month, year, quinzena],
    queryFn: () => base44.entities.Pagamento.filter({ mes: month, ano: year, tipo: 'vale_transporte', quinzena }),
  });

  const diasQuinzenaAtual = useMemo(() => diasUteisQuinzena(year, month, quinzena), [year, month, quinzena]);

  const colabsComVt = useMemo(() => {
    return colaboradores
      .filter(c => c.status === 'ativo' && c.vt_tipo && c.vt_tipo !== 'sem_vt')
      .map(c => {
        const valorDia = c.vt_valor_diario || 0;

        // Pontos da quinzena atual
        const pontosColabAtual = pontosAtual.filter(p => p.colaborador_id === c.id);
        const diasTrabalhados = pontosColabAtual.filter(p => p.presente).length;
        const temPonto = pontosColabAtual.length > 0;

        // Sábados efetivamente trabalhados na quinzena atual
        const sabadosTrabalhados = pontosColabAtual.filter(p => {
          if (!p.presente) return false;
          const dow = new Date(p.data + 'T00:00:00').getDay();
          return dow === 6;
        }).length;

        // Dias úteis base (seg-sex) respeitando admissão + sábados trabalhados
        const diasColabAtual = diasUteisQuinzenaColab(year, month, quinzena, c.data_admissao) + sabadosTrabalhados;
        const vtCheio = diasColabAtual * valorDia;

        // Faltas na quinzena ANTERIOR (respeitando admissão do colaborador)
        const diasColabAnterior = diasUteisQuinzenaColab(qAnterior.ano, qAnterior.mes, qAnterior.quinzena, c.data_admissao);
        const pontosColabAnterior = pontosAnterior.filter(p => p.colaborador_id === c.id);
        const diasTrabalhAdoAnterior = pontosColabAnterior.filter(p => p.presente).length;
        // Só desconta faltas se o colaborador já estava ativo na quinzena anterior
        const faltasAnterior = diasColabAnterior > 0 ? Math.max(0, diasColabAnterior - diasTrabalhAdoAnterior) : 0;
        const descontoFaltas = faltasAnterior * valorDia;

        // Total líquido a pagar = VT cheio - desconto de faltas da quinzena anterior
        const totalLiquido = Math.max(0, vtCheio - descontoFaltas);

        const lanc = lancamentos.find(l => l.colaborador_id === c.id && l.quinzena === quinzena);
        const pagamento = pagamentosVT.find(p => p.colaborador_id === c.id && p.status !== 'cancelado');
        const vt_pago = pagamento?.status === 'pago';

        const vt_zerado = totalLiquido === 0 && !lanc && !vt_pago;

        return {
          ...c,
          valorDia,
          vtCheio,
          diasTrabalhados,
          temPonto,
          faltasAnterior,
          descontoFaltas,
          totalLiquido,
          diasColabAtual,
          sabadosTrabalhados,
          diasColabAnterior,
          lanc,
          vt_lancado: !!lanc,
          vt_pago,
          vt_zerado,
          vt_status: vt_pago ? 'pago' : lanc ? lanc.status : vt_zerado ? 'zerado' : 'pendente',
        };
      })
      .filter(c => !search || c.nome?.toLowerCase().includes(search.toLowerCase()));
  }, [colaboradores, pontosAtual, pontosAnterior, lancamentos, diasQuinzenaAtual, quinzena, search, year, month, qAnterior]);

  const jaLancados = colabsComVt.filter(c => c.vt_lancado).length;
  const pendentes = colabsComVt.filter(c => !c.vt_lancado && !c.vt_pago && !c.vt_zerado).length;
  const totalSelecionado = [...selected].reduce((s, id) => {
    const c = colabsComVt.find(x => x.id === id);
    return s + (c?.totalLiquido || 0);
  }, 0);

  const lancarMutation = useMutation({
    mutationFn: async (colabs) => {
      const referencia = `${MONTHS[month - 1]}/${year} - ${quinzena === 1 ? '1ª' : '2ª'} Quinzena`;

      // Data de desconto das faltas:
      // 1ª quinzena → desconto no dia 20 do mesmo mês
      // 2ª quinzena → desconto no dia 05 do próximo mês
      const getDataDesconto = () => {
        if (quinzena === 1) {
          return `${year}-${String(month).padStart(2,'0')}-20`;
        } else {
          const proxMes = month === 12 ? 1 : month + 1;
          const proxAno = month === 12 ? year + 1 : year;
          return `${proxAno}-${String(proxMes).padStart(2,'0')}-05`;
        }
      };

      for (const c of colabs) {
        const existente = lancamentos.find(l => l.colaborador_id === c.id && l.quinzena === quinzena);
        const payload = {
          colaborador_id: c.id,
          colaborador_nome: c.nome,
          mes: month,
          ano: year,
          quinzena,
          valor_dia: c.valorDia,
          dias_esperados: diasQuinzenaAtual,
          dias_trabalhados: c.diasTrabalhados,
          valor_total: c.totalLiquido,
          status: 'lancado',
          observacoes: c.faltasAnterior > 0 ? `Desconto de ${c.faltasAnterior} falta(s) da quinzena anterior: -R$ ${c.descontoFaltas.toFixed(2)}` : '',
        };
        if (existente) await base44.entities.ValeTransporteLancamento.update(existente.id, payload);
        else await base44.entities.ValeTransporteLancamento.create(payload);

        // Criar pagamento de VT (valor líquido a receber)
        const pagamentoExistente = await base44.entities.Pagamento.filter({
          colaborador_id: c.id, mes: month, ano: year, tipo: 'vale_transporte', quinzena,
        });
        if (pagamentoExistente.length === 0) {
          await base44.entities.Pagamento.create({
            colaborador_id: c.id,
            colaborador_nome: c.nome,
            tipo: 'vale_transporte',
            referencia,
            mes: month,
            ano: year,
            quinzena,
            valor: c.totalLiquido,
            status: 'pendente',
            descricao: `VT ${quinzena === 1 ? '1ª' : '2ª'} Quinzena${c.faltasAnterior > 0 ? ` (desc. ${c.faltasAnterior} falta(s))` : ''}`,
          });
        }

        // Se há desconto de faltas, criar adiantamento para ser descontado no fechamento do salário
        if (c.descontoFaltas > 0) {
          const dataDesconto = getDataDesconto();
          const adiantExistente = await base44.entities.Pagamento.filter({
            colaborador_id: c.id, mes: month, ano: year, tipo: 'adiantamento',
            descricao: `Desc. faltas VT ${quinzena === 1 ? '1ª' : '2ª'} Quinzena`,
          });
          if (adiantExistente.length === 0) {
            await base44.entities.Pagamento.create({
              colaborador_id: c.id,
              colaborador_nome: c.nome,
              tipo: 'adiantamento',
              referencia,
              mes: month,
              ano: year,
              quinzena,
              valor: c.descontoFaltas,
              status: 'pendente',
              descontar: true,
              data_desconto: dataDesconto,
              descricao: `Desc. faltas VT ${quinzena === 1 ? '1ª' : '2ª'} Quinzena`,
            });
          }
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vt-lanc'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos-vt'] });
      setSelected(new Set());
    },
  });

  const avulsoMutation = useMutation({
    mutationFn: async () => {
      const c = colaboradores.find(x => x.id === avulsoForm.colaborador_id);
      if (!c) return;
      const total = Number(avulsoForm.valor_dia) * Number(avulsoForm.dias);
      await base44.entities.ValeTransporteLancamento.create({
        colaborador_id: c.id,
        colaborador_nome: c.nome,
        mes: month,
        ano: year,
        quinzena,
        valor_dia: Number(avulsoForm.valor_dia),
        dias_esperados: Number(avulsoForm.dias),
        dias_trabalhados: Number(avulsoForm.dias),
        valor_total: total,
        status: 'lancado',
        observacoes: avulsoForm.observacoes,
      });
      await base44.entities.Pagamento.create({
        colaborador_id: c.id,
        colaborador_nome: c.nome,
        tipo: 'vale_transporte',
        referencia: `${MONTHS[month - 1]}/${year} - VT Avulso`,
        mes: month,
        ano: year,
        quinzena,
        valor: total,
        status: 'pendente',
        descricao: avulsoForm.observacoes || 'VT Avulso',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vt-lanc'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
      setAvulsoOpen(false);
      setAvulsoForm({ colaborador_id: '', valor_dia: '', dias: '', observacoes: '' });
    },
  });

  const toggleSelect = (id) => setSelected(prev => {
    const n = new Set(prev);
    if (n.has(id)) n.delete(id); else n.add(id);
    return n;
  });

  const toggleAll = () => {
    const pendentesIds = colabsComVt.filter(c => !c.vt_lancado && !c.vt_pago && !c.vt_zerado).map(c => c.id);
    if (pendentesIds.every(id => selected.has(id))) setSelected(new Set());
    else setSelected(new Set(pendentesIds));
  };

  const detalhe = detalheOpen ? colabsComVt.find(c => c.id === detalheOpen) : null;

  return (
    <div>
      <PageHeader title="Pagamento de Vale Transporte" subtitle="VT cheio por quinzena — faltas anteriores descontadas do salário" icon={Bus}>
        <Button variant="outline" className="gap-1.5" onClick={() => setAvulsoOpen(true)}><Plus className="w-4 h-4" /> VT Avulso</Button>
        <Button
          className="gap-1.5"
          disabled={selected.size === 0 || lancarMutation.isPending}
          onClick={() => {
            const colabs = colabsComVt.filter(c => selected.has(c.id));
            lancarMutation.mutate(colabs);
          }}
        >
          <CreditCard className="w-4 h-4" /> Lançar VT Selecionados ({selected.size}) — R$ {totalSelecionado.toFixed(2)}
        </Button>
      </PageHeader>

      {/* Filtros */}
      <div className="flex flex-wrap gap-2 mb-4 items-center">
        <Select value={String(month)} onValueChange={v => setMonth(Number(v))}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>{MONTHS.map((m, i) => <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(year)} onValueChange={v => setYear(Number(v))}>
          <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
          <SelectContent>{[2024,2025,2026,2027].map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={String(quinzena)} onValueChange={v => setQuinzena(Number(v))}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1ª Quinzena (6–20)</SelectItem>
            <SelectItem value="2">2ª Quinzena (21–5)</SelectItem>
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Nome do colaborador..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      {/* Info box */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg px-3 py-2 text-xs text-blue-700 mb-4 flex items-start gap-2">
        <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
        <div>
          <strong>Regra de cálculo:</strong> VT cheio pela {quinzena === 1 ? '1ª' : '2ª'} quinzena <strong>({labelRangeQuinzena(year, month, quinzena)})</strong> — {diasQuinzenaAtual} dias úteis.
          Admissão no meio da quinzena? Calculado a partir da data de entrada. Faltas da quinzena anterior são <strong>descontadas do salário</strong>.
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <Card className="border-l-4 border-l-blue-500"><CardContent className="p-3"><p className="text-[10px] uppercase text-muted-foreground font-semibold">Colaboradores com VT</p><p className="text-lg font-bold">{colabsComVt.length}</p></CardContent></Card>
        <Card className="border-l-4 border-l-green-500"><CardContent className="p-3"><p className="text-[10px] uppercase text-muted-foreground font-semibold">Já Lançados</p><p className="text-lg font-bold">{jaLancados}</p></CardContent></Card>
        <Card className="border-l-4 border-l-yellow-500"><CardContent className="p-3"><p className="text-[10px] uppercase text-muted-foreground font-semibold">Pendentes</p><p className="text-lg font-bold text-yellow-600">{pendentes}</p></CardContent></Card>
        <Card className="border-l-4 border-l-purple-500"><CardContent className="p-3"><p className="text-[10px] uppercase text-muted-foreground font-semibold">Total Selecionado</p><p className="text-lg font-bold">R$ {totalSelecionado.toFixed(2)}</p></CardContent></Card>
      </div>

      {/* Tabela */}
      <div className="border rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-sidebar text-sidebar-foreground">
              <th className="px-3 py-3 text-left w-8">
                <Checkbox checked={colabsComVt.filter(c => !c.vt_lancado).length > 0 && colabsComVt.filter(c => !c.vt_lancado).every(c => selected.has(c.id))} onCheckedChange={toggleAll} />
              </th>
              <th className="px-3 py-3 text-left font-medium">Colaborador</th>
              <th className="px-3 py-3 text-left font-medium">Tipo VT</th>
              <th className="px-3 py-3 text-right font-medium">Valor/Dia</th>
              <th className="px-3 py-3 text-right font-medium">Dias Quinzena</th>
              <th className="px-3 py-3 text-right font-medium">VT Cheio</th>
              <th className="px-3 py-3 text-right font-medium">Desc. Faltas</th>
              <th className="px-3 py-3 text-right font-medium">Total Líquido</th>
              <th className="px-3 py-3 text-left font-medium">Status</th>
              <th className="px-3 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {colabsComVt.length === 0 ? (
              <tr><td colSpan={10} className="text-center py-8 text-muted-foreground">Nenhum colaborador com VT</td></tr>
            ) : (
              colabsComVt.map(c => (
                <tr key={c.id} className={`border-t hover:bg-muted/30 ${c.vt_lancado ? 'opacity-70' : ''}`}>
                  <td className="px-3 py-3">
                    {!c.vt_lancado && !c.vt_pago && !c.vt_zerado && (
                      <Checkbox checked={selected.has(c.id)} onCheckedChange={() => toggleSelect(c.id)} />
                    )}
                  </td>
                  <td className="px-3 py-3">
                    <p className="font-medium text-sm">{c.nome}</p>
                    <p className="text-xs text-muted-foreground">{c.chapa} · {c.funcao_nome}</p>
                    <div className="flex gap-1 mt-1 flex-wrap">
                      {(c.vt_trechos_ida || []).map((t, i) => (
                        <span key={i} className="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded text-[10px]">Trecho R${t.valor?.toFixed(2)}</span>
                      ))}
                    </div>
                  </td>
                  <td className="px-3 py-3"><span className="text-xs">{vtTypeLabels[c.vt_tipo] || c.vt_tipo}</span></td>
                  <td className="px-3 py-3 text-right">R$ {c.valorDia.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">
                    {c.diasColabAtual}d
                    {c.sabadosTrabalhados > 0 && <span className="text-[10px] text-blue-600 ml-1">(+{c.sabadosTrabalhados} sáb)</span>}
                  </td>
                  <td className="px-3 py-3 text-right font-medium">R$ {c.vtCheio.toFixed(2)}</td>
                  <td className="px-3 py-3 text-right">
                    {c.descontoFaltas > 0 ? (
                      <span className="text-red-600 font-semibold">- R$ {c.descontoFaltas.toFixed(2)}<br/><span className="text-[10px] font-normal">{c.faltasAnterior} falta(s)</span></span>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </td>
                  <td className="px-3 py-3 text-right font-bold text-green-700">R$ {c.totalLiquido.toFixed(2)}</td>
                  <td className="px-3 py-3">
                    {c.vt_pago ? (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">✓ Pago</span>
                    ) : c.vt_lancado ? (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Lançado</span>
                    ) : c.vt_zerado ? (
                      <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full font-medium">— R$ 0,00</span>
                    ) : (
                      <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-medium">Pendente</span>
                    )}
                  </td>
                  <td className="px-3 py-3">
                    <Button size="sm" variant="ghost" onClick={() => setDetalheOpen(c.id)}>
                      <Info className="w-4 h-4" />
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
          {colabsComVt.length > 0 && (
            <tfoot>
              <tr className="border-t bg-muted/60">
                <td colSpan={5} className="px-3 py-2 font-semibold">Total</td>
                <td className="px-3 py-2 text-right font-bold">R$ {colabsComVt.reduce((s, c) => s + c.vtCheio, 0).toFixed(2)}</td>
                <td className="px-3 py-2 text-right font-bold text-red-600">- R$ {colabsComVt.reduce((s, c) => s + c.descontoFaltas, 0).toFixed(2)}</td>
                <td className="px-3 py-2 text-right font-bold text-green-700">R$ {colabsComVt.reduce((s, c) => s + c.totalLiquido, 0).toFixed(2)}</td>
                <td colSpan={2} />
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      {/* Modal Detalhamento */}
      <Dialog open={!!detalheOpen} onOpenChange={() => setDetalheOpen(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Detalhe VT — {detalhe?.nome}</DialogTitle></DialogHeader>
          {detalhe && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Valor diário</span><span className="font-medium">R$ {detalhe.valorDia.toFixed(2)}</span></div>
              <div className="flex justify-between py-1 border-b"><span className="text-muted-foreground">Dias úteis seg-sex ({labelRangeQuinzena(year, month, quinzena)})</span><span className="font-medium">{detalhe.diasColabAtual - detalhe.sabadosTrabalhados}d</span></div>
              {detalhe.sabadosTrabalhados > 0 && (
                <div className="flex justify-between py-1 border-b text-blue-700"><span className="text-muted-foreground">(+) Sábados trabalhados</span><span className="font-medium">+{detalhe.sabadosTrabalhados}d</span></div>
              )}
              <div className="flex justify-between py-1 border-b font-semibold"><span>Total dias VT</span><span>{detalhe.diasColabAtual}d</span></div>
              <div className="flex justify-between py-1 border-b font-semibold"><span>VT Cheio</span><span>R$ {detalhe.vtCheio.toFixed(2)}</span></div>
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-2 text-xs text-yellow-800 mt-1">
                <p className="font-semibold mb-1">Quinzena anterior ({qAnterior.quinzena === 1 ? '1ª' : '2ª'} — {labelRangeQuinzena(qAnterior.ano, qAnterior.mes, qAnterior.quinzena)})</p>
                <div className="flex justify-between"><span>Dias úteis esperados</span><span>{detalhe.diasColabAnterior}d</span></div>
                <div className="flex justify-between"><span>Dias com presença</span><span>{detalhe.diasColabAnterior - detalhe.faltasAnterior}d</span></div>
                <div className="flex justify-between font-semibold"><span>Faltas</span><span>{detalhe.faltasAnterior}d</span></div>
              </div>
              {detalhe.descontoFaltas > 0 && (
                <div className="flex justify-between py-1 border-b text-red-600 font-semibold">
                  <span>(-) Desconto de faltas</span>
                  <span>- R$ {detalhe.descontoFaltas.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between py-2 font-bold text-base border-t-2 text-green-700">
                <span>Total Líquido</span><span>R$ {detalhe.totalLiquido.toFixed(2)}</span>
              </div>
              {detalhe.descontoFaltas > 0 && (
                <p className="text-xs text-muted-foreground text-center">⚠️ O desconto de faltas é descontado do salário nesta quinzena.</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal VT Avulso */}
      <Dialog open={avulsoOpen} onOpenChange={setAvulsoOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>VT Avulso</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Colaborador *</Label>
              <Select value={avulsoForm.colaborador_id} onValueChange={handleAvulsoColabChange}>
                <SelectTrigger><SelectValue placeholder="Selecionar..." /></SelectTrigger>
                <SelectContent>{colaboradores.filter(c => c.status === 'ativo').map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {avulsoForm.colaborador_id && (
              <div className="bg-muted rounded-lg p-3 text-xs text-muted-foreground">
                Valor/dia: <strong>R$ {Number(avulsoForm.valor_dia || 0).toFixed(2)}</strong>
              </div>
            )}
            <div>
              <Label>Quantidade de Dias *</Label>
              <Input type="number" min="1" value={avulsoForm.dias} onChange={e => setAvulsoForm({...avulsoForm, dias: e.target.value})} placeholder="Ex: 10" />
            </div>
            <div className="bg-muted rounded-lg p-3 text-sm font-semibold">Total: R$ {(Number(avulsoForm.valor_dia) * Number(avulsoForm.dias)).toFixed(2)}</div>
            <div><Label>Observações</Label><Input value={avulsoForm.observacoes} onChange={e => setAvulsoForm({...avulsoForm, observacoes: e.target.value})} placeholder="Observações (opcional)" /></div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setAvulsoOpen(false)}>Cancelar</Button>
              <Button
                onClick={() => avulsoMutation.mutate()}
                disabled={avulsoMutation.isPending || !avulsoForm.colaborador_id || !avulsoForm.dias}
              >
                Lançar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}